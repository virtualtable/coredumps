# Executor Base

Uploaded on my GitHub after being leaked without permission by a skid.
