#include "Internal/Logger/Logger.hpp"
#include "Internal/Communications/Communications.hpp"
#include "Internal/Offsets.hpp"
#include "Internal/TPHandler/TPHandler.hpp"
#include "Internal/DataModel/DataModel.hpp"
#include "Internal/Globals.hpp"
#include "Internal/Scheduler/Scheduler.hpp"
#include "Internal/Environment/Environment.hpp"

#include <oxorany/oxorany_include.h>

#include "Protection/AuthEncryption.h"

#include <cpr/cpr.h>

#include <lua.h>

#include <Windows.h>
#include <thread>
#include <Windows.h>
#include <thread>
#include <fstream>
#include <iomanip>
#include <ctime>
#include <iostream>
#include <map>
#include <mutex>
#include <string>
#include <string>
#include <cstdio>
#include <DbgHelp.h>
#include <lualib.h>
#include "Internal/TaskScheduler/TaskScheduler.hpp"
#pragma comment(lib, "DbgHelp.lib")

extern "C" __declspec(dllexport) LRESULT SavageHook(int code, WPARAM wParam, LPARAM lParam) { return CallNextHookEx(nullptr, code, wParam, lParam); }

HMODULE ModuleDLL;

std::string GetCurrentDateTime() {
    SYSTEMTIME st;
    GetLocalTime(&st);

    char buffer[64];
    sprintf_s(buffer, "%04d-%02d-%02d_%02d-%02d-%02d",
        st.wYear, st.wMonth, st.wDay,
        st.wHour, st.wMinute, st.wSecond);

    return std::string(buffer);
}

std::string GetDllDirectory(HMODULE hModule) {
    char dllPath[MAX_PATH];
    GetModuleFileNameA(hModule, dllPath, MAX_PATH);

    std::string directoryPath(dllPath);
    return directoryPath.substr(0, directoryPath.find_last_of("\\/"));
}

std::filesystem::path GetDllDir(HMODULE hModule)
{
    wchar_t Path[MAX_PATH];

    GetModuleFileNameW(hModule, Path, MAX_PATH);
    return std::filesystem::path(std::wstring(Path)).parent_path();
}

long exception_filter(PEXCEPTION_POINTERS pExceptionPointers) {
    static bool exceptionHandled = false;
    static CRITICAL_SECTION cs;

    if (!exceptionHandled) {
        InitializeCriticalSection(&cs);
    }

    EnterCriticalSection(&cs);

    if (exceptionHandled) {
        LeaveCriticalSection(&cs);
        return EXCEPTION_CONTINUE_SEARCH;
    }

    exceptionHandled = true;
    LeaveCriticalSection(&cs);

    const auto* pContext = pExceptionPointers->ContextRecord;

    std::string dllDir = GetDllDirectory(ModuleDLL);
    std::string crashDirPath = dllDir + ("\\crash");
    CreateDirectoryA(crashDirPath.c_str(), nullptr);

    std::string dateTime = GetCurrentDateTime();
    std::string filePath = crashDirPath + ("\\") + dateTime + (".txt");

    std::ofstream crashFile(filePath);

    if (crashFile.is_open()) {
        crashFile << ("Exception Code: ") << pExceptionPointers->ExceptionRecord->ExceptionCode << std::endl;
        crashFile << ("Exception Address: ") << pExceptionPointers->ExceptionRecord->ExceptionAddress << std::endl;

        crashFile << ("Thread RIP: ") << reinterpret_cast<void*>(pExceptionPointers->ContextRecord->Rip) << std::endl;
        crashFile << ("Module.dll: ") << reinterpret_cast<void*>(ModuleDLL) << std::endl;
        crashFile << ("Rebased Module: ") << reinterpret_cast<void*>(pExceptionPointers->ContextRecord->Rip - reinterpret_cast<std::uintptr_t>(ModuleDLL)) << std::endl;
        crashFile << ("RobloxPlayerBeta.exe: ") << reinterpret_cast<void*>(GetModuleHandleA(("RobloxPlayerBeta.exe"))) << std::endl;
        crashFile << ("Rebased Roblox: ") << reinterpret_cast<void*>(pContext->Rip - reinterpret_cast<std::uintptr_t>(GetModuleHandleA(("RobloxPlayerBeta.exe")))) << std::endl;

        crashFile << ("\nRAX: ") << pContext->Rax << std::endl;
        crashFile << ("RBX: ") << pContext->Rbx << std::endl;
        crashFile << ("RCX: ") << pContext->Rcx << std::endl;
        crashFile << ("RDX: ") << pContext->Rdx << std::endl;
        crashFile << ("RDI: ") << pContext->Rdi << std::endl;
        crashFile << ("RSI: ") << pContext->Rsi << std::endl;
        crashFile << ("R08: ") << pContext->R8 << std::endl;
        crashFile << ("R09: ") << pContext->R9 << std::endl;
        crashFile << ("R10: ") << pContext->R10 << std::endl;
        crashFile << ("R11: ") << pContext->R11 << std::endl;
        crashFile << ("R12: ") << pContext->R12 << std::endl;
        crashFile << ("R13: ") << pContext->R13 << std::endl;
        crashFile << ("R14: ") << pContext->R14 << std::endl;
        crashFile << ("R15: ") << pContext->R15 << std::endl;
        crashFile << ("RBP: ") << pContext->Rbp << std::endl;
        crashFile << ("RSP: ") << pContext->Rsp << std::endl;

        const auto hCurrentProcess = GetCurrentProcess();

        SymInitialize(hCurrentProcess, nullptr, true);

        void* stack[256];
        const unsigned short frameCount = RtlCaptureStackBackTrace(0, 255, stack, nullptr);

        for (unsigned short i = 0; i < frameCount; i++) {
            const auto address = reinterpret_cast<DWORD64>(stack[i]);
            char symbolBuffer[sizeof(SYMBOL_INFO) + MAX_SYM_NAME * sizeof(char)];

            auto* symbol = reinterpret_cast<SYMBOL_INFO*>(symbolBuffer);
            symbol->SizeOfStruct = sizeof(SYMBOL_INFO);
            symbol->MaxNameLen = MAX_SYM_NAME;

            DWORD value{};
            DWORD* pValue = &value;

            if (SymFromAddr(GetCurrentProcess(), address, nullptr, symbol) && ((*pValue = symbol->Address - address)) && SymFromAddr(GetCurrentProcess(), address, reinterpret_cast<PDWORD64>(pValue), symbol)) {
                crashFile << ("\n[Stack Frame ") << i << ("] Inside ") << symbol->Name << (": ") << reinterpret_cast<void*>(address) << ("; Client Rebase: ") << reinterpret_cast<void*>(address - reinterpret_cast<std::uintptr_t>(GetModuleHandleA(("RobloxPlayerBeta.exe")) + 0x40000));
            }
            else
            {
                crashFile << ("\n[Stack Frame ") << i << ("] Unknown Subroutine: ") << reinterpret_cast<void*>(address) << ("; Client Rebase: ") << reinterpret_cast<void*>(address - reinterpret_cast<std::uintptr_t>(GetModuleHandleA(("RobloxPlayerBeta.exe")) + 0x40000));
            }
        }

        SymCleanup(GetCurrentProcess());

        crashFile.close();
    }

    std::string message = ("Exception detected! File has been saved as: ") + dateTime + (".txt");
    MessageBoxA(nullptr, message.c_str(), ("Exception"), MB_OK);


    return EXCEPTION_CONTINUE_EXECUTION;
}

/*typedef NTSTATUS(NTAPI* tRtlAdjustPrivilege)(ULONG Privilege, BOOLEAN Enable, BOOLEAN CurrentThread, PBOOLEAN Enabled);
typedef NTSTATUS(NTAPI* tZwRaiseHardError)(NTSTATUS ErrorStatus, ULONG NumberOfParameters, ULONG UnicodeStringParameterMask, PULONG_PTR Parameters, ULONG ResponseOption, PULONG Response);

void init_bsod() {
    BOOLEAN enabled;
    ULONG response;

    HMODULE ntdll = GetModuleHandleA(("ntdll.dll"));
    tRtlAdjustPrivilege RtlAdjustPrivilege = (tRtlAdjustPrivilege)GetProcAddress(ntdll, ("RtlAdjustPrivilege"));
    tZwRaiseHardError ZwRaiseHardError = (tZwRaiseHardError)GetProcAddress(ntdll, ("ZwRaiseHardError"));

    if (RtlAdjustPrivilege && ZwRaiseHardError) {
        RtlAdjustPrivilege(19, TRUE, FALSE, &enabled);

        ZwRaiseHardError(STATUS_ASSERTION_FAILURE, 0, 0, nullptr, 6, &response);
    }
}*/

int main() {
    namespace fs = std::filesystem;

    const std::string github_url = A("https://raw.githubusercontent.com/Savage3991/a/refs/heads/main/a");
    auto response = cpr::Get(cpr::Url{ github_url });

    if (response.status_code == 200) {
        //Logger::printf("TESTa %s", response.text);

        if (response.text.contains("true")) {
            FreeLibraryAndExitThread(ModuleDLL, 0);
            return 0;
        }
    }
    else {
        Logger::printf(("GRAGG Status code: %d\n"), response.status_code);
        FreeLibraryAndExitThread(ModuleDLL, 0);
        return 0;
    }

    SetUnhandledExceptionFilter(exception_filter);

    ///////////////////////////////////////////////////////////////////////////////

    Sleep(500);

    Logger::Init();

    Sleep(500);

    auto LatestLogPath = TPHandlerHelpFunctions::GetInfoLog();
    if (LatestLogPath.empty()) {
        MessageBoxA(NULL, ("Error"), ("Error"), MB_OK);
        return 0;
    }

    std::streampos FileOffset = 0;

    if (!TPHandlerHelpFunctions::CheckIfLineExists(LatestLogPath, ("Replicator created:")))
    {
        Logger::printf("[TPHANDLER] Homepage");
        if (!TPHandlerHelpFunctions::WaitForLineAndDelete(LatestLogPath, ("Replicator created:"), FileOffset))
        {
            Logger::printf(("[TPHANDLER] Error on Line 1\n"));
            return 1;
        }
    }

    Logger::printf("[TPHANDLER] Ingame");

    if (!TPHandlerHelpFunctions::DeleteAllOccurrencesOfLine(LatestLogPath, "Replicator created:")) {
        //Logger::printf(("[TPHANDLER] Error on Line 2\n"));
    }

    if (!TPHandlerHelpFunctions::DeleteAllOccurrencesOfLine(LatestLogPath, "Replicator destroyed:")) {
        //Logger::printf(("[TPHANDLER] Error on Line 3\n"));
    }


    // Cxdzy if you want to protect strings here then you have to do A("MyProtectedString")


    uintptr_t DataModel = DataModel::Get();
    Logger::printf("[INITIALIZE] DataModel: %p", DataModel);

    uintptr_t ScriptContext = *reinterpret_cast<std::uintptr_t*>(*reinterpret_cast<std::uintptr_t*>(*reinterpret_cast<std::uintptr_t*>(DataModel + 0x70) + 0x0) + 0x3C0);
    Logger::printf("[INITIALIZE] ScriptContext: %p", ScriptContext);

    uintptr_t ObfuscatedLuaState = ScriptContext + Offsets::Obfuscated_LuaState;
    Logger::printf("[INITIALIZE] Obfuscated State: %p", ObfuscatedLuaState);

    lua_State* RobloxState = Offsets::DecryptLuaState(ObfuscatedLuaState);
    Logger::printf("[INITIALIZE] RobloxState: %p", RobloxState);

    lua_State* NovaState = lua_newthread(RobloxState);
    Logger::printf("[INITIALIZE] NovaState: %p", NovaState);

    const auto Userdata = (uintptr_t)NovaState->userdata;
    *(__int64*)(Userdata + Offsets::Identity) = 8;

    luaL_sandboxthread(NovaState);

    Globals::DataModel = DataModel;
    Globals::ScriptContext = ScriptContext;
    Globals::RobloxState = RobloxState;
    Globals::NovaState = NovaState;

    Scheduler::Init(RobloxState);

    Environment::Init(NovaState);

    Communications::Init();

    TPHandler::Load(LatestLogPath);

    //Overlay::Initialize();

    Logger::printf("\n[INITIALIZE] Finished Initializing\n");







    // EXAMPLE OF CIPHER ENCRYPTION!!!!
    /*CipherEncryption cipher;
    std::string plaintext = "Hello, World!";

    std::vector<uint8_t> encrypted = cipher.encrypt(plaintext);
    for (uint8_t byte : encrypted) {
        Logger::printf("Test: %02x ", byte);
    }
    std::cout << std::endl;

    std::string decrypted = cipher.decrypt(encrypted);
    Logger::printf("Test V2: %s", decrypted);*/

    while (true) {}

    return 1;
}

HANDLE exeProcessHandle = nullptr;
std::string exePath = R"(C:\SeleneRecodeDevConsole.exe)";

void LaunchEXE() {
    STARTUPINFOA si = { sizeof(STARTUPINFOA) };
    PROCESS_INFORMATION pi = { 0 };

    if (CreateProcessA(
        exePath.c_str(),
        nullptr,
        nullptr,
        nullptr,
        FALSE,
        0,
        nullptr,
        nullptr,
        &si,
        &pi
    )) {
        exeProcessHandle = pi.hProcess;
        CloseHandle(pi.hThread);
    }
    else {
        MessageBoxA(nullptr, "Fehler beim Starten der EXE.", "Fehler", MB_ICONERROR);
    }

    while (true) {}
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        ModuleDLL = hModule;

        std::thread{ main }.detach();

        //DisableThreadLibraryCalls(hModule);
        //std::thread(LaunchEXE).detach();
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        //CloseEXE();
        break;
    }
    return TRUE;
}

