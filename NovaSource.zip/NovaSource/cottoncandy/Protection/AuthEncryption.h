#pragma

#include <iostream>
#include <vector>
#include <string>
#include <random>
#include <stdexcept>
#include <iomanip>

class CipherEncryption {
private:
    std::vector<uint8_t> key;

    std::vector<uint8_t> generateRandomBytes(size_t length) {
        std::vector<uint8_t> bytes(length);
        std::mt19937 generator(std::random_device{}());
        std::uniform_int_distribution<int> distribution(0, 255);
        for (auto& byte : bytes) {
            byte = static_cast<uint8_t>(distribution(generator));
        }
        return bytes;
    }

    std::vector<uint8_t> xorData(const std::vector<uint8_t>& data, const std::vector<uint8_t>& key) {
        std::vector<uint8_t> result(data.size());
        for (size_t i = 0; i < data.size(); ++i) {
            result[i] = data[i] ^ key[i % key.size()];
        }
        return result;
    }

public:
    CipherEncryption() : key(generateRandomBytes(32)) {}

    std::vector<uint8_t> encrypt(const std::string& plaintext) {
        std::vector<uint8_t> data(plaintext.begin(), plaintext.end());
        std::vector<uint8_t> salt = generateRandomBytes(16);
        std::vector<uint8_t> encryptedData = xorData(data, key);
        salt.insert(salt.end(), encryptedData.begin(), encryptedData.end());
        return salt;
    }

    std::string decrypt(const std::vector<uint8_t>& ciphertext) {
        if (ciphertext.size() <= 16) {
            throw std::invalid_argument("Ciphertext too short.");
        }

        std::vector<uint8_t> encryptedData(ciphertext.begin() + 16, ciphertext.end());
        std::vector<uint8_t> decryptedData = xorData(encryptedData, key);
        return std::string(decryptedData.begin(), decryptedData.end());
    }
};