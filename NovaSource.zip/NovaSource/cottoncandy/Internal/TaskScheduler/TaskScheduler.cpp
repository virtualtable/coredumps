#include "TaskScheduler.hpp"
#include "../Offsets.hpp"
#include "../Logger/Logger.hpp"

#include <Windows.h>

uintptr_t TaskScheduler::GetJobByName(std::string JobName) {
    uintptr_t base = (uintptr_t)GetModuleHandleA(("RobloxPlayerBeta.exe"));

    uintptr_t Scheduler = *reinterpret_cast<uintptr_t*>(base + Offsets::RawTaskScheduler);

    Logger::printf(("TaskScheduler: %p\n"), Scheduler);

    uintptr_t JobRet = 0;
    uintptr_t JobStart = *(uintptr_t*)(Scheduler + Offsets::JobsStart);

    while (JobStart != *(uintptr_t*)(Scheduler + Offsets::JobsEnd)) {
        Logger::printf(("Job: %s\n"), *(std::string*)(*(uintptr_t*)(JobStart)+Offsets::JobName));

        if (*(std::string*)(*(uintptr_t*)(JobStart)+Offsets::JobName) == JobName) {
            JobRet = *(uintptr_t*)JobStart;
        }
        JobStart += 0x10;
    }

    return JobRet;
}

uintptr_t TaskScheduler::GetScriptContext() {
    uintptr_t WaitingHybridScriptsJob = GetJobByName(("WaitingHybridScriptsJob"));

    return *reinterpret_cast<uintptr_t*>(WaitingHybridScriptsJob + Offsets::ScriptContext);
}

__forceinline static auto get_jobs() -> std::vector<__int64>
{
    std::vector<__int64> jobs;

    uintptr_t base = (uintptr_t)GetModuleHandleA(("RobloxPlayerBeta.exe"));

    uintptr_t task_scheduler = *reinterpret_cast<uintptr_t*>(base + Offsets::RawTaskScheduler);

    __int64* current_job = *reinterpret_cast<__int64**>(task_scheduler + Offsets::JobsStart);

    do {
        jobs.push_back(*current_job);
        current_job += 2;
    } while (current_job != *reinterpret_cast<__int64**>(task_scheduler + Offsets::JobsEnd));

    return jobs;
}

__forceinline static std::vector<__int64> get_all_jobs_by_name(std::string name)
{
    std::vector <__int64> result;
    std::vector <__int64> jobs = get_jobs();

    for (__int64& job : jobs)
    {
        if (std::string* job_name = reinterpret_cast<std::string*>(job + Offsets::JobName); *job_name == name)
        {
            result.push_back(job);
        }
    }

    return result;
}

bool TaskScheduler::IsLoaded()
{
    int counter = get_all_jobs_by_name("WaitingHybridScriptsJob").size();
    if (counter == 2)
        return true;
    else
        return false;
}