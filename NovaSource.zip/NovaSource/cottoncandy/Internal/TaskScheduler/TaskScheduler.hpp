#pragma once

#include <cstdint>
#include <string>

class TaskScheduler
{
public:
	static uintptr_t GetJobByName(std::string JobName);
	static uintptr_t GetScriptContext();
	static bool IsLoaded();
};

