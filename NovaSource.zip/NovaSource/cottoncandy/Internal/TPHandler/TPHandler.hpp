#pragma once

#include <string>
#include <filesystem>

class TPHandler {
public:
    static void Load(std::string);
};

class TPHandlerHelpFunctions {
public:
    static std::filesystem::path GetLatestLog(const std::filesystem::path& LogLocation);
    static std::string GetInfoLog();
    static bool DeleteProcessedLines(const std::string& FilePath, std::streampos& FileOffset);
    static bool WaitForLineAndDelete(const std::string& FilePath, const std::string& TargetLine, std::streampos& FileOffset);
    static bool CheckIfLineExists(const std::string& FilePath, const std::string& TargetLine);
    static bool DeleteAllOccurrencesOfLine(const std::string& FilePath, const std::string& TargetLine);
};