#include "TPHandler.hpp"

#include <Windows.h>
#include <thread>
#include <DbgHelp.h>
#include <Shlobj.h>
#include <fstream>
#include <filesystem>
#include <string>
#include <iostream>
#include <thread>

#include "lualib.h"

#include "../Logger/Logger.hpp"
#include "../Communications/Communications.hpp"
#include "../Offsets.hpp"
#include "../DataModel/DataModel.hpp"
#include "../TaskScheduler/TaskScheduler.hpp"
#include "../Globals.hpp"
#include "../Scheduler/Scheduler.hpp"
#include "../Environment/Environment.hpp"

std::filesystem::path TPHandlerHelpFunctions::GetLatestLog(const std::filesystem::path& LogLocation)
{
    std::filesystem::path LatestLogPath;
    std::filesystem::file_time_type LatestTime{};

    try
    {
        for (const auto& entry : std::filesystem::directory_iterator(LogLocation))
        {
            if (std::filesystem::is_regular_file(entry.path()))
            {
                auto LastWriteTime = std::filesystem::last_write_time(entry.path());
                if (LastWriteTime > LatestTime)
                {
                    LatestTime = LastWriteTime;
                    LatestLogPath = entry.path();
                }
            }
        }
    }
    catch (const std::filesystem::filesystem_error& e)
    {
        std::cerr << "farakkk: " << e.what() << std::endl;
    }

    return LatestLogPath;
}

std::string TPHandlerHelpFunctions::GetInfoLog()
{
    PWSTR AppData = nullptr;

    if (SHGetKnownFolderPath(FOLDERID_LocalAppData, KF_FLAG_CREATE, nullptr, &AppData) != S_OK)
    {
        return "";
    }

    std::filesystem::path AppDataPath(AppData);
    CoTaskMemFree(AppData);

    auto LogDirectory = AppDataPath / ("Roblox") / ("logs");
    if (!std::filesystem::exists(LogDirectory))
    {
        return "";
    }

    auto LatestLog = GetLatestLog(LogDirectory);
    if (LatestLog.empty())
    {
        return "";
    }

    return LatestLog.string();
}

bool TPHandlerHelpFunctions::DeleteProcessedLines(const std::string& FilePath, std::streampos& FileOffset)
{
    try
    {
        std::ifstream LogFile(FilePath, std::ios::binary);
        if (!LogFile.is_open())
        {
            return false;
        }

        LogFile.seekg(FileOffset);
        std::ostringstream RemainingLines;
        RemainingLines << LogFile.rdbuf();

        LogFile.close();

        std::ofstream OutFile(FilePath, std::ios::trunc | std::ios::binary);
        if (!OutFile.is_open())
        {
            return false;
        }

        OutFile << RemainingLines.str();
        OutFile.close();

        FileOffset = 0;
        return true;
    }
    catch (const std::exception& e)
    {
        return false;
    }
}

bool TPHandlerHelpFunctions::WaitForLineAndDelete(const std::string& FilePath, const std::string& TargetLine, std::streampos& FileOffset)
{
    while (true)
    {
        std::ifstream LogFile(FilePath);
        if (!LogFile.is_open())
        {
            return false;
        }

        LogFile.seekg(FileOffset);

        std::string Line;
        while (std::getline(LogFile, Line))
        {
            FileOffset = LogFile.tellg();
            if (Line.find(TargetLine) != std::string::npos)
            {
                if (!DeleteProcessedLines(FilePath, FileOffset))
                {
                    return false;
                }

                return true;
            }
        }

        LogFile.close();

        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
}

bool TPHandlerHelpFunctions::CheckIfLineExists(const std::string& FilePath, const std::string& TargetLine)
{
    std::ifstream LogFile(FilePath);
    if (!LogFile.is_open())
    {
        return false;
    }

    std::string Line;
    while (std::getline(LogFile, Line))
    {
        if (Line.find(TargetLine) != std::string::npos)
        {
            return true;
        }
    }

    return false;
}

bool TPHandlerHelpFunctions::DeleteAllOccurrencesOfLine(const std::string& FilePath, const std::string& TargetLine)
{
    try
    {
        std::ifstream LogFile(FilePath, std::ios::binary);
        if (!LogFile.is_open())
        {
            return false;
        }

        std::ostringstream RemainingLines;
        std::string Line;
        bool Found = false;

        while (std::getline(LogFile, Line))
        {
            if (Line.find(TargetLine) == std::string::npos)
            {
                RemainingLines << Line << '\n';
            }
            else
            {
                Found = true;
            }
        }
        LogFile.close();

        if (Found)
        {
            std::ofstream OutFile(FilePath, std::ios::trunc | std::ios::binary);
            if (!OutFile.is_open())
            {
                return false;
            }
            OutFile << RemainingLines.str();
            OutFile.close();
        }

        return Found;
    }
    catch (const std::exception& e)
    {
        std::cerr << "Error while deleting lines: " << e.what() << std::endl;
        return false;
    }
}


void TPHandler::Load(std::string LatestLogPath) {

    std::thread([LatestLogPath]() mutable -> void {

        while (true) {
            std::streampos FileOffset = 0;

            if (!TPHandlerHelpFunctions::WaitForLineAndDelete(LatestLogPath, ("Replicator destroyed:"), FileOffset))
            {
            }

            Logger::printf("[TPHANDLER] Homepage");
            Environment::Reset();

            if (!TPHandlerHelpFunctions::WaitForLineAndDelete(LatestLogPath, ("Replicator created:"), FileOffset))
            {
            }

            Logger::printf("[TPHANDLER] Ingame");

            std::this_thread::sleep_for(std::chrono::seconds(1));

            uintptr_t ScriptContext = TaskScheduler::GetScriptContext();
            Logger::printf("\n[INITIALIZE] ScriptContext: %p", ScriptContext);

            uintptr_t DataModel = *reinterpret_cast<std::uintptr_t*>(ScriptContext + Offsets::Parent);
            Logger::printf("[INITIALIZE] DataModel: %p", DataModel);

            uintptr_t ObfuscatedLuaState = ScriptContext + Offsets::Obfuscated_LuaState;
            Logger::printf("[INITIALIZE] Obfuscated State: %p", ObfuscatedLuaState);

            lua_State* RobloxState = Offsets::DecryptLuaState(ObfuscatedLuaState);
            Logger::printf("[INITIALIZE] RobloxState: %p", RobloxState);

            lua_State* NovaState = lua_newthread(RobloxState);
            Logger::printf("[INITIALIZE] NovaState: %p", NovaState);

            const auto Userdata = (uintptr_t)NovaState->userdata;
            *(__int64*)(Userdata + Offsets::Identity) = 8;

            Globals::DataModel = DataModel;
            Globals::ScriptContext = ScriptContext;
            Globals::RobloxState = RobloxState;
            Globals::NovaState = NovaState;

            luaL_sandboxthread(NovaState);

            Scheduler::Init(RobloxState);

            Environment::Init(NovaState);

            while (!Environment::teleport_queue_script.empty())
            {
                Scheduler::AddScript(Environment::teleport_queue_script.front());
                //Scheduler::schedulerJobs.emplace(SchedulerJob(Environment::teleport_queue_script.front()));

                Environment::teleport_queue_script.pop();
            }

            Logger::printf("\n[INITIALIZE] Finished Initializing\n");

            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }

        }).detach();

}

