#pragma once

#include <map>
#include "lua.h"
#include <vector>
#include "lobject.h"
#include <lapi.h>
#include <queue>

class Environment
{
public:
	static std::vector<Closure*> function_array;
	static std::map<Closure*, Closure*> newcclosure_map;
	static std::map<Closure*, Closure*> hooked_functions;
	static std::queue<std::string> teleport_queue_script;
	static std::map<lua_State*, int> newcclosure_threads;


	static void Init(lua_State* L);
	static void Reset();
};

