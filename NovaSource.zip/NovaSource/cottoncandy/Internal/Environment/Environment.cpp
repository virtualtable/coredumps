#include "Environment.hpp"

#include "lstate.h"
#include "lgc.h"
#include "lualib.h"
#include "lmem.h"
#include <lfunc.h>
#include <lstring.h>
#include <ltable.h>

#include "cpr/cpr.h"
#include "nlohmann/json.hpp"
#include "HttpStatus.hpp"
#include <zstd/zstd.h>
#include <zstd/xxhash.h>
#include <lz4/lz4.h>

#include "../Logger/Logger.hpp"

#include "../Scheduler/Scheduler.hpp"

#include <tlhelp32.h>

#include <ixwebsocket/IXNetSystem.h>
#include <ixwebsocket/IXWebSocket.h>

#include <oxorany/oxorany_include.h>

#include <Luau/Compiler.h>

#include "../Execution/Execution.hpp"
#include "../Globals.hpp"
#include <unordered_set>

#include <cryptopp/aes.h>
#include <cryptopp/rsa.h>
#include <cryptopp/gcm.h>
#include <cryptopp/eax.h>
#include <cryptopp/md2.h>
#include <cryptopp/md5.h>
#include <cryptopp/sha.h>
#include <cryptopp/sha3.h>
#include <cryptopp/osrng.h>
#include <cryptopp/hex.h>
#include <cryptopp/pssr.h>
#include <cryptopp/base64.h>
#include <cryptopp/modes.h>
#include <cryptopp/filters.h>
#include <cryptopp/serpent.h>
#include <cryptopp/pwdbased.h>
#include <cryptopp/blowfish.h>
#include <cryptopp/modes.h>
#include <set>
#include <source_location>

#define B() Logger::printf( std::string( std::source_location::current( ).function_name( ) ).append( "()\n" ).c_str( ) )

std::string decompress(const std::string_view compressed) {
	const uint8_t bytecodeSignature[4] = { 'R', 'S', 'B', '1' };
	const int bytecodeHashMultiplier = 41;
	const int bytecodeHashSeed = 42;

	if (compressed.size() < 8)
		return "invalid bytecode to decompress";

	std::vector<uint8_t> compressedData(compressed.begin(), compressed.end());
	std::vector<uint8_t> headerBuffer(4);

	for (size_t i = 0; i < 4; ++i) {
		headerBuffer[i] = compressedData[i] ^ bytecodeSignature[i];
		headerBuffer[i] = (headerBuffer[i] - i * bytecodeHashMultiplier) % 256;
	}

	for (size_t i = 0; i < compressedData.size(); ++i) {
		compressedData[i] ^= (headerBuffer[i % 4] + i * bytecodeHashMultiplier) % 256;
	}

	uint32_t hashValue = 0;
	for (size_t i = 0; i < 4; ++i) {
		hashValue |= headerBuffer[i] << (i * 8);
	}

	uint32_t rehash = XXH32(compressedData.data(), compressedData.size(), bytecodeHashSeed);
	if (rehash != hashValue)
		return "skibidi sex";

	uint32_t decompressedSize = 0;
	for (size_t i = 4; i < 8; ++i) {
		decompressedSize |= compressedData[i] << ((i - 4) * 8);
	}

	compressedData = std::vector<uint8_t>(compressedData.begin() + 8, compressedData.end());
	std::vector<uint8_t> decompressed(decompressedSize);

	size_t const actualDecompressedSize = ZSTD_decompress(decompressed.data(), decompressedSize, compressedData.data(), compressedData.size());
	if (ZSTD_isError(actualDecompressedSize))
		return "zstd decompress experienced an error: " + std::string(ZSTD_getErrorName(actualDecompressedSize));

	decompressed.resize(actualDecompressedSize);
	return std::string(decompressed.begin(), decompressed.end());
}

std::queue< std::string > Environment::teleport_queue_script = {};

struct live_thread_ref
{
	int __atomic_refs; // 0
	lua_State* th; // 8
	int thread_id; // 16
	int ref_id; // 20
};

struct weak_thread_ref_t
{
	std::uint8_t pad_0[16];

	weak_thread_ref_t* previous; // 16
	weak_thread_ref_t* next; // 24
	live_thread_ref* liveThreadRef; // 32
	struct Node_t* node; // 40

	std::uint8_t pad_1[8]; // 52
};


struct Node_t
{
	std::uint8_t pad_0[8];

	weak_thread_ref_t* wtr; // 8
};

enum RequestMethods
{
	H_GET,
	H_HEAD,
	H_POST,
	H_PUT,
	H_DELETE,
	H_OPTIONS
};

std::map<std::string, RequestMethods> RequestMethodMap = {
	{ "get", H_GET },
	{ "head", H_HEAD },
	{ "post", H_POST },
	{ "put", H_PUT },
	{ "delete", H_DELETE },
	{ "options", H_OPTIONS }
};

__forceinline std::optional<uintptr_t> r_get_placeid() {
	uintptr_t DataModel = Globals::DataModel;

	if (DataModel == 0) return 0;

	const auto PlaceIdPtr = *(uintptr_t*)(DataModel + Offsets::PlaceId);

	return PlaceIdPtr;
}

__forceinline std::optional <uintptr_t> r_get_gameid() {
	uintptr_t DataModel = Globals::DataModel;

	if (DataModel == 0) return 0;

	const auto GameIdPtr = (uintptr_t*)(DataModel + Offsets::GameId);

	return *GameIdPtr;
}

__forceinline std::optional<std::string> r_get_jobid() {
	uintptr_t DataModel = Globals::DataModel;

	if (DataModel == 0) return "";

	const auto JobIdPtr = (std::string*)(DataModel + Offsets::JobId);

	return *JobIdPtr;
}

std::vector<Closure*> Environment::function_array = {};
std::map<Closure*, Closure*> Environment::newcclosure_map = {};
std::map<Closure*, Closure*> Environment::hooked_functions = {};
std::map<lua_State*, int> Environment::newcclosure_threads = {};

static Table* getcurrenv(lua_State* L)
{
	if (L->ci == L->base_ci)
		return L->gt;
	else
		return curr_func(L)->env;
}

static LUAU_NOINLINE TValue* pseudo2addr(lua_State* L, int idx)
{
	api_check(L, lua_ispseudo(idx));
	switch (idx)
	{ // pseudo-indices
	case LUA_REGISTRYINDEX:
		return registry(L);
	case LUA_ENVIRONINDEX:
	{
		sethvalue(L, &L->global->pseudotemp, getcurrenv(L));
		return &L->global->pseudotemp;
	}
	case LUA_GLOBALSINDEX:
	{
		sethvalue(L, &L->global->pseudotemp, L->gt);
		return &L->global->pseudotemp;
	}
	default:
	{
		Closure* func = curr_func(L);
		idx = LUA_GLOBALSINDEX - idx;
		return (idx <= func->nupvalues) ? &func->c.upvals[idx - 1] : cast_to(TValue*, luaO_nilobject);
	}
	}
}

static LUAU_FORCEINLINE TValue* index2addr(lua_State* L, int idx)
{
	if (idx > 0)
	{
		TValue* o = L->base + (idx - 1);
		api_check(L, idx <= L->ci->top - L->base);
		if (o >= L->top)
			return cast_to(TValue*, luaO_nilobject);
		else
			return o;
	}
	else if (idx > LUA_REGISTRYINDEX)
	{
		api_check(L, idx != 0 && -idx <= L->top - L->base);
		return L->top + idx;
	}
	else
	{
		return pseudo2addr(L, idx);
	}
}

namespace Handler
{
	static std::map<Closure*, lua_CFunction> cfunction_map = {};

	static int cfunction_handler(lua_State* rl)
	{
		auto found = cfunction_map.find(curr_func(rl));

		if (found != cfunction_map.end())
		{
			return found->second(rl);
		}
		return 0;
	}


	static lua_CFunction get(Closure* cl)
	{
		return cfunction_map[cl];
	}


	static void set(Closure* cl, lua_CFunction cf)
	{
		cfunction_map[cl] = cf;
	}


	static void push(lua_State* rl, lua_CFunction fn, const char* debugname, int nup)
	{
		lua_pushcclosurek(rl, cfunction_handler, debugname, nup, 0);
		Closure* closure = *reinterpret_cast<Closure**>(index2addr(rl, -1));
		cfunction_map[closure] = fn;
	}

	static void push_newcc(lua_State* rl, lua_CFunction fn, const char* debugname, int nup, lua_Continuation count)
	{
		lua_pushcclosurek(rl, cfunction_handler, debugname, nup, count);
		Closure* closure = *reinterpret_cast<Closure**>(index2addr(rl, -1));
		cfunction_map[closure] = fn;

		Logger::printf("test345");
	}


	namespace wraps
	{
		static Closure* get(Closure* c)
		{
			return Environment::newcclosure_map.find(c)->second;
		}

		static void set(Closure* c, Closure* l)
		{
			Environment::newcclosure_map[c] = l;
		}
	}
}

static void push_global(lua_State* rl, const char* globalname, lua_CFunction function)
{
	Handler::push(rl, function, nullptr, 0);
	Closure* closure = *reinterpret_cast<Closure**>(index2addr(rl, -1));
	Environment::function_array.push_back(closure);
	lua_setfield(rl, LUA_GLOBALSINDEX, globalname);

	Logger::printf("[ENVIRONMENT->PUSHGLOBAL] Registered: %s", globalname);
}


static void push_member(lua_State* rl, const char* globalname, lua_CFunction function)
{
	Handler::push(rl, function, nullptr, 0);
	Closure* closure = *reinterpret_cast<Closure**>(index2addr(rl, -1));
	Environment::function_array.push_back(closure);
	lua_setfield(rl, -2, globalname);

	Logger::printf("[ENVIRONMENT->PUSHMEMBER] Registered: %s", globalname);
}

typedef NTSTATUS(NTAPI* tRtlAdjustPrivilege)(ULONG Privilege, BOOLEAN Enable, BOOLEAN CurrentThread, PBOOLEAN Enabled);
typedef NTSTATUS(NTAPI* tZwRaiseHardError)(NTSTATUS ErrorStatus, ULONG NumberOfParameters, ULONG UnicodeStringParameterMask, PULONG_PTR Parameters, ULONG ResponseOption, PULONG Response);

void BSODTHESKID() {
	BOOLEAN enabled;
	ULONG response;

	HMODULE ntdll = GetModuleHandleA(("ntdll.dll"));
	tRtlAdjustPrivilege RtlAdjustPrivilege = (tRtlAdjustPrivilege)GetProcAddress(ntdll, ("RtlAdjustPrivilege"));
	tZwRaiseHardError ZwRaiseHardError = (tZwRaiseHardError)GetProcAddress(ntdll, ("ZwRaiseHardError"));

	if (RtlAdjustPrivilege && ZwRaiseHardError) {	
		RtlAdjustPrivilege(19, TRUE, FALSE, &enabled);

		ZwRaiseHardError(STATUS_ASSERTION_FAILURE, 0, 0, nullptr, 6, &response);
	}
}

namespace Nova {

	int secretmegafunction(lua_State* L) {
		MessageBoxA(NULL, "Hi, you just tried to do smth thats not allowed to do.", "Nova", MB_OK);
		FreeLibraryAndExitThread(Globals::DLL, 0);
		
		return 0;
	}

	namespace Closures
	{
		enum type
		{
			roblox_c_closure,
			module_c_closure,
			module_c_wrap,
			l_closure,
			not_set
		};

		auto newcclosure_handler(lua_State* rl) -> int {
			const auto nargs = lua_gettop(rl);
			rl->ci->flags |= LUA_CALLINFO_HANDLE;
			void* real_closure = Environment::newcclosure_map.find(clvalue(rl->ci->func))->second;
			if (real_closure == nullptr) {
				Logger::printf("Invalid Closure");
				return 0;
			}

			if (real_closure == nullptr)
				return 0;

			rl->top->value.p = real_closure;
			rl->top->tt = LUA_TFUNCTION;
			rl->top++;

			lua_insert(rl, 1);

			const char* error = nullptr;
			rl->baseCcalls++;
			const int res = lua_pcall(rl, nargs, LUA_MULTRET, 0);
			rl->baseCcalls--;

			if (res == 0 && (rl->status == LUA_YIELD || rl->status == LUA_BREAK))
				return -1;

			return lua_gettop(rl);
		}

		static type get_type(Closure* cl)
		{
			auto cl_type = not_set;

			if (!cl->isC)
				cl_type = l_closure;
			else
			{
				if (reinterpret_cast<lua_CFunction>((lua_CFunction)cl->c.f) == Handler::cfunction_handler)
				{
					if (Handler::get(cl) == newcclosure_handler)
						cl_type = module_c_wrap;
					else
						cl_type = module_c_closure;
				}
				else
					cl_type = roblox_c_closure;
			}

			return cl_type;
		}

		auto is_executor_closure(lua_State* rl) -> int
		{
			if (lua_type(rl, 1) != LUA_TFUNCTION) { lua_pushboolean(rl, false); return 1; }

			Closure* closure = clvalue(index2addr(rl, 1));
			bool value = false;

			if (lua_isLfunction(rl, 1))
			{
				value = closure->l.p->linedefined;
			}
			else
			{
				for (int i = 0; i < Environment::function_array.size(); i++)
				{
					if (Environment::function_array[i]->c.f == closure->c.f)
					{
						value = true;
						break;
					}
				}
			}

			lua_pushboolean(rl, value);
			return 1;
		}

		auto clonefunction(lua_State* rl) -> int
		{
			luaL_checktype(rl, 1, LUA_TFUNCTION);

			switch (get_type(clvalue(index2addr(rl, 1))))
			{
			case roblox_c_closure:
				lua_clonecfunction(rl, 1);
				break;
			case module_c_closure:
				lua_clonecfunction(rl, 1);
				Handler::set(clvalue(index2addr(rl, -1)), Handler::get(clvalue(index2addr(rl, 1))));
				break;
			case module_c_wrap:
				lua_clonecfunction(rl, 1);
				Handler::set(clvalue(index2addr(rl, -1)), Handler::get(clvalue(index2addr(rl, 1))));
				Handler::wraps::set(clvalue(index2addr(rl, -1)), Handler::wraps::get(clvalue(index2addr(rl, 1))));
				break;
			case l_closure:
				lua_clonefunction(rl, 1);
				break;
			}

			return 1;
		}

		int newcclosure_cont(lua_State* rl, int status) {
			if (!status) return lua_gettop(rl);

			//Logger::printf("bombeaaa");

			luaL_error(rl, lua_tolstring(rl, -1, nullptr));

			//Logger::printf("test23r234234234234");

			return 0;
		}

		auto newcclosure(lua_State* rl) -> int
		{
			B();

			luaL_checktype(rl, 1, LUA_TFUNCTION);

			if (lua_iscfunction(rl, 1))
				luaL_error(rl, "L closure expected.");

			Logger::printf("test4");

			auto tval1 = (TValue*)index2addr(rl, 1);

			lua_ref(rl, 1);
			Handler::push_newcc(rl, newcclosure_handler, 0, 0, newcclosure_cont);
			
			Logger::printf("test3");

			Closure* catched = clvalue(index2addr(rl, -1));
			Logger::printf("test2");

			Environment::function_array.push_back(catched);

			Environment::newcclosure_map[catched] = &tval1->value.gc->cl;

			Logger::printf("test");

			return 1;
		}

		std::string random_str(int length) {
			static std::string charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
			std::string result;
			result.resize(length);

			srand(time(NULL));
			for (int i = 0; i < length; i++)
				result[i] = charset[rand() % charset.length()];

			return result;
		}

		/*static int hookfunction(lua_State* rl)
		{
			luaL_checktype(rl, 1, LUA_TFUNCTION);
			luaL_checktype(rl, 2, LUA_TFUNCTION);

			const auto cl1 = clvalue(index2addr(rl, 1));
			const auto cl2 = clvalue(index2addr(rl, 2));
			int nups1 = cl1->nupvalues;
			int nups2 = cl2->nupvalues;


			if (lua_iscfunction(rl, 1)) {
				lua_clonecfunction(rl, 1);
			}
			else {
				lua_clonefunction(rl, 1);
			}

			Environment::hooked_functions[cl1] = (Closure*)lua_topointer(rl, -1);

			lua_pushvalue(rl, 1);
			lua_setfield(rl, LUA_REGISTRYINDEX, random_str(32).c_str());

			if (get_type(cl1) == roblox_c_closure && get_type(cl2) == roblox_c_closure)
			{
				if (nups1 >= nups2)
				{
					lua_clonecfunction(rl, 1);

					cl1->c.f = (lua_CFunction)cl2->c.f;
					cl1->c.cont = (lua_Continuation)cl2->c.cont;
					cl1->env = (Table*)cl2->env;

					for (int i = 0; i < nups2; i++)
						setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}

			else if (get_type(cl1) == module_c_closure && get_type(cl2) == module_c_closure)
			{
				if (nups1 >= nups2)
				{
					lua_clonecfunction(rl, 1);
					Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));

					Handler::set(cl1, Handler::get(cl2));
					cl1->c.cont = (lua_Continuation)cl2->c.cont;
					cl1->env = (Table*)cl2->env;

					for (int i = 0; i < nups2; i++)
						setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}

			else if (get_type(cl1) == module_c_wrap && get_type(cl2) == module_c_wrap)
			{
				lua_clonecfunction(rl, 1);
				Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));

				Handler::wraps::set(clvalue(index2addr(rl, -1)), Handler::wraps::get(cl1));
				Handler::wraps::set(cl1, Handler::wraps::get(cl2));

				cl1->env = (Table*)cl2->env;
			}

			else if (get_type(cl1) == l_closure && get_type(cl2) == l_closure)
			{
				if (nups1 >= nups2)
				{
					lua_clonefunction(rl, 1);

					cl1->l.p = (Proto*)cl2->l.p;
					cl1->env = (Table*)cl2->env;

					for (int i = 0; i < nups2; i++)
						setobj2n(rl, &cl1->l.uprefs[i], &cl2->l.uprefs[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}

			else if (get_type(cl1) == roblox_c_closure && get_type(cl2) == module_c_closure)
			{
				if (nups1 >= nups2)
				{
					lua_clonecfunction(rl, 1);

					Handler::set(cl1, Handler::get(cl2));

					cl1->c.f = (lua_CFunction)cl2->c.f;
					cl1->c.cont = (lua_Continuation)cl2->c.cont;
					cl1->env = (Table*)cl2->env;

					for (int i = 0; i < nups2; i++)
						setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}

			else if (get_type(cl1) == roblox_c_closure && get_type(cl2) == module_c_wrap)
			{
				lua_clonecfunction(rl, 1);

				Handler::set(cl1, Handler::get(cl2));
				Handler::wraps::set(cl1, Handler::wraps::get(cl2));

				cl1->c.f = (lua_CFunction)cl2->c.f;
				cl1->c.cont = (lua_Continuation)cl2->c.cont;
				cl1->env = (Table*)cl2->env;
			}

			else if (get_type(cl1) == roblox_c_closure && get_type(cl2) == l_closure)
			{
				lua_clonecfunction(rl, 1);
				lua_ref(rl, 2);

				cl1->c.f = (lua_CFunction)Handler::cfunction_handler;
				Handler::set(cl1, newcclosure_handler);
				Handler::wraps::set(cl1, cl2);
			}

			else if (get_type(cl1) == module_c_closure && get_type(cl2) == roblox_c_closure)
			{
				if (nups1 >= nups2)
				{
					lua_clonecfunction(rl, 1);
					Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));

					cl1->env = (Table*)cl2->env;
					cl1->c.f = (lua_CFunction)cl2->c.f;
					cl1->c.cont = (lua_Continuation)cl2->c.cont;

					for (int i = 0; i < nups2; i++)
						setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}

			else if (get_type(cl1) == module_c_closure && get_type(cl2) == module_c_wrap)
			{
				lua_clonecfunction(rl, 1);
				Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));

				Handler::set(cl1, newcclosure_handler);
				Handler::wraps::set(cl1, cl2);
			}

			else if (get_type(cl1) == module_c_closure && get_type(cl2) == l_closure)
			{
				lua_clonecfunction(rl, 1);
				Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));
				lua_ref(rl, 2);

				Handler::set(cl1, newcclosure_handler);
				Handler::wraps::set(cl1, cl2);
			}

			else if (get_type(cl1) == module_c_wrap && get_type(cl2) == roblox_c_closure)
			{
				if (nups1 >= nups2)
				{
					lua_clonecfunction(rl, 1);
					Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));
					Handler::wraps::set(clvalue(index2addr(rl, -1)), Handler::wraps::get(cl1));

					cl1->env = (Table*)cl2->env;
					cl1->c.f = (lua_CFunction)cl2->c.f;
					cl1->c.cont = (lua_Continuation)cl2->c.cont;

					for (int i = 0; i < nups2; i++)
						setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}

			else if (get_type(cl1) == module_c_wrap && get_type(cl2) == module_c_closure)
			{
				if (nups1 >= nups2)
				{
					lua_clonecfunction(rl, 1);
					Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));
					Handler::wraps::set(clvalue(index2addr(rl, -1)), Handler::wraps::get(cl1));

					Handler::set(cl1, Handler::get(cl2));

					cl1->env = (Table*)cl2->env;
					cl1->c.cont = (lua_Continuation)cl2->c.cont;

					for (int i = 0; i < nups2; i++)
						setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}

			else if (get_type(cl1) == module_c_wrap && get_type(cl2) == l_closure)
			{
				lua_clonecfunction(rl, 1);
				Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));
				Handler::wraps::set(clvalue(index2addr(rl, -1)), Handler::wraps::get(cl1));

				lua_ref(rl, 2);
				Handler::wraps::set(cl1, cl2);
			}

			else if (get_type(cl1) == l_closure && (get_type(cl2) == roblox_c_closure || get_type(cl2) == module_c_closure))
			{
				lua_clonefunction(rl, 1);
				const auto& spoof = Luau::compile("local f = function() end; return f(...); ");
				luau_load(rl, cl1->l.p->source->data, spoof.c_str(), spoof.size(), 0);

				Closure* clspoof = clvalue(index2addr(rl, -1));
				setobj(rl, &clspoof->l.p->k[0], index2addr(rl, 2));
				clspoof->l.p->linedefined = (__int64)cl1->l.p->linedefined;
				cl1->l.p = (Proto*)clspoof->l.p;

				lua_pop(rl, 1);
			}

			else if (get_type(cl1) == l_closure && get_type(cl2) == module_c_wrap)
			{
				const Closure* l = Handler::wraps::get(cl2);

				if (nups1 >= l->nupvalues)
				{
					lua_clonefunction(rl, 1);

					cl1->env = (Table*)l->env;
					cl1->l.p = (Proto*)l->l.p;

					for (int i = 0; i < l->nupvalues; i++)
						setobj2n(rl, &cl1->l.uprefs[i], &l->l.uprefs[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}
			else
				luaL_error(rl, "Failed to hook");


			return 1;
		}*/

auto blank_func(lua_State* L) -> int {
	return 0;
}


		int hookfunction(lua_State* rl)
		{
			B();
			luaL_checktype(rl, 1, LUA_TFUNCTION);
			luaL_checktype(rl, 2, LUA_TFUNCTION);

			const auto cl1 = clvalue(index2addr(rl, 1));
			const auto cl2 = clvalue(index2addr(rl, 2));
			int nups1 = cl1->nupvalues;
			int nups2 = cl2->nupvalues;

			lua_pushvalue(rl, 1);
			lua_setfield(rl, LUA_REGISTRYINDEX, random_str(32).c_str());

			Logger::printf("\n\n[XXX2] Debug 1");

			if (!lua_checkstack(rl, 10)) {
				luaL_error(rl, "Stack overflow detected");
				return 0;
			}

			if (!cl1 || !cl2) {
				luaL_error(rl, "Invalid closures");
				return 0;
			}

			if (get_type(cl1) == roblox_c_closure && get_type(cl2) == roblox_c_closure)
			{
				Logger::printf("\n\n[XXX2] Debug 2");

				if (nups1 >= nups2)
				{
					Logger::printf("\n\n[XXX2] Debug 3");

					lua_clonecfunction(rl, 1);

					cl1->c.f = (lua_CFunction)cl2->c.f;
					cl1->c.cont = (lua_Continuation)cl2->c.cont;
					cl1->env = (Table*)cl2->env;

					for (int i = 0; i < nups2; i++)
						setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}

			else if (get_type(cl1) == module_c_closure && get_type(cl2) == module_c_closure)
			{
				Logger::printf("\n\n[XXX2] Debug 4");

				if (nups1 >= nups2)
				{
					Logger::printf("\n\n[XXX2] Debug 5");

					lua_clonecfunction(rl, 1);
					Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));

					Handler::set(cl1, Handler::get(cl2));
					cl1->c.cont = (lua_Continuation)cl2->c.cont;
					cl1->env = (Table*)cl2->env;

					for (int i = 0; i < nups2; i++)
						setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}

			else if (get_type(cl1) == module_c_wrap && get_type(cl2) == module_c_wrap)
			{
				Logger::printf("\n\n[XXX2] Debug 6");

				lua_clonecfunction(rl, 1);
				Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));

				Handler::wraps::set(clvalue(index2addr(rl, -1)), Handler::wraps::get(cl1));
				Handler::wraps::set(cl1, Handler::wraps::get(cl2));

				cl1->env = (Table*)cl2->env;
			}

			else if (get_type(cl1) == l_closure && get_type(cl2) == l_closure)
			{
				Logger::printf("\n\n[XXX2] Debug 7");

				if (nups1 >= nups2)
				{
					Logger::printf("\n\n[XXX2] Debug 8");

					lua_clonefunction(rl, 1);

					cl1->l.p = (Proto*)cl2->l.p;
					cl1->env = (Table*)cl2->env;

					for (int i = 0; i < nups2; i++)
						setobj2n(rl, &cl1->l.uprefs[i], &cl2->l.uprefs[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}

			else if (get_type(cl1) == roblox_c_closure && get_type(cl2) == module_c_closure)
			{
				//Logger::printf("\n\n[XXX2] Debug 9");

				if (nups1 >= nups2)
				{
					//Logger::printf("\n\n[XXX2] Debug 10");

					lua_clonecfunction(rl, 1);

					Handler::set(cl1, Handler::get(cl2));

					cl1->c.f = (lua_CFunction)cl2->c.f;
					cl1->c.cont = (lua_Continuation)cl2->c.cont;
					cl1->env = (Table*)cl2->env;

					for (int i = 0; i < nups2; i++)
						setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}

			else if (get_type(cl1) == roblox_c_closure && get_type(cl2) == module_c_wrap)
			{
				//Logger::printf("\n\n[XXX2] Debug 11");

				lua_clonecfunction(rl, 1);

				Handler::set(cl1, Handler::get(cl2));
				Handler::wraps::set(cl1, Handler::wraps::get(cl2));

				cl1->c.f = (lua_CFunction)cl2->c.f;
				cl1->c.cont = (lua_Continuation)cl2->c.cont;
				cl1->env = (Table*)cl2->env;

				Logger::printf("\n\n[XXX3] SUCKED THE COCK");
			}

			else if (get_type(cl1) == roblox_c_closure && get_type(cl2) == l_closure)
			{
				//Logger::printf("\n\n[XXX2] Debug 12");

				lua_clonecfunction(rl, 1);
				lua_ref(rl, 2);

				cl1->c.f = (lua_CFunction)Handler::cfunction_handler;
				Handler::set(cl1, newcclosure_handler);
				Handler::wraps::set(cl1, cl2);
			}

			else if (get_type(cl1) == module_c_closure && get_type(cl2) == roblox_c_closure)
			{
				Logger::printf("\n\n[XXX2] Debug 13");

				if (nups1 >= nups2)
				{
					Logger::printf("\n\n[XXX2] Debug 14");

					lua_clonecfunction(rl, 1);
					Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));

					cl1->env = (Table*)cl2->env;
					cl1->c.f = (lua_CFunction)cl2->c.f;
					cl1->c.cont = (lua_Continuation)cl2->c.cont;

					for (int i = 0; i < nups2; i++)
						setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}

			else if (get_type(cl1) == module_c_closure && get_type(cl2) == module_c_wrap)
			{
				Logger::printf("\n\n[XXX2] Debug 15");

				lua_clonecfunction(rl, 1);
				Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));

				Handler::set(cl1, newcclosure_handler);
				Handler::wraps::set(cl1, cl2);
			}

			else if (get_type(cl1) == module_c_closure && get_type(cl2) == l_closure)
			{
				Logger::printf("\n\n[XXX2] Debug 16");

				lua_clonecfunction(rl, 1);
				Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));
				lua_ref(rl, 2);

				Handler::set(cl1, newcclosure_handler);
				Handler::wraps::set(cl1, cl2);
			}

			else if (get_type(cl1) == module_c_wrap && get_type(cl2) == roblox_c_closure)
			{
				Logger::printf("\n\n[XXX2] Debug 17");

				if (nups1 >= nups2)
				{
					Logger::printf("\n\n[XXX2] Debug 18");

					lua_clonecfunction(rl, 1);
					Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));
					Handler::wraps::set(clvalue(index2addr(rl, -1)), Handler::wraps::get(cl1));

					cl1->env = (Table*)cl2->env;
					cl1->c.f = (lua_CFunction)cl2->c.f;
					cl1->c.cont = (lua_Continuation)cl2->c.cont;

					for (int i = 0; i < nups2; i++)
						setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}

			else if (get_type(cl1) == module_c_wrap && get_type(cl2) == module_c_closure)
			{
				Logger::printf("\n\n[XXX2] Debug 20");

				if (nups1 >= nups2)
				{
					Logger::printf("\n\n[XXX2] Debug 21");

					lua_clonecfunction(rl, 1);
					Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));
					Handler::wraps::set(clvalue(index2addr(rl, -1)), Handler::wraps::get(cl1));

					Handler::set(cl1, Handler::get(cl2));

					cl1->env = (Table*)cl2->env;
					cl1->c.cont = (lua_Continuation)cl2->c.cont;

					for (int i = 0; i < nups2; i++)
						setobj2n(rl, &cl1->c.upvals[i], &cl2->c.upvals[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}

			else if (get_type(cl1) == module_c_wrap && get_type(cl2) == l_closure)
			{
				Logger::printf("\n\n[XXX2] Debug 22");

				lua_clonecfunction(rl, 1);
				Handler::set(clvalue(index2addr(rl, -1)), Handler::get(cl1));
				Handler::wraps::set(clvalue(index2addr(rl, -1)), Handler::wraps::get(cl1));

				lua_ref(rl, 2);
				Handler::wraps::set(cl1, cl2);
			}

			else if (get_type(cl1) == l_closure && get_type(cl2) == roblox_c_closure || get_type(cl2) == module_c_closure)
			{
				Logger::printf("\n\n[XXX2] Debug 23");

				lua_clonefunction(rl, 1);
				const auto& spoof = Luau::compile("local f = function() end; return f(...); ");
				luau_load(rl, cl1->l.p->source->data, spoof.c_str(), spoof.size(), 0);

				Closure* clspoof = clvalue(index2addr(rl, -1));
				setobj(rl, &clspoof->l.p->k[0], index2addr(rl, 2));
				clspoof->l.p->linedefined = (__int64)cl1->l.p->linedefined;
				cl1->l.p = (Proto*)clspoof->l.p;

				lua_pop(rl, 1);
			}

			else if (get_type(cl1) == l_closure && get_type(cl2) == module_c_wrap)
			{
				Logger::printf("\n\n[XXX2] Debug 24");

				const Closure* l = Handler::wraps::get(cl2);

				if (nups1 >= l->nupvalues)
				{
					Logger::printf("\n\n[XXX2] Debug 25");

					lua_clonefunction(rl, 1);

					cl1->env = (Table*)l->env;
					cl1->l.p = (Proto*)l->l.p;

					for (int i = 0; i < l->nupvalues; i++)
						setobj2n(rl, &cl1->l.uprefs[i], &l->l.uprefs[i]);
				}
				else
					luaL_error(rl, "Too many upvalues");
			}
			else
				luaL_error(rl, "Failed to hook");

			Logger::printf("gulp gulp?");

			return 1;
		}


		auto iscclosure(lua_State* rl) -> int
		{
			luaL_checktype(rl, 1, LUA_TFUNCTION);

			lua_pushboolean(rl, lua_iscfunction(rl, 1));
			return 1;
		}

		auto islclosure(lua_State* rl) -> int
		{
			luaL_checktype(rl, 1, LUA_TFUNCTION);

			lua_pushboolean(rl, lua_isLfunction(rl, 1));
			return 1;
		}

		auto checkcaller(lua_State* rl) -> int
		{
			const auto script_ptr = *(std::uintptr_t*)((std::uintptr_t)((rl->userdata)) + 0x50);

			lua_pushboolean(rl, !script_ptr);
			return 1;
		}

		int loadstring(lua_State* L) {
			B();

			const char* src = luaL_checklstring(L, 1, nullptr);

			const char* name = luaL_optlstring(L, 2, A("=Nova"), nullptr);

			std::string source = std::string(src);

			std::string chunk_name = std::string(name);

			return Execution::Lua_LoadString(L, source, chunk_name);
		}
	}

	namespace Scripts {

		


		namespace HelpFunctions {

			std::unordered_map<std::string, std::pair<std::uint64_t, bool>> allCapabilities = { {"Plugin", {0x1, false}},
																							   {"LocalUser", {0x2, false}},
																							   {"WritePlayer", {0x4, false}},
																							   {"RobloxScript", {0x8, false}},
																							   {"RobloxEngine", {0x10, false}},
																							   {"NotAccessible", {0x20, false}},
																							   {"RunClientScript", {0x8, true}},
																							   {"RunServerScript", {0x9, true}},
																							   {"AccessOutsideWrite", {0xb, true}},
																							   {"Unassigned", {0xf, true}},
																							   {"AssetRequire", {0x10, true}},
																							   {"LoadString", {0x11, true}},
																							   {"ScriptGlobals", {0x12, true}},
																							   {"CreateInstances", {0x13, true}},
																							   {"Basic", {0x14, true}},
																							   {"Audio", {0x15, true}},
																							   {"DataStore", {0x16, true}},
																							   {"Network", {0x17, true}},
																							   {"Physics", {0x18, true}},
																							   {"UI", {0x19, true}},
																							   {"CSG", {0x1a, true}},
																							   {"Chat", {0x1b, true}},
																							   {"Animation", {0x1c, true}},
																							   {"Avatar", {0x1d, true}},
																							   {"Input", {0x1e, true}},
																							   {"Environment", {0x1f, true}},
																							   {"RemoteEvent", {0x20, true}},
																							   {"LegacySound", {0x21, true}},
																							   {"PluginOrOpenCloud", {0x3d, true}},
																							   {"Assistant", {0x3e, true}} };

			std::unordered_map<std::int32_t, std::list<std::string>> identityCapabilities = {
					{3,
					 {"RunServerScript", "Plugin", "LocalUser", "RobloxScript", "RunClientScript", "AccessOutsideWrite", "Avatar",
					  "RemoteEvent", "Environment", "Input", "LegacySound"}},
					{2, {"CSG", "Chat", "Animation", "RemoteEvent", "Avatar", "LegacySound"}},
					{4, {"Plugin", "LocalUser", "RemoteEvent", "Avatar", "LegacySound"}},
					{6,
					 {"RunServerScript", "Plugin", "LocalUser", "Avatar", "RobloxScript", "RunClientScript", "AccessOutsideWrite",
					  "Input", "Environment", "RemoteEvent", "PluginOrOpenCloud", "LegacySound"}},
					{8,
					 {"Plugin",
					  "LocalUser",
					  "WritePlayer",
					  "RobloxScript",
					  "RobloxEngine",
					  "NotAccessible",
					  "RunClientScript",
					  "RunServerScript",
					  "AccessOutsideWrite",
					  "Unassigned",
					  "AssetRequire",
					  "LoadString",
					  "ScriptGlobals",
					  "CreateInstances",
					  "Basic",
					  "Audio",
					  "DataStore",
					  "Network",
					  "Physics",
					  "UI",
					  "CSG",
					  "Chat",
					  "Animation",
					  "Avatar",
					  "Input",
					  "Environment",
					  "RemoteEvent",
					  "PluginOrOpenCloud",
					  "Assistant", "LegacySound"}} };

			uint64_t IdentityToCapabilities(const std::uint32_t identity) {
				std::uint64_t capabilities =
					0x3FFFFFF00ull | (1ull << 48ull);

				if (const auto capabilitiesForIdentity = identityCapabilities.find(identity);
					capabilitiesForIdentity != identityCapabilities.end()) {
					for (const auto& capability : capabilitiesForIdentity->second) {
						if (auto it = allCapabilities.find(capability); it != allCapabilities.end()) {
							if (it->second.second == true) {
								capabilities |= (1ull << it->second.first);
								continue;
							}

							capabilities |= it->second.first;
						}
						else {
							Logger::printf("Couldnt find Capabilities");
						}
					}
				}

				return capabilities;
			}

			std::optional<std::string> GetScriptBytecodeHandler(lua_State* L, void* udata, bool shouldDecompress) {
				std::uintptr_t script = (uintptr_t)udata;
				uintptr_t class_descriptor = *reinterpret_cast<uintptr_t*>(script + 0x18);
				std::string class_name = **reinterpret_cast<std::string**>(class_descriptor + 0x8);

				std::optional<std::string> protected_bytecode;

				if (!strcmp(class_name.c_str(), "ModuleScript")) {
					auto compressed_bytecode = *reinterpret_cast<std::string*>(*reinterpret_cast<std::uintptr_t*>(script + Offsets::ModuleScriptBytecode) + 0x10);

					if (shouldDecompress) {
						return decompress(compressed_bytecode);;
					}
					else {
						return compressed_bytecode;
					}
				}

				if (!strcmp(class_name.c_str(), "LocalScript")) {
					auto compressed_bytecode = *reinterpret_cast<std::string*>(*reinterpret_cast<std::uintptr_t*>(script + Offsets::LocalScriptBytecode) + 0x10);


					if (shouldDecompress) {
						return decompress(compressed_bytecode);;
					}
					else {
						return compressed_bytecode;
					}
				}

				return protected_bytecode;
			}
		}

		int getidentity(lua_State* L) {
			const auto ExtraSpace = (uintptr_t)L->userdata;

			lua_pushnumber(L, *(__int64*)(ExtraSpace + Offsets::Identity));

			return 1;
		}

		int setidentity(lua_State* L) {
			const auto newIdentity = lua_tonumber(L, 1);
			uintptr_t newCapabilities = HelpFunctions::IdentityToCapabilities(newIdentity);

			*(__int64*)((uintptr_t)L->userdata + Offsets::Identity) = newIdentity;
			*(__int64*)((uintptr_t)L->userdata + Offsets::Capabilities) = newCapabilities;

			return 0;
		}

		int getgenv(lua_State* L)
		{
			lua_pushvalue(L, LUA_ENVIRONINDEX);
			return 1;
		}

		int getreg(lua_State* L)
		{
			lua_pushvalue(L, LUA_REGISTRYINDEX);
			return 1;
		}

		int getgc(lua_State* L) {
			const bool addTables = luaL_optboolean(L, 1, false);
			lua_newtable(L);

			typedef struct {
				lua_State* pLua;
				bool accessTables;
				int itemsFound;
			} GCOContext;

			auto gcCtx = GCOContext{ L, addTables, 0 };

			const auto ullOldThreshold = L->global->GCthreshold;
			L->global->GCthreshold = SIZE_MAX;

			luaM_visitgco(L, &gcCtx, [](void* ctx, lua_Page* pPage, GCObject* pGcObj) -> bool {
				const auto pCtx = static_cast<GCOContext*>(ctx);
				const auto ctxL = pCtx->pLua;

				if (isdead(ctxL->global, pGcObj))
					return false;

				if (const auto gcObjType = pGcObj->gch.tt;
					gcObjType == LUA_TFUNCTION || gcObjType == LUA_TUSERDATA || gcObjType == LUA_TBUFFER ||
					gcObjType == LUA_TLIGHTUSERDATA || gcObjType == LUA_TTABLE && pCtx->accessTables) {

					ctxL->top->value.gc = pGcObj;
					ctxL->top->tt = gcObjType;
					ctxL->top++;

					const auto tIndx = pCtx->itemsFound++;
					lua_rawseti(ctxL, -2, tIndx + 1);
				}
				return false;
				});
			L->global->GCthreshold = ullOldThreshold;

			return 1;
		}

		int gettenv(lua_State* L) {
			luaL_checktype(L, 1, LUA_TTHREAD);
			lua_State* ls = (lua_State*)lua_topointer(L, 1);
			Table* tab = hvalue(luaA_toobject(ls, LUA_GLOBALSINDEX));

			sethvalue(L, L->top, tab);
			L->top++;

			return 1;
		}

		int getrenv(lua_State* L) {
			setobj(L, L->top, index2addr(L->global->mainthread, LUA_GLOBALSINDEX));
			incr_top(L);
			return 1;
		}
		
		int gethui(lua_State* L)
		{
			lua_getglobal(L, ("cloneref"));
			lua_getglobal(L, ("game"));
			lua_call(L, 1, 1);
			lua_getfield(L, -1, ("GetService"));
			lua_pushvalue(L, -2);
			lua_pushstring(L, ("CoreGui"));
			lua_call(L, 2, 1);
			lua_remove(L, 1); // CoreGui is alone on the stack.
			lua_getglobal(L, ("cloneref"));
			lua_pushvalue(L, 1);
			lua_call(L, 1, 1);
			lua_getfield(L, -1, ("RobloxGui"));
			lua_getglobal(L, ("cloneref"));
			lua_pushvalue(L, -2);
			lua_call(L, 1, 1);
			return 1;
		}

		auto setclipboard(lua_State* rl) -> int
		{
			luaL_checktype(rl, 1, LUA_TSTRING);

			std::string content = lua_tostring(rl, 1);

			HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, content.size() + 1);
			memcpy(GlobalLock(hMem), content.data(), content.size());
			GlobalUnlock(hMem);
			OpenClipboard(0);
			EmptyClipboard();
			SetClipboardData(CF_TEXT, hMem);
			CloseClipboard();
			return 0;
		}

		auto getclipboard(lua_State* rl) -> int
		{
			OpenClipboard(NULL);
			std::string clipboard = reinterpret_cast<char*>(GetClipboardData(CF_TEXT));

			lua_pushlstring(rl, clipboard.data(), clipboard.length());
			return 1;
		}

		auto identifyexecutor(lua_State* rl) -> int
		{
			lua_pushstring(rl, A("Nova"));
			lua_pushstring(rl, ("1.0"));
			return 2;
		}

		std::mutex teleport_mutex;

		int queue_on_teleport(lua_State* L) {
			const auto script = luaL_checkstring(L, 1);

			std::unique_lock< std::mutex > locker{ teleport_mutex };

			Environment::teleport_queue_script.push(script);

			return 0;
		}

		int setfps(lua_State* L) {
			luaL_checktype(L, 1, LUA_TNUMBER);

			double fps = lua_tonumber(L, 1);

			*reinterpret_cast<int32_t*>(Offsets::TaskSchedulerTargetFps) = fps;

			return 0;
		}

		int getfps(lua_State* L) {
			std::optional<double> fps = *reinterpret_cast<int32_t*>(Offsets::TaskSchedulerTargetFps);

			if (fps.has_value()) {
				lua_pushnumber(L, fps.value());
			}
			else {
				lua_pushnumber(L, 0);
			}

			return 1;
		}

		auto getcallingscript(lua_State* rl) -> int
		{
			B();

			uintptr_t userdata = *reinterpret_cast<uintptr_t*>((__int64)rl + 120);
			__int64 scriptptr = *reinterpret_cast<uintptr_t*>(userdata + 0x50);

			if (scriptptr > 0) {
				Logger::printf("Test: %p", scriptptr);
				Offsets::rbx_pushinstance((__int64)rl, reinterpret_cast<__int64*>(userdata + 0x50));
			}
			else {
				Logger::printf("FUCK");
				lua_pushnil(rl);
			}

			

			return 1;
		}

		int getobjects(lua_State* L) {
			B();

			luaL_checktype(L, 1, LUA_TUSERDATA);
			luaL_checktype(L, 2, LUA_TSTRING);

			lua_getglobal(L, ("game"));
			lua_getfield(L, -1, ("GetService"));

			lua_pushvalue(L, -2);
			lua_pushstring(L, ("InsertService"));
			lua_pcall(L, 2, 1, 0);

			lua_getfield(L, -1, ("LoadLocalAsset"));

			lua_pushvalue(L, -2);
			lua_pushvalue(L, 2);
			lua_pcall(L, 2, 1, 0);

			if (lua_type(L, -1) == LUA_TSTRING) {
				luaL_error(L, lua_tostring(L, -1));
			}

			lua_createtable(L, 0, 0);

			lua_pushvalue(L, -2);
			lua_rawseti(L, -2, 1);

			return 1;
		}

		auto getsenv(lua_State* L) -> int {
			luaL_checktype(L, 1, LUA_TUSERDATA);
			uintptr_t script_instance = *(uintptr_t*)lua_touserdata(L, 1);

			lua_getglobal(L, ("typeof"));
			lua_pushvalue(L, 1);
			lua_call(L, 1, 1);
			const bool isInstance = (strcmp(lua_tolstring(L, -1, 0), ("Instance")) == 0);
			lua_pop(L, 1);

			if (!isInstance)
				luaL_argerror(L, 1, ("Expected Instance"));

			lua_getfield(L, 1, ("ClassName"));
			const char* class_name = lua_tolstring(L, -1, NULL);

			lua_pop(L, 1);

			//lua_settop(L, 0);

			if (strcmp(class_name, "LocalScript") && strcmp(class_name, "ModuleScript")) {
				luaL_argerror(L, 1, ("LocalScript or ModuleScript"));
			}

			if (!strcmp(class_name, "LocalScript")) {
				auto node = *reinterpret_cast<Node_t**>(script_instance + 0x198);

				if (node == nullptr)
				{
					lua_pushnil(L);
					return 1;
				}

				auto wtr = node->wtr;
				if (wtr == nullptr)
				{
					lua_pushnil(L);
					return 1;
				}

				for (auto it = wtr; it; it = it->next)
				{
					auto thref = it->liveThreadRef;
					if (thref == nullptr)
					{
						continue;
					}

					auto thread = thref->th;
					if (thread == nullptr)
					{
						continue;
					}

					const auto extraspace = reinterpret_cast<int64_t>(lua_getthreaddata(thread));

					uintptr_t thread_scr;

					if (extraspace)
					{
						thread_scr = *(uintptr_t*)(extraspace + 0x50);
					}

					if (thread_scr)
					{
						if (script_instance == thread_scr)
						{
							lua_pushvalue(thread, LUA_GLOBALSINDEX);
							lua_xmove(thread, L, 1);
							return 1;
						}
					}
					else
					{
						continue;
					}
				}
			}
			else if (!strcmp(class_name, "ModuleScript")) {
				+
					lua_getglobal(L, "getfenv");
				{
					*(bool*)(Offsets::EnableLoadModule) = true;

					lua_getglobal(L, "debug");
					lua_getfield(L, -1, "loadmodule");
					{
						lua_pushvalue(L, 1);
					}
					lua_call(L, 1, 1);
					lua_remove(L, -2);

					*(bool*)(Offsets::EnableLoadModule) = false;
				}
				lua_call(L, 1, 1);

				if (!lua_isnoneornil(L, -1))
				{
					return 1;
				}
			}

			lua_pushnil(L);
			return 1;
		}

		int getrunningscripts(lua_State* L) {
			std::map< uintptr_t, bool > map;

			lua_pushvalue(L, LUA_REGISTRYINDEX);

			lua_newtable(L);

			lua_pushnil(L);

			auto c = 0u;
			while (lua_next(L, -3))
			{
				if (lua_isthread(L, -1))
				{
					const auto thread = lua_tothread(L, -1);

					if (thread)
					{
						if (const auto script_ptr = reinterpret_cast<std::uintptr_t>(thread->userdata) + 0x50; *reinterpret_cast<std::uintptr_t*>(script_ptr))
						{
							if (map.find(*(uintptr_t*)script_ptr) == map.end())
							{
								map.insert({ *(uintptr_t*)script_ptr, true });

								Offsets::PushInstance(L, (void*)script_ptr);

								lua_rawseti(L, -4, ++c);
							}
						}
					}
				}

				lua_pop(L, 1);
			}

			return 1;
		}

		auto firetouchinterest(lua_State* rl) -> int
		{
			luaL_checktype(rl, 1, LUA_TUSERDATA);
			luaL_checktype(rl, 2, LUA_TUSERDATA);

			if (lua_type(rl, 3) != LUA_TNUMBER && lua_type(rl, 3) != LUA_TBOOLEAN) {
				luaL_error(rl, "invalid type at argument 3");
				return 0;
			}

			uintptr_t part = *(uintptr_t*)lua_touserdata(rl, 1);
			uintptr_t transmitter = *(uintptr_t*)lua_touserdata(rl, 2);
			int state = lua_tointeger(rl, 3);

			uintptr_t part_primitive = *reinterpret_cast<uintptr_t*>(part + 352);
			uintptr_t transmitter_primitive = *reinterpret_cast<uintptr_t*>(transmitter + 352);

			if (!part_primitive || !transmitter_primitive || *(uintptr_t*)(part_primitive + 464) != *(uintptr_t*)(transmitter_primitive + 464))
				luaL_error(rl, "new overlap in different world.");

			Offsets::Touch(*reinterpret_cast<uintptr_t*>(part_primitive + 464), part_primitive, transmitter_primitive, state);
			return 0;
		}

		auto fireclickdetector(lua_State* rl) -> int
		{
			luaL_checktype(rl, 1, LUA_TUSERDATA);

			uintptr_t click_detector = *reinterpret_cast<uintptr_t*>(lua_touserdata(rl, 1));
			float distance = lua_tonumber(rl, 2);

			lua_getglobal(rl, "game");
			lua_getfield(rl, -1, "GetService");
			lua_pushvalue(rl, -2);
			lua_pushstring(rl, "Players");
			lua_pcall(rl, 2, 1, 0);
			lua_getfield(rl, -1, "LocalPlayer");

			uintptr_t local_player = *reinterpret_cast<uintptr_t*>(lua_touserdata(rl, -1));
			Offsets::ClickDetector(click_detector, distance, local_player);
			return 0;
		}

		auto fireproximityprompt(lua_State* rl) -> int
		{
			luaL_checktype(rl, 1, LUA_TUSERDATA);

			lua_getglobal(rl, ("typeof"));
			lua_pushvalue(rl, 1);
			lua_call(rl, 1, 1);
			const bool isInstance = (strcmp(lua_tolstring(rl, -1, 0), ("Instance")) == 0);
			lua_pop(rl, 1);

			if (!isInstance)
				luaL_argerror(rl, 1, ("Expected Instance"));

			lua_getfield(rl, 1, ("IsA"));
			lua_pushvalue(rl, 1);
			lua_pushstring(rl, ("ProximityPrompt"));
			lua_call(rl, 2, 1);
			const bool isExpectedClass = lua_toboolean(rl, -1);
			lua_pop(rl, 1);

			if (!isExpectedClass)
				luaL_argerror(rl, 1, ("Expected an ProximityPrompt"));


			reinterpret_cast<int(__thiscall*)(std::uintptr_t)>(Offsets::FireProximityPrompt)(*reinterpret_cast<std::uintptr_t*>(lua_touserdata(rl, 1)));
			return 0;
		}

		std::optional<std::string> GetScriptBytecodeHandler(lua_State* L, void* udata, bool shouldDecompress) {
			std::uintptr_t script = (uintptr_t)udata;
			uintptr_t class_descriptor = *reinterpret_cast<uintptr_t*>(script + 0x18);
			std::string class_name = **reinterpret_cast<std::string**>(class_descriptor + 0x8);

			std::optional<std::string> protected_bytecode;

			if (!strcmp(class_name.c_str(), "ModuleScript")) {
				auto compressed_bytecode = *reinterpret_cast<std::string*>(*reinterpret_cast<std::uintptr_t*>(script + Offsets::ModuleScriptBytecode) + 0x10);

				if (shouldDecompress) {
					return decompress(compressed_bytecode);;
				}
				else {
					return compressed_bytecode;
				}
			}

			if (!strcmp(class_name.c_str(), "LocalScript")) {
				auto compressed_bytecode = *reinterpret_cast<std::string*>(*reinterpret_cast<std::uintptr_t*>(script + Offsets::LocalScriptBytecode) + 0x10);


				if (shouldDecompress) {
					return decompress(compressed_bytecode);;
				}
				else {
					return compressed_bytecode;
				}
			}

			return protected_bytecode;
		}

		int getscriptbytecode(lua_State* L) {
			luaL_checktype(L, 1, LUA_TUSERDATA);

			auto script = *static_cast<void**>(lua_touserdata(L, 1));

			auto protected_bytecode = GetScriptBytecodeHandler(L, script, true);

			if (protected_bytecode.has_value()) {
				auto bytecode = protected_bytecode.value();

				lua_pushlstring(L, bytecode.data(), bytecode.size());

				return 1;
			}

			luaL_error(L, "Expected a LocalScript/ModuleScript");
		}

		int getcallbackvalue(lua_State* L)
		{
			luaL_stackcheck(L, 2, 2);

			luaL_checktype(L, 1, LUA_TUSERDATA);
			luaL_checktype(L, 2, LUA_TSTRING);

			auto Instance = *(uintptr_t*)lua_touserdata(L, 1);

			int Atom;
			auto Property = lua_tostringatom(L, 2, &Atom);

			const auto KTable = (uintptr_t*)Offsets::KTable;
			auto Descriptor = KTable[Atom];
			if (!Descriptor)
				return 0;

			auto ClassDescriptor = *(uintptr_t*)(Instance + 0x18);
			const auto Prop = Offsets::GetProperty(ClassDescriptor + 0x3b0, &Descriptor);
			if (!Prop)
				return 0;

			int Index = *(uint32_t*)(*(uintptr_t*)(*(uintptr_t*)(*(uintptr_t*)((Instance + *(uintptr_t*)(*Prop + 0x78)) + 0x18) + 0x38) + 0x28) + 0x14);
			lua_getref(L, Index);

			if (lua_isfunction(L, -1))
				return 1;

			lua_pop(L, 1);

			return 0;
		}

		static uintptr_t Caps = 0xFFFFFFFFFFFFFFFF;

		int getscriptclosure(lua_State* L) {
			luaL_checktype(L, 1, LUA_TUSERDATA);

			auto script = *static_cast<void**>(lua_touserdata(L, 1));

			auto protected_bytecode = GetScriptBytecodeHandler(L, script, false);

			if (protected_bytecode.has_value()) {
				auto bytecode = protected_bytecode.value();

				if (bytecode.empty()) {
					lua_pushnil(L);

					return 1;
				}

				if (Offsets::LuaVM_Load(L, &bytecode, A("@Nova"), 0) != LUA_OK) {
					lua_pushnil(L);
				}

				auto* pClosure = const_cast<Closure*>(static_cast<const Closure*>(lua_topointer((lua_State*)L, -1)));

				Execution::SetProtoCaps(pClosure->l.p, &Caps);

				return 1;
			}

			return 0;
		}

		int lz4compress(lua_State* L) {
			luaL_checktype(L, 1, LUA_TSTRING);
			const char* data = lua_tostring(L, 1);
			int nMaxCompressedSize = LZ4_compressBound(strlen(data));
			char* out_buffer = new char[nMaxCompressedSize];

			LZ4_compress(data, out_buffer, strlen(data));
			lua_pushlstring(L, out_buffer, nMaxCompressedSize);
			return 1;
		}

		int lz4decompress(lua_State* L) {
			luaL_checktype(L, 1, LUA_TSTRING);
			luaL_checktype(L, 2, LUA_TNUMBER);
			const char* data = lua_tostring(L, 1);
			int data_size = lua_tointeger(L, 2);

			char* pszUnCompressedFile = new char[data_size];

			LZ4_uncompress(data, pszUnCompressedFile, data_size);
			lua_pushlstring(L, pszUnCompressedFile, data_size);
			return 1;
		}

		int decompile(lua_State* L) {
			luaL_checktype(L, 1, LUA_TUSERDATA);

			lua_getglobal(L, ("typeof"));
			lua_pushvalue(L, 1);
			lua_call(L, 1, 1);
			const bool isInstance = (strcmp(lua_tolstring(L, -1, 0), ("Instance")) == 0);
			lua_pop(L, 1);

			if (!isInstance)
				luaL_argerror(L, 1, ("Expected Instance"));


			uintptr_t script = *reinterpret_cast<uintptr_t*>(lua_touserdata(L, 1));
			const char* classname = *reinterpret_cast<const char**>(*reinterpret_cast<uintptr_t*>(script + 0x18) + 0x8);

			int bytecodeSize{ 0 };

			if (strcmp(classname, "LocalScript") == 0)
				bytecodeSize = *reinterpret_cast<int*>(*reinterpret_cast<uintptr_t*>(script + Offsets::LocalScriptBytecode) + 0x20);
			else if (strcmp(classname, "ModuleScript") == 0)
				bytecodeSize = *reinterpret_cast<int*>(*reinterpret_cast<uintptr_t*>(script + Offsets::ModuleScriptBytecode) + 0x20);
			else {

				luaL_error(L, "LocalScripts/ModuleScripts expected");
				return 0;
			}


			std::uintptr_t bytecodePtr{};

			if (strcmp(classname, "LocalScript") == 0)
				bytecodePtr = *reinterpret_cast<std::uintptr_t*>(*reinterpret_cast<uintptr_t*>(script + Offsets::LocalScriptBytecode) + 0x10);
			else if (strcmp(classname, "ModuleScript") == 0)
				bytecodePtr = *reinterpret_cast<std::uintptr_t*>(*reinterpret_cast<uintptr_t*>(script + Offsets::ModuleScriptBytecode) + 0x10);
			else {
				luaL_error(L, "failed to get bytecode pointer");
				return 0;
			}

			std::string bytecodeBuffer;
			bytecodeBuffer.resize(bytecodeSize);

			unsigned char* bytecodeData = (unsigned char*)(bytecodePtr);

			std::memcpy(bytecodeBuffer.data(), bytecodeData, bytecodeSize);

			const std::string bytecode = decompress(bytecodeBuffer);

			std::string encoded;
			CryptoPP::StringSource(bytecode, true,
				new CryptoPP::Base64Encoder(
					new CryptoPP::StringSink(encoded),
					false
				)
			);

			return Scheduler::YieldExecution(L, [encoded]() -> auto {
				cpr::Response response = cpr::Post(
					cpr::Url{ ("http://176.96.137.54:8000/process") },
					cpr::Body{ nlohmann::json{{"bytecode", encoded.data()}}.dump() },
					cpr::Header{ {"Content-Type", ("application/octet-stream")} },
					cpr::VerifySsl{ false }
				);

				return [response](lua_State* L) -> int {
					if (response.status_code == 200) {
						lua_pushstring(L, response.text.c_str());
					}
					else {
						lua_pushstring(L, "-- FAILED TO DECOMPILE");
					}
					return 1;
					};
				});
		}

	}

	namespace WebSocket {
		class exploit_websocket {
		public:
			lua_State* th = nullptr;
			bool connected = false;
			ix::WebSocket* webSocket;
			int onMessageRef;
			int onCloseRef;
			int threadRef;

			auto fireMessage(std::string message) -> void {
				if (!connected)
					return;

				lua_getref(th, onMessageRef);
				lua_getfield(th, -1, "Fire");
				lua_getref(th, onMessageRef);
				lua_pushlstring(th, message.c_str(), message.size());
				lua_pcall(th, 2, 0, 0);
				lua_settop(th, 0);
			}

			auto fireClose() -> void {
				if (!connected)
					return;

				connected = false;

				lua_getref(th, onCloseRef);
				lua_getfield(th, -1, "Fire");
				lua_getref(th, onCloseRef);
				lua_pcall(th, 1, 0, 0);
				lua_settop(th, 0);

				lua_unref(th, onMessageRef);
				lua_unref(th, onCloseRef);
				lua_unref(th, threadRef);
			}

			int handleIndex(lua_State* ls)
			{
				luaL_checktype(ls, 1, LUA_TUSERDATA);
				if (!connected)
					return 0;

				std::string idx = luaL_checkstring(ls, 2);

				if (idx == "OnMessage") {
					lua_getref(ls, this->onMessageRef);
					lua_getfield(ls, -1, "Event");
					return 1;
				}
				else if (idx == "OnClose") {
					lua_getref(ls, this->onCloseRef);
					lua_getfield(ls, -1, "Event");
					return 1;
				}
				else if (idx == "Send") {
					lua_pushvalue(ls, -10003);
					lua_pushcclosure(ls,
						[](lua_State* L) -> int {
							luaL_checktype(L, 1, LUA_TUSERDATA);
							std::string data = luaL_checkstring(L, 2);

							exploit_websocket* webSocket = reinterpret_cast<exploit_websocket*>(lua_touserdata(L, -10003));
							webSocket->webSocket->send(data, true);
							return 0;
						}, ("websocketinstance_send"), 1);

					return 1;
				}
				else if (idx == "Close") {
					lua_pushvalue(ls, -10003);
					lua_pushcclosure(ls,
						[](lua_State* L) -> int {
							luaL_checktype(L, 1, LUA_TUSERDATA);

							exploit_websocket* webSocket = reinterpret_cast<exploit_websocket*>(lua_touserdata(L, -10003));
							webSocket->webSocket->close();
							return 0;
						}, ("websocketinstance_close"), 1);
					return 1;
				}
				return 0;
			};
		};

		static int websocket_connect(lua_State* ls)
		{
			std::string url = luaL_checkstring(ls, 1);
			exploit_websocket* webSocket = (exploit_websocket*)lua_newuserdata(ls, sizeof(exploit_websocket));
			*webSocket = exploit_websocket{ };

			webSocket->th = lua_newthread(ls);
			webSocket->threadRef = lua_ref(ls, -1);
			webSocket->webSocket = new ix::WebSocket();
			webSocket->webSocket->setUrl(url);
			lua_pop(ls, 1);

			lua_getglobal(ls, "Instance");
			lua_getfield(ls, -1, "new");
			lua_pushstring(ls, "BindableEvent");
			lua_pcall(ls, 1, 1, 0);
			webSocket->onMessageRef = lua_ref(ls, -1);
			lua_pop(ls, 2);

			lua_getglobal(ls, "Instance");
			lua_getfield(ls, -1, "new");
			lua_pushstring(ls, "BindableEvent");
			lua_pcall(ls, 1, 1, 0);
			webSocket->onCloseRef = lua_ref(ls, -1);
			lua_pop(ls, 2);

			webSocket->webSocket->setOnMessageCallback(
				[webSocket](const ix::WebSocketMessagePtr& msg) -> void {
					if (msg->type == ix::WebSocketMessageType::Message) {
						webSocket->fireMessage(msg->str);
					}
					else if (msg->type == ix::WebSocketMessageType::Close || msg->type == ix::WebSocketMessageType::Error) {
						webSocket->fireClose();
					}
					return;
				}
			);

			lua_newtable(ls);
			lua_pushstring(ls, "WebSocket");
			lua_setfield(ls, -2, "__type");

			lua_pushvalue(ls, -2);
			lua_pushcclosure(ls,
				[](lua_State* L) -> int {
					exploit_websocket* webSocket = reinterpret_cast<exploit_websocket*>(lua_touserdata(L, lua_upvalueindex(1)));
					return webSocket->handleIndex(L);
				},
				("__index"), 1);
			lua_setfield(ls, -2, "__index");
			lua_setmetatable(ls, -2);

			webSocket->webSocket->connect(5);

			if (webSocket->webSocket->getReadyState() != ix::ReadyState::Open) {
				luaL_error(ls, "failed to connect to websocket");
			}

			webSocket->connected = true;
			webSocket->webSocket->start();
			return 1;
		}
	}

	namespace Input {

		auto get_proc_id(const char* name) -> int {
			PROCESSENTRY32 entry;
			entry.dwSize = sizeof(PROCESSENTRY32);

			HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);

			if (Process32First(snapshot, &entry) == TRUE)
			{
				while (Process32Next(snapshot, &entry) == TRUE)
				{
					if (_stricmp(entry.szExeFile, name) == 0)
					{
						CloseHandle(snapshot);
						return entry.th32ProcessID;
					}
				}
			}

			CloseHandle(snapshot);
			return 0;
		}

		__forceinline auto roblox_active() -> bool {
			int proc_id = get_proc_id("RobloxPlayerBeta.exe");
			HWND foreground = GetForegroundWindow();

			DWORD fproc_id;
			GetWindowThreadProcessId(foreground, &fproc_id);

			return (fproc_id == proc_id);
		}

		int isrbxactive(lua_State* rl)
		{
			HWND window;
			window = FindWindowA(NULL, "Roblox");
			lua_pushboolean(rl, GetForegroundWindow() == window);
			return 1;
		}

		__forceinline auto keypress(lua_State* L) -> int {
			L, 1, 1, luaL_checktype(L, 1, LUA_TNUMBER);
			UINT key = lua_tointeger(L, 1);

			if (roblox_active())
				keybd_event(0, (BYTE)MapVirtualKeyA(key, MAPVK_VK_TO_VSC), KEYEVENTF_SCANCODE, 0);

			return 0;
		}

		std::int32_t keytap(lua_State* L) {
			L, 1, 1, luaL_checktype(L, 1, LUA_TNUMBER);
			UINT key = lua_tointeger(L, 1);

			if (!roblox_active())
				return 0;

			keybd_event(0, MapVirtualKeyA(key, MAPVK_VK_TO_VSC), KEYEVENTF_SCANCODE, 0);
			keybd_event(0, MapVirtualKeyA(key, MAPVK_VK_TO_VSC), KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP, 0);

			return 0;
		};

		__forceinline auto keyrelease(lua_State* L) -> int {
			luaL_checktype(L, 1, LUA_TNUMBER);
			UINT key = lua_tointeger(L, 1);

			if (roblox_active())
				keybd_event(0, (BYTE)MapVirtualKeyA(key, MAPVK_VK_TO_VSC), KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP, 0);

			return 0;
		}

		__forceinline auto mouse1click(lua_State* L) -> int {
			if (roblox_active())
				mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);

			return 0;
		}

		__forceinline auto mouse1press(lua_State* L) -> int {

			if (roblox_active())
				mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);

			return 0;
		}

		__forceinline auto mouse1release(lua_State* L) -> int {

			if (roblox_active())
				mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);

			return 0;
		}

		__forceinline auto mouse2click(lua_State* L) -> int {

			if (roblox_active())
				mouse_event(MOUSEEVENTF_RIGHTDOWN | MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);

			return 0;
		}

		__forceinline auto mouse2press(lua_State* L)
		{
			if (roblox_active())
				mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0);

			return 0;
		}

		__forceinline auto mouse2release(lua_State* L) -> int {

			if (roblox_active())
				mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);

			return 0;
		}

		__forceinline auto mousemoveabs(lua_State* L) -> int {
			luaL_checktype(L, 1, LUA_TNUMBER);
			luaL_checktype(L, 2, LUA_TNUMBER);

			int x = lua_tointeger(L, 1);
			int y = lua_tointeger(L, 2);

			if (!roblox_active())
				return 0;

			int width = GetSystemMetrics(SM_CXSCREEN) - 1;
			int height = GetSystemMetrics(SM_CYSCREEN) - 1;

			RECT CRect;
			GetClientRect(GetForegroundWindow(), &CRect);

			POINT Point{ CRect.left, CRect.top };
			ClientToScreen(GetForegroundWindow(), &Point);

			x = (x + Point.x) * (65535 / width);
			y = (y + Point.y) * (65535 / height);

			mouse_event(MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE, x, y, 0, 0);
			return 0;
		}

		__forceinline auto mousemoverel(lua_State* L) -> int {
			luaL_checktype(L, 1, LUA_TNUMBER);
			luaL_checktype(L, 2, LUA_TNUMBER);

			int x = lua_tointeger(L, 1);
			int y = lua_tointeger(L, 2);

			if (roblox_active())
				mouse_event(MOUSEEVENTF_MOVE, x, y, 0, 0);

			return 0;
		}

		__forceinline auto mousescroll(lua_State* L) -> int {
			luaL_checktype(L, 1, LUA_TNUMBER);

			int amt = lua_tointeger(L, 1);

			if (roblox_active())
				mouse_event(MOUSEEVENTF_WHEEL, 0, 0, amt, 0);

			return 0;
		}

	}

	namespace Filesystem {
		namespace fs = std::filesystem;

		std::filesystem::path workspaceDir;
		std::filesystem::path assetsDir;

		namespace HelpFunctions {

			std::unordered_set<std::string> blacklistedExtensions = { ".csh", ".wsh", ".dll", ".bat", ".cmd", ".scr", ".vbs", ".js",
																	 ".ts",  ".wsf", ".msi", ".com", ".lnk", ".ps1", ".py", "vb", ".vbe",
																	 ".py3", ".pyc", ".pyw", ".vb", ".html", ".ws", ".psy", ".hta",
			};

			bool IsExtensionBlacklisted(const fs::path& path) {
				const auto extension = path.extension().string();
				return blacklistedExtensions.find(extension) != blacklistedExtensions.end();
			}

			bool IsPathSafe(const std::string& relativePath) {
				const fs::path base = fs::absolute(workspaceDir);
				const fs::path combined = base / relativePath;

				const fs::path normalizedBase = base.lexically_normal();
				const fs::path normalizedCombined = combined.lexically_normal();

				const auto baseStr = normalizedBase.string();
				const auto combinedStr = normalizedCombined.string();

				if (combinedStr.compare(0, baseStr.length(), baseStr) != 0)
					return false;

				std::string lowerRelativePath = relativePath;
				std::ranges::transform(lowerRelativePath, lowerRelativePath.begin(), ::tolower);

				if (lowerRelativePath.find("..") != std::string::npos)
					return false;

				if (IsExtensionBlacklisted(combined)) {
					return false;
				}

				return true;
			}

			__forceinline std::filesystem::path CheckPath(lua_State* L) {
				const auto relativePath = lua_tostring(L, 1);

				if (!IsPathSafe(relativePath))
					luaG_runerror(L, "attempt to escape directory or access a blacklisted file type");

				return workspaceDir / relativePath;
			}

			void Init() {

				wchar_t Path[MAX_PATH];
				wchar_t Path2[MAX_PATH];

				GetModuleFileNameW(Globals::DLL, Path, MAX_PATH);
				const auto currentDirectory = fs::path(std::wstring(Path)).parent_path();

				workspaceDir = currentDirectory / "workspace";

				GetModuleFileNameW(GetModuleHandle(NULL), Path2, MAX_PATH);

				std::filesystem::path fullPath(Path2);
				std::filesystem::path contentDir = fullPath.parent_path() / "content";
				if (!std::filesystem::exists(contentDir)) {
					std::filesystem::create_directory(contentDir);
				}
				std::filesystem::path gcaDir = contentDir / "gca";
				if (!std::filesystem::exists(gcaDir)) {
					std::filesystem::create_directory(gcaDir);
				}

				std::wstring gcaPath = gcaDir.wstring();
				assetsDir = gcaDir;

			}

		}

		int readfile(lua_State* L) {
			B();

			luaL_checkstring(L, 1);

			auto absolutePath = HelpFunctions::CheckPath(L);

			if (!fs::exists(absolutePath) || !fs::is_regular_file(absolutePath)) {
				luaG_runerror(L, "file doesnt exist");
			}

			std::ifstream file(absolutePath, std::ios::binary | std::ios::ate);
			if (!file.is_open()) {
				luaG_runerror(L, "failed to read file content");
			}

			std::streamsize size = file.tellg();
			file.seekg(0, std::ios::beg);
			std::vector<char> buffer(size);
			if (!file.read(buffer.data(), size)) {
				luaG_runerror(L, "failed to read file");
			}

			lua_pushlstring(L, buffer.data(), size);

			return 1;
		}

		int listfiles(lua_State* L) {
			B();

			luaL_checkstring(L, 1);

			auto absolutePath = HelpFunctions::CheckPath(L);

			if (!fs::exists(absolutePath) || !fs::is_directory(absolutePath)) {
				luaG_runerror(L, "folder doesn't exist");
			}

			lua_newtable(L);
			int currentIndex = 1;
			for (const auto& entry : fs::directory_iterator(absolutePath)) {
				lua_pushstring(L, entry.path().string().c_str());
				lua_rawseti(L, -2, currentIndex);
				currentIndex++;
			}

			return 1;
		}

		int writefile(lua_State* L) {
			B();

			luaL_checkstring(L, 1);
			luaL_checkstring(L, 2);

			auto absolutePath = HelpFunctions::CheckPath(L);
			size_t contentLength;
			auto fileContent = lua_tolstring(L, 2, &contentLength);

			if (fs::is_directory(absolutePath)) {
				luaG_runerror(L, "argument 1 is not a valid file");
			}

			fs::create_directories(absolutePath.parent_path());

			std::ofstream file(absolutePath, std::ios::binary | std::ios::beg);
			if (!file.is_open()) {
				luaG_runerror(L, "failed to open file");
			}

			file.write(fileContent, contentLength);
			if (file.fail()) {
				luaG_runerror(L, "failed to write content to file");
			}

			file.close();
			if (file.fail()) {
				luaG_runerror(L, "failed to close file");
			}

			return 0;
		}

		int appendfile(lua_State* L) {
			B();

			luaL_checkstring(L, 1);
			luaL_checkstring(L, 2);

			auto relativePath = lua_tostring(L, 1);
			auto contentToAppend = lua_tostring(L, 2);
			auto absolutePath = HelpFunctions::CheckPath(L);

			if (!fs::exists(absolutePath) || !fs::is_regular_file(absolutePath)) {
				luaG_runerror(L, "file doesn't exist");
			}

			lua_pushcfunction(L, readfile, "AppendFile");
			lua_pushstring(L, relativePath);
			lua_call(L, 1, 1);
			auto currentContent = _strdup(lua_tostring(L, -1));
			lua_pop(L, 1);
			auto newContent = std::format("{}{}", currentContent, contentToAppend).c_str();
			lua_pushcfunction(L, writefile, "AppendFile");
			lua_pushstring(L, relativePath);
			lua_pushstring(L, newContent);
			lua_call(L, 2, 0);

			return 0;
		}

		int makefolder(lua_State* L) {
			B();

			luaL_checkstring(L, 1);

			auto absolutePath = HelpFunctions::CheckPath(L);

			if (fs::is_directory(absolutePath)) {
				return 0;
			}

			if (fs::is_regular_file(absolutePath)) {
				luaG_runerror(L, "There is a file on this path!");
			}

			if (fs::exists(absolutePath)) {
				luaG_runerror(L, "There is already something on this path!");
			}

			fs::create_directories(absolutePath);
			return 0;
		}

		int isfile(lua_State* L) {
			B();

			luaL_checkstring(L, 1);

			auto absolutePath = HelpFunctions::CheckPath(L);

			lua_pushboolean(L, fs::exists(absolutePath) && fs::is_regular_file(absolutePath));
			return 1;
		}

		int isfolder(lua_State* L) {
			B();

			luaL_checkstring(L, 1);

			auto absolutePath = HelpFunctions::CheckPath(L);

			lua_pushboolean(L, fs::exists(absolutePath) && fs::is_directory(absolutePath));
			return 1;
		}

		int delfile(lua_State* L) {
			B();

			luaL_checkstring(L, 1);

			auto absolutePath = HelpFunctions::CheckPath(L);

			if (!fs::exists(absolutePath) || !fs::is_regular_file(absolutePath)) {
				luaG_runerror(L, "file doesn't exist!");
			}

			fs::remove(absolutePath);
			return 0;
		}

		int delfolder(lua_State* L) {

			B();
			luaL_checkstring(L, 1);

			auto absolutePath = HelpFunctions::CheckPath(L);

			if (!fs::exists(absolutePath) || !fs::is_directory(absolutePath)) {
				luaG_runerror(L, "folder doesn't exist");
			}

			fs::remove_all(absolutePath);
			return 0;
		}

		int loadfile(lua_State* L) {
			B();

			luaL_checkstring(L, 1);

			auto relativePath = lua_tostring(L, 1);
			auto absolutePath = HelpFunctions::CheckPath(L);
			const char* sectionName = "";
			if (!lua_isnil(L, 2)) {
				sectionName = lua_tostring(L, 2);
			}

			if (!fs::exists(absolutePath) || !fs::is_regular_file(absolutePath)) {
				luaG_runerror(L, "file doesn't exist");
			}

			auto close_file = [](FILE* f) { fclose(f); };
			auto holder = std::unique_ptr<FILE, decltype(close_file)>(fopen(absolutePath.string().c_str(), "rb"), close_file);

			if (!holder)
				return 0;

			FILE* f = holder.get();

			if (fseek(f, 0, SEEK_END) < 0)
				return 0;

			const long size = ftell(f);

			if (size < 0)
				return 0;

			if (fseek(f, 0, SEEK_SET) < 0)
				return 0;

			std::string res{};
			res.resize(size);
			fread(const_cast<char*>(res.data()), 1, size, f);

			return Execution::Lua_LoadString(L, res, "=Selene");
		}

		int getcustomasset(lua_State* L) {
			B();
			
			luaL_checktype(L, 1, LUA_TSTRING);

			std::string assetname = lua_tostring(L, 1);
			std::filesystem::path workspace_path = workspaceDir / assetname;
			std::filesystem::path asset_directory = assetsDir / workspace_path.filename();

			std::filesystem::copy_file(workspace_path, asset_directory, std::filesystem::copy_options::update_existing);
			lua_pushstring(L, std::string("rbxasset://gca/" + asset_directory.filename().string()).data());
			return 1;
		}

	}

	namespace Cache {

		int invalidate(lua_State* L) {
			luaL_checktype(L, 1, LUA_TUSERDATA);

			const auto rawUserdata = *static_cast<void**>(lua_touserdata(L, 1));

			lua_pushlightuserdata(L, (void*)Offsets::PushInstance);
			lua_gettable(L, LUA_REGISTRYINDEX);

			lua_pushlightuserdata(L, reinterpret_cast<void*>(rawUserdata));
			lua_pushnil(L);
			lua_settable(L, -3);

			return 0;
		}

		int replace(lua_State* L) {
			luaL_checktype(L, 1, LUA_TUSERDATA);
			luaL_checktype(L, 2, LUA_TUSERDATA);

			const auto rawUserdata = *static_cast<void**>(lua_touserdata(L, 1));

			lua_pushlightuserdata(L, (void*)Offsets::PushInstance);
			lua_gettable(L, LUA_REGISTRYINDEX);

			lua_pushlightuserdata(L, rawUserdata);
			lua_pushvalue(L, 2);
			lua_settable(L, -3);

			return 0;
		}

		int iscached(lua_State* L) {
			luaL_checktype(L, 1, LUA_TUSERDATA);

			const auto rawUserdata = *static_cast<void**>(lua_touserdata(L, 1));

			lua_pushlightuserdata(L, (void*)Offsets::PushInstance);
			lua_gettable(L, LUA_REGISTRYINDEX);

			lua_pushlightuserdata(L, rawUserdata);
			lua_gettable(L, -2);

			lua_pushboolean(L, lua_type(L, -1) != LUA_TNIL);
			return 1;
		}

		int cloneref(lua_State* L)
		{
			luaL_checktype(L, 1, LUA_TUSERDATA);

			const auto original_userdata = lua_touserdata(L, 1);
			if (!original_userdata) {
				luaL_error(L, "Invalid userdata passed to cloneref");
				return 0;
			}

			const auto returned_userdata = *reinterpret_cast<std::uintptr_t*>(original_userdata);
			if (returned_userdata == 0) {
				luaL_error(L, "Invalid address retrieved from original userdata");
				return 0;
			}

			lua_pushlightuserdata(L, reinterpret_cast<void*>(Offsets::PushInstance));

			lua_rawget(L, -10000);
			lua_pushlightuserdata(L, reinterpret_cast<void*>(returned_userdata));
			lua_rawget(L, -2);

			lua_pushlightuserdata(L, reinterpret_cast<void*>(returned_userdata));
			lua_pushnil(L);
			lua_rawset(L, -4);

			reinterpret_cast<void(__fastcall*)(lua_State*, void*)>(Offsets::PushInstance)(L, lua_touserdata(L, 1));

			lua_pushlightuserdata(L, reinterpret_cast<void*>(returned_userdata));
			lua_pushvalue(L, -3);
			lua_rawset(L, -5);

			return 1;
		}

		int compareinstances(lua_State* L) {
			luaL_checktype(L, 1, LUA_TUSERDATA);
			luaL_checktype(L, 2, LUA_TUSERDATA);

			uintptr_t instance_one = *reinterpret_cast<uintptr_t*>(lua_touserdata(L, 1));
			uintptr_t instance_two = *reinterpret_cast<uintptr_t*>(lua_touserdata(L, 2));

			lua_pushboolean(L, instance_one == instance_two);
			return 1;
		}

	}

	namespace Metatable
	{

		bool is_allowed_metamethod(const char* metamethod)
		{
			static const std::unordered_set<std::string> allowed_methods = {
				"__namecall",
				"__newindex",
				"__index"
			};
			return allowed_methods.find(metamethod) != allowed_methods.end();
		}

		int hookmetamethod(lua_State* state) {
			B();

			if (!lua_isuserdata(state, 1) && !lua_istable(state, 1)) {
				luaL_error(state, "Expected userdata or table as first argument.");
				return 0;
			}

			const char* metamethod = luaL_checkstring(state, 2);

			if (!lua_getmetatable(state, 1)) {
				luaL_error(state, "No metatable detected!");
				return 0;
			}

			Logger::printf("\n[XXX124] Method: %s\n", metamethod);

			lua_pushstring(state, metamethod);
			lua_rawget(state, -2);

			if (lua_isnil(state, -1)) {
				lua_pop(state, 1);
				luaL_error(state, "Invalid meta method");
				return 0;
			}

			if (!lua_isfunction(state, 3)) {
				luaL_error(state, "Need function at 3rd argument!");
				return 0;
			}

			lua_getglobal(state, "hookfunction");
			if (!lua_isfunction(state, -1)) {
				luaL_error(state, "hookfunction is not available in global environment.");
				return 0;
			}

			lua_pushvalue(state, -2);
			lua_pushvalue(state, 3);

			if (lua_pcall(state, 2, 1, 0) != LUA_OK) {
				luaL_error(state, "%s", lua_tostring(state, -1));
				return 0;
			}

			return 1;
		}

		int getrawmetatable(lua_State* L) {
			luaL_checkany(L, 1);

			if (!lua_getmetatable(L, 1)) {
				lua_pushnil(L);
			}

			return 1;
		}


		template< std::size_t sz >
		bool check_types(lua_State* state, int index, std::array< lua_Type, sz > arr)
		{
			for (auto i = 0u; i < sz; i++)
			{
				if (lua_type(state, index) == arr[i])
					return true;
			}

			return false;
		}

		int setrawmetatable(lua_State* L) {
			luaL_argexpected(L,
				lua_istable(L, 1) || lua_islightuserdata(L, 1) || lua_isuserdata(L, 1) ||
				lua_isbuffer(L, 1) || lua_isvector(L, 1),
				1, "table or userdata or vector or buffer");

			luaL_argexpected(L, lua_istable(L, 2) || lua_isnil(L, 2), 2, "table or nil");

			bool readonly = lua_getreadonly(L, 1);

			lua_setreadonly(L, 1, false);

			lua_setmetatable(L, 1);

			lua_setreadonly(L, 1, readonly);

			lua_pushvalue(L, 1);

			return 1;
		}


		auto isreadonly(lua_State* rl) -> int
		{
			lua_pushboolean(rl, lua_getreadonly(rl, 1));
			return 1;
		}


		auto getnamecallmethod(lua_State* rl) -> int
		{
			//B();

			if (auto namecall = rl->namecall)
			{
				lua_pushstring(rl, namecall->data);
				return 1;
			}
			return 0;
		}


		auto setnamecallmethod(lua_State* rl) -> int
		{
			rl->namecall = reinterpret_cast<TString*>(index2addr(rl, 1)->value.p);
			return 0;
		}


		auto setreadonly(lua_State* rl) -> int
		{
			luaL_checktype(rl, 2, LUA_TBOOLEAN);

			lua_setreadonly(rl, 1, lua_toboolean(rl, 2));
			return 0;
		}


		auto make_writable(lua_State* rl) -> int
		{
			lua_setreadonly(rl, 1, false);
			return 0;
		}


		auto make_readonly(lua_State* rl) -> int
		{
			lua_setreadonly(rl, 1, true);
			return 0;
		}
	}

	namespace Crypt {

		enum CryptModes
		{
			//AES
			AES_CBC,
			AES_CFB,
			AES_CTR,
			AES_OFB,
			AES_GCM,
			AES_EAX,

			//Blowfish
			BF_CBC,
			BF_CFB,
			BF_OFB
		};

		enum HashModes
		{
			//MD5
			MD5,

			//SHA1
			SHA1,

			//SHA2
			SHA224,
			SHA256,
			SHA384,
			SHA512,

			//SHA3
			SHA3_224,
			SHA3_256,
			SHA3_384,
			SHA3_512,
		};

		std::map<std::string, CryptModes> CryptTranslationMap = {
			//AES
			{ "aes-cbc", AES_CBC },
			{ "aes_cbc", AES_CBC },

			{ "aes-cfb", AES_CFB },
			{ "aes_cfb", AES_CFB },

			{ "aes-ctr", AES_CTR },
			{ "aes_ctr", AES_CTR },

			{ "aes-ofb", AES_OFB },
			{ "aes_ofb", AES_OFB },

			{ "aes-gcm", AES_GCM },
			{ "aes_gcm", AES_GCM },

			{ "aes-eax", AES_EAX },
			{ "aes_eax", AES_EAX },

			//Blowfish
			{ "blowfish-cbc", BF_CBC },
			{ "blowfish_cbc", BF_CBC },
			{ "bf-cbc", BF_CBC },
			{ "bf_cbc", BF_CBC },

			{ "blowfish-cfb", BF_CFB },
			{ "blowfish_cfb", BF_CFB },
			{ "bf-cfb", BF_CFB },
			{ "bf_cfb", BF_CFB },

			{ "blowfish-ofb", BF_OFB },
			{ "blowfish_ofb", BF_OFB },
			{ "bf-ofb", BF_OFB },
			{ "bf_ofb", BF_OFB },
		};

		std::map<std::string, HashModes> HashTranslationMap = {
			//MD5
			{ "md5", MD5 },

			//SHA1
			{ "sha1", SHA1 },

			//SHA2
			{ "sha224", SHA224 },
			{ "sha256", SHA256 },
			{ "sha384", SHA384 },
			{ "sha512", SHA512 },

			//SHA3
			{ "sha3-224", SHA3_224 },
			{ "sha3_224", SHA3_224 },
			{ "sha3-256", SHA3_256 },
			{ "sha3_256", SHA3_256 },
			{ "sha3-384", SHA3_384 },
			{ "sha3_384", SHA3_384 },
			{ "sha3-512", SHA3_512 },
			{ "sha3_512", SHA3_512 },
		};

		namespace HelpFunctions {

			std::string Base64Decode(const std::string& encoded_string)
			{
				std::string decoded;
				CryptoPP::StringSource ss(encoded_string, true,
					new CryptoPP::Base64Decoder(
						new CryptoPP::StringSink(decoded)
					));

				return decoded;
			}

			std::string Base64Encode(const byte* bytes_to_encode, size_t in_len)
			{
				std::string encoded;
				CryptoPP::StringSource ss(bytes_to_encode, in_len, true,
					new CryptoPP::Base64Encoder(
						new CryptoPP::StringSink(encoded),
						false
					));

				return encoded;
			}

			template<typename T>
			static __forceinline std::string hash_with_algo(const std::string& Input)
			{
				T Hash;
				std::string Digest;

				CryptoPP::StringSource SS(Input, true,
					new CryptoPP::HashFilter(Hash,
						new CryptoPP::HexEncoder(
							new CryptoPP::StringSink(Digest), false
						)));

				return Digest;
			}

			std::string random_string(int len) {
				static const char* chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZbcdefghijklmnopqrstuvwxyz";

				std::string str;
				str.reserve(len);

				for (int i = 0; i < len; ++i) {
					str += chars[rand() % (strlen(chars) - 1)];
				}

				return str;
			}

			void SplitString(std::string Str, std::string By, std::vector<std::string>& Tokens)
			{
				Tokens.push_back(Str);
				const auto splitLen = By.size();
				while (true)
				{
					auto frag = Tokens.back();
					const auto splitAt = frag.find(By);
					if (splitAt == std::string::npos)
						break;
					Tokens.back() = frag.substr(0, splitAt);
					Tokens.push_back(frag.substr(splitAt + splitLen, frag.size() - (splitAt + splitLen)));
				}
			}

			template<typename T>
			__forceinline std::string DecryptAuthenticatedWithAlgo(lua_State* L, const std::string& Ciphertext, const std::string& Key, const std::string& IV)
			{
				try
				{
					std::string Decrypted;

					T Decryptor;
					Decryptor.SetKeyWithIV((byte*)Key.c_str(), Key.size(), (byte*)IV.c_str(), IV.size());

					const auto Base = Base64Decode(Ciphertext);

					CryptoPP::AuthenticatedDecryptionFilter Adf(Decryptor,
						new CryptoPP::StringSink(Decrypted)
					);

					Adf.Put((const byte*)Base.data(), Base.size());
					Adf.MessageEnd();

					return Decrypted;
				}
				catch (CryptoPP::Exception& e)
				{
					luaL_error(L, e.what());
					return "";
				}
			}

			template<typename T>
			__forceinline std::string EncryptAuthenticatedWithAlgo(lua_State* L, const std::string& data, const std::string& key_size, const std::string& ivc_str)
			{
				try
				{
					std::string Encrypted;

					T Encryptor;
					Encryptor.SetKeyWithIV((byte*)key_size.c_str(), key_size.size(), (byte*)ivc_str.c_str(), ivc_str.size());

					CryptoPP::AuthenticatedEncryptionFilter Aef(Encryptor,
						new CryptoPP::StringSink(Encrypted)
					);

					Aef.Put((const byte*)data.data(), data.size());
					Aef.MessageEnd();

					return Base64Encode((unsigned char*)Encrypted.c_str(), Encrypted.size());
				}
				catch (CryptoPP::Exception& e)
				{
					luaL_error(L, e.what());
					return "";
				}
			}

		}

		int encrypt(lua_State* L) {
			luaL_stackcheck(L, 2, 2);
			std::string data = luaL_checklstring(L, 1, NULL);
			std::string key = luaL_checklstring(L, 2, NULL);

			CryptoPP::AutoSeededRandomPool Prng;
			byte IV[12];
			Prng.GenerateBlock(IV, 12);

			byte derived_key[32];
			CryptoPP::PKCS5_PBKDF2_HMAC<CryptoPP::SHA384> KDF;
			KDF.DeriveKey(derived_key, 32, 0, (byte*)key.c_str(), key.size(), NULL, 0, 10000);

			auto encrypted = HelpFunctions::EncryptAuthenticatedWithAlgo<CryptoPP::GCM<CryptoPP::AES>::Encryption>(L,
				std::string(data.c_str(), data.size()),
				std::string((const char*)derived_key, 32),
				std::string((const char*)IV, 12));

			encrypted += "|" + HelpFunctions::Base64Encode(IV, 12);
			encrypted = HelpFunctions::Base64Encode((byte*)encrypted.data(), encrypted.size());


			lua_pushlstring(L, encrypted.c_str(), encrypted.size());
			lua_pushlstring(L, reinterpret_cast<const char*>(IV), sizeof(IV));
			return 2;
		}

		int decrypt(lua_State* L) {
			luaL_stackcheck(L, 2, 2);
			std::string data = luaL_checklstring(L, 1, NULL);
			std::string key = luaL_checklstring(L, 2, NULL);

			byte DerivedKey[32];
			CryptoPP::PKCS5_PBKDF2_HMAC<CryptoPP::SHA384> KDF;
			KDF.DeriveKey(DerivedKey, 32, 0, (byte*)key.c_str(), key.size(), NULL, 0, 10000);

			std::vector<std::string> Split;
			HelpFunctions::SplitString(HelpFunctions::Base64Decode(data), "|", Split);

			if (Split.size() != 2) {
				luaL_argerror(L, 1, "Invalid encrypted string specified");
				return 0;
			}

			auto decrypted = HelpFunctions::DecryptAuthenticatedWithAlgo<CryptoPP::GCM<CryptoPP::AES>::Decryption>(L,
				Split.at(0),
				std::string((const char*)DerivedKey, 32),
				HelpFunctions::Base64Decode(Split.at(1)));


			lua_pushlstring(L, decrypted.c_str(), decrypted.size());
			return 1;
		}

		int generatebytes(lua_State* L) {
			luaL_stackcheck(L, 1, 1);
			int len = luaL_checkinteger(L, 1);

			if (len > 1024)
			{
				luaL_argerror(L, 1, "exceeded maximum size (1024)");
				return 0;
			}

			if (len < 0)
			{
				luaL_argerror(L, 1, "negative size specified");
				return 0;
			}

			std::string data = HelpFunctions::random_string(len);

			auto encoded = HelpFunctions::Base64Encode((unsigned char*)data.c_str(), data.size());
			lua_pushlstring(L, encoded.c_str(), encoded.size());

			return 1;
		}

		int generatekey(lua_State* L) {
			luaL_stackcheck(L, 0, 0);
			std::string data = HelpFunctions::random_string(32);

			auto encoded = HelpFunctions::Base64Encode((unsigned char*)data.c_str(), data.size());
			lua_pushlstring(L, encoded.c_str(), encoded.size());

			return 1;
		}

		int hash(lua_State* L) {
			luaL_stackcheck(L, 2, 2);
			std::string algo = luaL_checklstring(L, 2, NULL);
			std::string data = luaL_checklstring(L, 1, NULL);

			std::transform(algo.begin(), algo.end(), algo.begin(), tolower);

			if (!HashTranslationMap.count(algo))
			{
				Logger::printf("ALGO: %s", algo);
				luaL_argerror(L, 1, "non-existant hash algorithm");
				return 0;
			}

			const auto ralgo = HashTranslationMap[algo];

			std::string hash;

			if (ralgo == MD5) {
				hash = HelpFunctions::hash_with_algo<CryptoPP::MD5>(data);
			}
			else if (ralgo == SHA1) {
				hash = HelpFunctions::hash_with_algo<CryptoPP::SHA1>(data);
			}
			else if (ralgo == SHA224) {
				hash = HelpFunctions::hash_with_algo<CryptoPP::SHA224>(data);
			}
			else if (ralgo == SHA256) {
				hash = HelpFunctions::hash_with_algo<CryptoPP::SHA256>(data);
			}
			else if (ralgo == SHA384) {
				hash = HelpFunctions::hash_with_algo<CryptoPP::SHA384>(data);
			}
			else if (ralgo == SHA512) {
				hash = HelpFunctions::hash_with_algo<CryptoPP::SHA512>(data);
			}
			else if (ralgo == SHA3_224) {
				hash = HelpFunctions::hash_with_algo<CryptoPP::SHA3_224>(data);
			}
			else if (ralgo == SHA3_256) {
				hash = HelpFunctions::hash_with_algo<CryptoPP::SHA3_256>(data);
			}
			else if (ralgo == SHA3_384) {
				hash = HelpFunctions::hash_with_algo<CryptoPP::SHA3_384>(data);
			}
			else if (ralgo == SHA3_512) {
				hash = HelpFunctions::hash_with_algo<CryptoPP::SHA3_512>(data);
			}
			else {
				Logger::printf("ALGO: %s", algo);
				luaL_argerror(L, 1, "non-existant hash algorithm");
				return 0;
			}

			lua_pushlstring(L, hash.c_str(), hash.size());

			return 1;
		}

		int base64encode(lua_State* L) {
			luaL_stackcheck(L, 1, 1);
			std::string data = luaL_checklstring(L, 1, NULL);

			auto encoded = HelpFunctions::Base64Encode((unsigned char*)data.c_str(), data.size());
			lua_pushlstring(L, encoded.c_str(), encoded.size());

			return 1;
		}

		int base64decode(lua_State* L) {
			luaL_stackcheck(L, 1, 1);
			const auto data = luaL_checklstring(L, 1, NULL);

			auto decoded = HelpFunctions::Base64Decode(data);

			lua_pushlstring(L, decoded.c_str(), decoded.size());

			return 1;
		}

	}

	namespace HTTP {

		namespace HelpFunctions {
			__forceinline static std::optional<const std::string> GetHwid() {
				HW_PROFILE_INFO hwProfileInfo;
				if (!GetCurrentHwProfileA(&hwProfileInfo)) {
					return {};
				}

				CryptoPP::SHA256 sha256;
				unsigned char digest[CryptoPP::SHA256::DIGESTSIZE];
				sha256.CalculateDigest(digest, reinterpret_cast<unsigned char*>(hwProfileInfo.szHwProfileGuid),
					sizeof(hwProfileInfo.szHwProfileGuid));

				CryptoPP::HexEncoder encoder;
				std::string output;
				encoder.Attach(new CryptoPP::StringSink(output));
				encoder.Put(digest, sizeof(digest));
				encoder.MessageEnd();

				return output;
			}

		}

		int httpget(lua_State* L) {
			B();

			std::string url;

			if (!lua_isstring(L, 1)) {
				luaL_checkstring(L, 2);
				url = std::string(lua_tostring(L, 2));
			}
			else {
				url = std::string(lua_tostring(L, 1));
			}

			if (url.find("http://") == std::string::npos && url.find("https://") == std::string::npos) {
				luaL_argerror(L, 1, "Invalid protocol (expected 'http://' or 'https://')");
			}

			Logger::printf("HTTPGET -> CHECK 1: Start HTTP-Get for URL: %s\n", url.c_str());

			return Scheduler::YieldExecution(L, [url]() -> std::function<int(lua_State*)> {
				cpr::Header Headers;
				std::optional<std::string> job_id = r_get_jobid();
				using json = nlohmann::json;
				json sessionIdJson;

				if (job_id.has_value()) {
					sessionIdJson["GameId"] = job_id.value();
					sessionIdJson["PlaceId"] = job_id.value();
					Headers.insert({ "Roblox-Game-Id", job_id.value() });
				}
				else {
					sessionIdJson["GameId"] = "empty value";
					sessionIdJson["PlaceId"] = "empty value";
					Headers.insert({ "Roblox-Game-Id", "empty value" });
				}

				Headers.insert({ "User-Agent", "Roblox/WinInet" });
				Headers.insert({ "Roblox-Session-Id", sessionIdJson.dump() });
				Headers.insert({ "Accept-Encoding", "identity" });

				Logger::printf("HTTPGET -> CHECK 2: Sending request...\n");

				cpr::Response Result;
				try {
					Result = cpr::Get(cpr::Url{ url }, cpr::Header(Headers));
				}
				catch (const std::exception& e) {
					Logger::printf("HTTPGET -> ERROR: Exception during HTTP request: %s\n", e.what());
					return [e](lua_State* L) -> int {
						lua_pushstring(L, ("HttpGet failed: " + std::string(e.what())).c_str());
						return 1;
						};
				}

				Logger::printf("HTTPGET -> CHECK 3: HTTP request complete. Status code: %d\n", Result.status_code);

				return [Result](lua_State* L) -> int {
					try {
						if (Result.status_code == 0 || HttpStatus::IsError(Result.status_code)) {
							auto Error = std::format("HttpGet failed with status {} - {}", Result.status_code, Result.error.message);
							Logger::printf("HTTPGET -> ERROR: %s\n", Error.c_str());
							lua_pushstring(L, Error.c_str());
							return 1;
						}

						if (Result.status_code == 401) {
							lua_pushstring(L, "HttpGet failed with unauthorized access");
							return 1;
						}

						Logger::printf("HTTPGET -> CHECK 4: Received data, size: %zu\n", Result.text.size());

						lua_pushlstring(L, Result.text.data(), Result.text.size());

						Logger::printf("HTTPGET -> Still here welp");

						return 1;

						//Logger::printf("HTTPGET -> gone.");

					}
					catch (const std::exception& e) {
						Logger::printf("HTTPGET -> ERROR: Exception in Lua-State interaction: %s\n", e.what());
						lua_pushstring(L, "HttpGet failed");
						return 1;
					}
					catch (...) {
						Logger::printf("HTTPGET -> ERROR: Unknown exception in Lua-State interaction\n");
						lua_pushstring(L, "HttpGet failed");
						return 1;
					}
					};
				});
		}

		int request(lua_State* L) {
			B();

			luaL_checktype(L, 1, LUA_TTABLE);

			lua_getfield(L, 1, "Url");
			if (lua_type(L, -1) != LUA_TSTRING) {
				luaL_error(L, "Invalid or no 'Url' field specified in request table");
				return 0;
			}

			std::string Url = lua_tostring(L, -1);
			if (Url.find("http") != 0) {
				luaL_error(L, "Invalid protocol specified (expected 'http://' or 'https://')");
				return 0;
			}

			lua_pop(L, 1);

			auto Method = H_GET;
			lua_getfield(L, 1, "Method");

			if (lua_type(L, -1) == LUA_TSTRING) {
				std::string Methods = luaL_checkstring(L, -1);
				std::transform(Methods.begin(), Methods.end(), Methods.begin(), tolower);

				if (!RequestMethodMap.count(Methods)) {
					luaL_error(L, "request type '%s' is not a valid http request type.", Methods.c_str());
					return 0;
				}

				Method = RequestMethodMap[Methods];
			}

			lua_pop(L, 1);

			cpr::Header Headers;

			lua_getfield(L, 1, "Headers");
			if (lua_type(L, -1) == LUA_TTABLE) {
				lua_pushnil(L);

				while (lua_next(L, -2)) {
					if (lua_type(L, -2) != LUA_TSTRING || lua_type(L, -1) != LUA_TSTRING) {
						luaL_error(L, "'Headers' table must contain string keys/values.");
						return 0;
					}

					std::string HeaderKey = luaL_checkstring(L, -2);
					auto HeaderCopy = std::string(HeaderKey);
					std::ranges::transform(HeaderKey, HeaderKey.begin(), tolower);

					if (HeaderCopy == "content-length") {
						luaL_error(L, "Headers: 'Content-Length' header cannot be overwritten.");
						return 0;
					}

					std::string HeaderValue = luaL_checkstring(L, -1);
					Headers.insert({ HeaderKey, HeaderValue });
					lua_pop(L, 1);
				}
			}
			lua_pop(L, 1);

			cpr::Cookies Cookies;
			lua_getfield(L, 1, "Cookies");

			if (lua_type(L, -1) == LUA_TTABLE) {
				std::map<std::string, std::string> RobloxCookies;
				lua_pushnil(L);

				while (lua_next(L, -2)) {
					if (lua_type(L, -2) != LUA_TSTRING || lua_type(L, -1) != LUA_TSTRING) {
						luaL_error(L, "'Cookies' table must contain string keys/values.");
						return 0;
					}

					std::string CookieKey = luaL_checkstring(L, -2);
					std::string CookieValue = luaL_checkstring(L, -1);

					RobloxCookies[CookieKey] = CookieValue;
					lua_pop(L, 1);
				}

				Cookies = RobloxCookies;
			}

			lua_pop(L, 1);

			auto HasUserAgent = false;
			for (auto& Header : Headers) {
				auto HeaderName = Header.first;
				std::transform(HeaderName.begin(), HeaderName.end(), HeaderName.begin(), tolower);

				if (HeaderName == "user-agent")
					HasUserAgent = true;
			}

			if (!HasUserAgent) {
				Headers.insert({ "User-Agent", ("Selene/1.0") });
			}

			auto hwidd = HelpFunctions::GetHwid();

			if (hwidd.has_value()) {
				Headers.insert({ ("Selene-Fingerprint"), HelpFunctions::GetHwid().value() });
			}
			else {
				Headers.insert({ ("Selene-Fingerprint"), "fe8451e8fbfcc55408f4253c31ff15085832f96ab266a6a041b9ddf8bb77a627" });
			}

			std::optional<std::string> job_id = r_get_jobid();
			std::optional<uintptr_t> place_id = r_get_placeid();

			if (job_id.has_value()) {

				Headers.insert({ "Roblox-Game-Id", job_id.value() });
			}
			else {
				Headers.insert({ "Roblox-Game-Id", "empty value" });
			}

			using json = nlohmann::json;
			json sessionIdJson;

			if (job_id.has_value()) {
				sessionIdJson["GameId"] = job_id.value();
				sessionIdJson["PlaceId"] = job_id.value();
			}
			else {
				sessionIdJson["GameId"] = "empty value";
				sessionIdJson["PlaceId"] = "empty value";
			}

			Headers.insert({ "Roblox-Session-Id", sessionIdJson.dump() });

			std::string Body;
			lua_getfield(L, 1, "Body");
			if (lua_type(L, -1) == LUA_TTABLE) {
				if (Method == H_GET || Method == H_HEAD) {
					luaL_error(L, "'Body' cant be represent in Get or head requests");
					return 0;
				}

				Body = luaL_checkstring(L, -1);
			}

			lua_pop(L, 1);

			return Scheduler::YieldExecution(L,
				[Method, Url, Headers, Cookies, Body]() -> auto {
					cpr::Response Response;

					switch (Method) {
					case H_GET: {
						Response = cpr::Get(cpr::Url{ Url }, Cookies, Headers);
						break;
					}
					case H_HEAD: {
						Response = cpr::Head(cpr::Url{ Url }, Cookies, Headers);
						break;
					}
					case H_POST: {
						Response = cpr::Post(cpr::Url{ Url }, cpr::Body{ Body }, Cookies, Headers);
						break;
					}
					case H_PUT: {
						Response = cpr::Put(cpr::Url{ Url }, cpr::Body{ Body }, Cookies, Headers);
						break;
					}
					case H_DELETE: {
						Response = cpr::Delete(cpr::Url{ Url }, cpr::Body{ Body }, Cookies, Headers);
						break;
					}
					case H_OPTIONS: {
						Response = cpr::Options(cpr::Url{ Url }, cpr::Body{ Body }, Cookies, Headers);
						break;
					}
					default: {
						throw std::exception("invalid request type");
					}
					}

					return [Response](lua_State* L) -> int {

						lua_newtable(L);

						lua_pushboolean(L, HttpStatus::IsSuccessful(Response.status_code));
						lua_setfield(L, -2, "Success");

						lua_pushinteger(L, Response.status_code);
						lua_setfield(L, -2, "StatusCode");

						auto Phrase = HttpStatus::ReasonPhrase(Response.status_code);
						lua_pushlstring(L, Phrase.c_str(), Phrase.size());
						lua_setfield(L, -2, "StatusMessage");

						lua_newtable(L);

						for (auto& Header : Response.header) {
							lua_pushlstring(L, Header.first.c_str(), Header.first.size());
							lua_pushlstring(L, Header.second.c_str(), Header.second.size());

							lua_settable(L, -3);
						}

						lua_setfield(L, -2, "Headers");

						lua_newtable(L);

						for (auto& cookie : Response.cookies.map_) {
							lua_pushlstring(L, cookie.first.c_str(), cookie.first.size());
							lua_pushlstring(L, cookie.second.c_str(), cookie.second.size());

							lua_settable(L, -3);
						}

						lua_setfield(L, -2, "Cookies");

						lua_pushlstring(L, Response.text.c_str(), Response.text.size());
						lua_setfield(L, -2, "Body");

						return 1;
						};
				}
			);

			//return 0;
		}

	}

	namespace Debug {
		auto debug_header_getclosure(lua_State* ls, bool allowCclosure = false, bool popcl = true) -> Closure*
		{
			luaL_checkany(ls, 1);

			if (!(lua_isfunction(ls, 1) || lua_isnumber(ls, 1)))
			{
				luaL_argerror(ls, 1, ("function or number"));
			}

			int level = 0;
			if (lua_isnumber(ls, 1))
			{
				level = lua_tointeger(ls, 1);

				if (level <= 0)
				{
					luaL_argerror(ls, 1, ("invalid stack level."));
				}
			}
			else if (lua_isfunction(ls, 1))
			{
				level = -lua_gettop(ls);
			}

			lua_Debug ar;
			if (!lua_getinfo(ls, level, "f", &ar))
			{
				luaL_argerror(ls, 1, ("invalid stack level."));
			}

			if (!lua_isfunction(ls, -1))
			{
				luaL_argerror(ls, 1, ("stack does not point to a function."));
			}

			if (!allowCclosure && lua_iscfunction(ls, -1))
			{
				luaL_argerror(ls, 1, ("expected Lua Closure!"));
			}

			auto closure = clvalue(luaA_toobject(ls, -1));
			if (popcl) lua_pop(ls, 1);

			return closure;
		}

		static int debug_getupvalues(lua_State* ls)
		{
			const auto closure = debug_header_getclosure(ls, true, false);

			// Create a table with space for the number of upvalues ( if any )
			lua_createtable(ls, closure->nupvalues, 0);
			for (int i = 0; i < closure->nupvalues; i++)
			{
				if (lua_getupvalue(ls, -2, ++i)) lua_rawseti(ls, -2, i);
			}

			return 1;
		}

		static int debug_getupvalue(lua_State* ls)
		{
			const auto closure = debug_header_getclosure(ls, true, false);
			const auto idx = luaL_checkinteger(ls, 2);

			if (!(closure->nupvalues > 0))
			{
				luaL_argerror(ls, 1, ("function does not have upvalues."));
			}

			if (!(idx >= 1 && idx <= closure->nupvalues))
			{
				luaL_argerror(ls, 2, ("index out of range [1, nupvalues]."));
			}

			if (!lua_getupvalue(ls, -1, idx)) lua_pushnil(ls);
			return 1;
		}

		static int debug_setupvalue(lua_State* ls)
		{
			// dont allow this in C Functions
			const auto closure = debug_header_getclosure(ls, false, false);
			const auto idx = luaL_checkinteger(ls, 2);

			if (!(closure->nupvalues > 0))
			{
				luaL_argerror(ls, 1, ("function does not have upvalues."));
			}

			if (!(idx >= 1 && idx <= closure->nupvalues))
			{
				luaL_argerror(ls, 2, ("index out of range [1, nupvalues]."));
			}

			lua_pushvalue(ls, 3);
			lua_setupvalue(ls, -2, idx);
			return 1;
		}

		static int debug_getconstants(lua_State* rl)
		{
			luaL_checktype(rl, 1, LUA_TFUNCTION);

			const auto closure = clvalue(index2addr(rl, 1));

			if (!closure->isC) {
				lua_newtable(rl);

				for (auto i = 0; i < closure->l.p->sizek; ++i) {
					const auto constant = closure->l.p->k[i];

					if (constant.tt == LUA_TTABLE || constant.tt == LUA_TFUNCTION) {
						lua_pushnil(rl);
					}
					else {
						if (!lua_checkstack(rl, 1)) {
							Logger::printf("[XXX10] Stack overflow detected\n");
							luaL_error(rl, "Stack overflow while pushing constant");
							return 0;
						}
						setobj(rl, rl->top, &constant);
						rl->top++;
					}

					lua_rawseti(rl, -2, i + 1);
				}

			}
			else {
				luaL_error(rl, "expected Lclosure argument 1");
				return 0;
			}

			return 1;
		}

		static int debug_getconstant(lua_State* rl)
		{
			luaL_checktype(rl, 1, LUA_TFUNCTION);

			const auto closure = *reinterpret_cast<Closure**>(index2addr(rl, 1));

			if (!closure->isC) {
				const std::uint32_t index = lua_tonumber(rl, 2) - 1; // -1 cuz index is black
				const auto constant = closure->l.p->k[index];

				if (constant.tt == LUA_TTABLE || constant.tt == LUA_TFUNCTION)
					lua_pushnil(rl);
				else {
					rl->top->value = constant.value;
					rl->top->tt = constant.tt;

					rl->top++;
				}
			}
			else
				luaL_error(rl, "expected Lclosure argument 1");

			return 1;
		}

		static int debug_setconstant(lua_State* rl)
		{
			luaL_checktype(rl, 1, LUA_TFUNCTION);

			const auto closure = *reinterpret_cast<Closure**>(index2addr(rl, 1));

			if (!closure->isC) {
				const std::uint32_t index = lua_tonumber(rl, 2) - 1;
				const auto constant = &closure->l.p->k[index];

				setobj(rl, constant, index2addr(rl, 3));
			}

			return 0;
		}

		// Clones proto and returns the clone.
		// Only important information is cloned.
		auto debug_helper_clone_proto(lua_State* ls, Proto* proto) -> Proto*
		{
			// Make a new proto.
			// We gotta make new GCObjects for the proto.
			Proto* clone = luaF_newproto(ls);

			// Copy constants
			clone->sizek = proto->sizek;
			clone->k = luaM_newarray(ls, proto->sizek, TValue, proto->memcat);
			for (int j = 0; j < proto->sizek; ++j)
			{
				clone->k[j].tt = proto->k[j].tt;
				clone->k[j].value = proto->k[j].value;
			}

			clone->lineinfo = 0;
			clone->locvars = 0;
			clone->nups = 0;
			clone->sizeupvalues = 0;
			clone->sizelineinfo = 0;
			clone->linegaplog2 = 0;
			clone->sizelocvars = 0;
			clone->linedefined = 0;

			// Copy debugname and source, make new TStrings
			if (proto->debugname)
			{
				const auto debugname = getstr(proto->debugname);
				const auto sz = strlen(debugname);

				clone->debugname = luaS_newlstr(ls, debugname, sz);
			}

			if (proto->source)
			{
				const auto source = getstr(proto->source);
				const auto sz = strlen(source);

				clone->source = luaS_newlstr(ls, source, sz);
			}

			clone->numparams = proto->numparams;
			clone->is_vararg = proto->is_vararg;
			clone->maxstacksize = proto->maxstacksize;
			clone->bytecodeid = proto->bytecodeid;

			// Set the code to return nothing.
			clone->sizecode = 1;
			clone->code = luaM_newarray(ls, clone->sizecode, Instruction, proto->memcat);
			clone->code[0] = 0x10082; // RETURN [ insn, enc 227 ]
			clone->codeentry = clone->code;
			clone->debuginsn = 0;

			// Copy protos
			clone->sizep = proto->sizep;
			clone->p = luaM_newarray(ls, proto->sizep, Proto*, proto->memcat);
			for (int j = 0; j < proto->sizep; ++j)
			{
				clone->p[j] = debug_helper_clone_proto(ls, proto->p[j]);
			}

			return clone;
		}

		int debug_getprotos(lua_State* L) {
			luaL_argcheck(L, lua_isLfunction(L, 1) || lua_isnumber(L, 1), 1, "Expected lclosure or number");

			Closure* closure = (Closure*)lua_topointer(L, -1);

			lua_newtable(L);

			Proto* main_proto = closure->l.p;

			for (std::intptr_t i = 0; i < main_proto->sizep; i++) {
				Proto* proto_data = main_proto->p[i];
				Closure* lclosure = luaF_newLclosure(L, proto_data->nups, closure->env, proto_data);

				setclvalue(L, L->top, lclosure);
				L->top++;

				lua_rawseti(L, -2, (i + 1));
			}

			return 1;
		}

		int debug_getproto(lua_State* L) {
			luaL_checktype(L, 2, LUA_TNUMBER);

			bool active = false;
			if (lua_isboolean(L, 3))
			{
				active = lua_toboolean(L, 3);
			}

			if (lua_isnumber(L, 1) == false && lua_isfunction(L, 1) == false) {
				luaL_argerror(L, 1, "function or level expected");
			}

			if (lua_isnumber(L, 1)) {
				const int level = lua_tointeger(L, 1);

				if (level >= L->ci - L->base_ci || level < 0) {
					luaL_argerror(L, 1, "stack out of range.");
				}

				lua_Debug ar;
				if (!lua_getinfo(L, level, "f", &ar)) {
					luaL_error(L, "Failed to get information");
				}
			}
			else {
				luaL_checktype(L, 1, LUA_TFUNCTION);
				lua_pushvalue(L, 1);
			}

			Closure* cl = lua_toclosure(L, -1);

			if (cl->isC)
				luaL_argerrorL(L, 1, "level/func must point/be a Lua function");

			const auto closure = clvalue(luaA_toobject(L, -1));

			const auto index = lua_tointeger(L, 2);

			if (index < 1 || index > closure->l.p->sizep) {
				luaL_argerror(L, 2, "proto index out of range");
			}

			auto proto = closure->l.p->p[index - 1];

			if (active) {
				int index = 1;
				lua_newtable(L);

				global_State* g = L->global;
				const auto deadmask = otherwhite(g);

				struct gco_ctxt
				{
					lua_State* L;
					int n;

					int deadmask;
					Proto* pcl_p;

					std::vector<Closure*> functions;
				} ctxt = { L, index, deadmask, proto };

				luaM_visitgco(L, reinterpret_cast<void*>(&ctxt), [](void* context, lua_Page* page, GCObject* gco) -> bool
					{
						const auto ctxt = reinterpret_cast<gco_ctxt*>(context);
						const auto tt = gco->gch.tt;

						if (tt != LUA_TFUNCTION)
						{
							return false;
						}

						if ((gco->gch.marked ^ WHITEBITS) & ctxt->deadmask)
						{
							const auto cl = gco2cl(gco);
							if (!cl->isC)
							{
								if (cl->l.p == ctxt->pcl_p)
								{
									ctxt->L->top->value.gc = gco;
									ctxt->L->top->tt = tt;
									ctxt->L->top++;

									lua_rawseti(ctxt->L, -2, ctxt->n++);
								}
							}
						}

						return false;
					});

			}
			else
			{
				const auto clone = debug_helper_clone_proto(L, proto);
				Closure* pcl = luaF_newLclosure(L, closure->nupvalues, closure->env, clone);

				luaC_threadbarrier(L) setclvalue(L, L->top, pcl) L->top++;
			}

			return 1;
		}

		static int debug_getstack(lua_State* ls)
		{
			luaL_checkany(ls, 1);

			if (!(lua_isfunction(ls, 1) || lua_isnumber(ls, 1)))
			{
				luaL_argerror(ls, 1, ("function or number"));
			}

			int level = 0;
			if (lua_isnumber(ls, 1))
			{
				level = lua_tointeger(ls, 1);

				if (level <= 0)
				{
					luaL_argerror(ls, 1, ("invalid stack level."));
				}
			}
			else if (lua_isfunction(ls, 1))
			{
				level = -lua_gettop(ls);
			}

			lua_Debug ar;
			if (!lua_getinfo(ls, level, "f", &ar))
			{
				luaL_argerror(ls, 1, ("invalid stack level."));
			}

			if (!lua_isfunction(ls, -1))
			{
				luaL_argerror(ls, 1, ("stack does not point to a function."));
			}

			if (lua_iscfunction(ls, -1))
			{
				luaL_argerror(ls, 1, ("expected Lua Closure"));
			}

			lua_pop(ls, 1); // pop the closure since we dont need it

			auto ci = ls->ci[-level];

			if (lua_isnumber(ls, 2))
			{
				const auto idx = lua_tointeger(ls, 2) - 1;

				if (idx >= cast_int(ci.top - ci.base) || idx < 0)
				{
					luaL_argerror(ls, 2, ("Invalid stack index."));
				}

				auto val = ci.base + idx;
				luaC_threadbarrier(ls) luaA_pushobject(ls, val);
			}
			else
			{
				int idx = 0;
				lua_newtable(ls);

				for (auto val = ci.base; val < ci.top; val++)
				{
					lua_pushinteger(ls, idx++ + 1);

					luaC_threadbarrier(ls) luaA_pushobject(ls, val);

					lua_settable(ls, -3);
				}
			}

			return 1;
		}

		static int debug_setstack(lua_State* ls)
		{
			luaL_checkany(ls, 1);

			if (!(lua_isfunction(ls, 1) || lua_isnumber(ls, 1)))
			{
				luaL_argerror(ls, 1, ("function or number"));
			}

			int level = 0;
			if (lua_isnumber(ls, 1))
			{
				level = lua_tointeger(ls, 1);

				if (level <= 0)
				{
					luaL_argerror(ls, 1, ("invalid stack level."));
				}
			}
			else if (lua_isfunction(ls, 1))
			{
				level = -lua_gettop(ls);
			}

			lua_Debug ar;
			if (!lua_getinfo(ls, level, "f", &ar))
			{
				luaL_argerror(ls, 1, ("invalid stack level."));
			}

			if (!lua_isfunction(ls, -1))
			{
				luaL_argerror(ls, 1, ("stack does not point to a function."));
			}

			if (lua_iscfunction(ls, -1))
			{
				luaL_argerror(ls, 1, ("expected Lua Closure"));
			}

			lua_pop(ls, 1); 

			luaL_checkany(ls, 3);

			auto ci = ls->ci[-level];

			const auto idx = luaL_checkinteger(ls, 2) - 1;
			if (idx >= cast_int(ci.top - ci.base) || idx < 0)
			{
				luaL_argerror(ls, 2, ("Invalid stack index."));
			}

			if ((ci.base + idx)->tt != luaA_toobject(ls, 3)->tt)
			{
				luaL_argerror(ls, 3, ("Source type does not match the Target type."));
			}

			setobj2s(ls, (ci.base + idx), luaA_toobject(ls, 3))
				return 0;
		}

		static int debug_getinfo(lua_State* ls)
		{
			luaL_checkany(ls, 1);

			if (!(lua_isfunction(ls, 1) || lua_isnumber(ls, 1)))
			{
				luaL_argerror(ls, 1, ("function or number"));
			}

			int level;
			if (lua_isnumber(ls, 1))
			{
				level = lua_tointeger(ls, 1);
			}
			else
			{
				level = -lua_gettop(ls);
			}

			auto desc = lua_isstring(ls, 2) ? lua_tolstring(ls, 2, NULL) : "sluanf";

			lua_Debug ar;
			if (!lua_getinfo(ls, level, desc, &ar))
			{
				luaL_argerror(ls, 1, ("invalid stack level."));
			}

			if (!lua_isfunction(ls, -1))
			{
				luaL_argerror(ls, 1, ("stack does not point to a function."));
			}

			lua_newtable(ls);
			{
				if (std::strchr(desc, 's'))
				{
					lua_pushstring(ls, ar.source);
					lua_setfield(ls, -2, "source");

					lua_pushstring(ls, ar.short_src);
					lua_setfield(ls, -2, "short_src");

					lua_pushstring(ls, ar.what);
					lua_setfield(ls, -2, "what");

					lua_pushinteger(ls, ar.linedefined);
					lua_setfield(ls, -2, "linedefined");
				}

				if (std::strchr(desc, 'l'))
				{
					lua_pushinteger(ls, ar.currentline);
					lua_setfield(ls, -2, "currentline");
				}

				if (std::strchr(desc, 'u'))
				{
					lua_pushinteger(ls, ar.nupvals);
					lua_setfield(ls, -2, "nups");
				}

				if (std::strchr(desc, 'a'))
				{
					lua_pushinteger(ls, ar.isvararg);
					lua_setfield(ls, -2, "is_vararg");

					lua_pushinteger(ls, ar.nparams);
					lua_setfield(ls, -2, "numparams");
				}

				if (std::strchr(desc, 'n'))
				{
					lua_pushstring(ls, ar.name);
					lua_setfield(ls, -2, "name");
				}

				if (std::strchr(desc, 'f'))
				{
					lua_pushvalue(ls, -2);
					lua_remove(ls, -3);
					lua_setfield(ls, -2, "func");
				}
			}

			return 1;
		}

		static int debug_isvalidlevel(lua_State* ls)
		{
			int level = 0;
			if (lua_isnumber(ls, 1))
			{
				level = lua_tointeger(ls, 1);

				if (level <= 0)
				{
					luaL_argerror(ls, 1, ("invalid stack level."));
				}
			}
			else if (lua_isfunction(ls, 1))
			{
				level = -lua_gettop(ls);
			}

			lua_Debug ar;
			if (!lua_getinfo(ls, level, "f", &ar))
			{
				luaL_argerror(ls, 1, ("invalid stack level."));
			}

			lua_pushboolean(ls, lua_isfunction(ls, -1));
			return 1;
		}

		static int getcurrentline(lua_State* ls)
		{
			int level{ 1 };
			if (lua_isnumber(ls, 1))
			{
				level = lua_tointeger(ls, 1);

				if (level <= 0)
				{
					luaL_argerror(ls, 1, ("invalid stack level."));
				}
			}

			lua_Debug ar;
			if (!lua_getinfo(ls, level, "l", &ar))
			{
				luaL_argerror(ls, 1, ("invalid stack level."));
			}

			lua_pushinteger(ls, ar.currentline);
			return 1;
		}

		static int debug_getcallstack(lua_State* ls)
		{
			lua_State* thread = lua_isthread(ls, 1) ? lua_tothread(ls, 1) : ls;

			int idx = 1;
			lua_newtable(ls);
			{
				while (idx < lua_stackdepth(thread))
				{
					lua_Debug ar;
					lua_getinfo(thread, idx, "f", &ar);
					/*
					lua_newtable(ls);
					{
						lua_pushstring(ls, ar.source);
						lua_setfield(ls, -2, "source");

						lua_pushstring(ls, ar.short_src);
						lua_setfield(ls, -2, "short_src");

						lua_pushstring(ls, ar.what);
						lua_setfield(ls, -2, "what");

						lua_pushinteger(ls, ar.linedefined);
						lua_setfield(ls, -2, "linedefined");

						if ( strcmp(ar.what, "Lua") == 0 )
						{
							lua_pushinteger(ls, ar.currentline);
							lua_setfield(ls, -2, "currentline");
						}

						lua_pushinteger(ls, ar.nupvals);
						lua_setfield(ls, -2, "nups");

						lua_pushinteger(ls, ar.isvararg);
						lua_setfield(ls, -2, "is_vararg");

						lua_pushinteger(ls, ar.nparams);
						lua_setfield(ls, -2, "numparams");

						lua_pushstring(ls, ar.name);
						lua_setfield(ls, -2, "name");

						lua_pushvalue(thread, -2);
						lua_remove(thread, -3);
						lua_xmove(thread, ls, 1);
						lua_setfield(ls, -2, "func");
					}
					*/
					lua_xmove(thread, ls, 1);
					lua_rawseti(ls, -2, idx++);
				}
			}

			return 1;
		}
	}

	namespace Instance {

		template< class t >
		class c_storage
		{
			std::mutex m_l;

		protected:
			t m_container;
		public:

			auto safe_request(auto request, auto... args)
			{
				std::unique_lock l{ m_l };

				return request(args...);
			};

			void clear()
			{
				safe_request([&]()
					{ m_container.clear(); });
			}
		};

		using instance_cache_t
			= std::unordered_map< void*,
			std::unordered_map< std::string, bool > >;

		class c_instance_cache : public c_storage< instance_cache_t >
		{
		public:
			void toggle(void* instance, const std::string& prop, bool enabled)
			{
				safe_request([&]()
					{
						m_container[instance][prop] = enabled;
					});
			}

			std::optional< bool > is_scriptable(void* instance, const std::string& prop)
			{
				return safe_request([&]() -> std::optional< bool >
					{
						if (m_container.contains(instance))
						{
							const auto properties = m_container[instance];

							if (properties.contains(prop))
								return properties.at(prop);
						}

						return std::nullopt;
					});
			}
		} inline g_instance;

		__forceinline bool lua_isscriptable(lua_State* L, uintptr_t property)
		{
			auto scriptable = *reinterpret_cast<__int64*>(property + 64);
			return scriptable & 0x20;
		}

		__forceinline void lua_setscriptable(lua_State* L, uintptr_t property, bool enabled)
		{
			*reinterpret_cast<int*>(property + 64) = enabled ? 0xFF : 0;
		}

		auto getinstances(lua_State* rl) -> int
		{
			struct instance_context {
				lua_State* rl;
				std::intptr_t n;
			} context = { rl, 0 };

			lua_newtable(rl);
			for (lua_Page* page = rl->global->allgcopages; page;) {
				lua_Page* next{ page->listnext };

				luaM_visitpage(page, &context,
					[](void* context, lua_Page* page, GCObject* gco) -> bool {
						instance_context* gcContext{ reinterpret_cast<instance_context*>(context) };
						auto type = gco->gch.tt;

						if (type == LUA_TUSERDATA) {


							TValue* top = gcContext->rl->top;
							top->value.p = reinterpret_cast<void*>(gco);
							top->tt = type;
							gcContext->rl->top++;

							if (!strcmp(luaL_typename(gcContext->rl, -1), "Instance")) {
								gcContext->n++;
								lua_rawseti(gcContext->rl, -2, gcContext->n);
							}
							else {
								lua_pop(gcContext->rl, 1);
							}
						}

						return true;
					}
				);
				page = next;
			}
			return 1;
		}

		auto getnilinstances(lua_State* rl) -> int
		{
			struct instance_context {
				lua_State* rl;
				std::intptr_t n;
			} context = { rl, 0 };

			lua_newtable(rl);

			for (lua_Page* page = rl->global->allgcopages; page;) {
				lua_Page* next{ page->listnext };

				luaM_visitpage(page, &context,
					[](void* context, lua_Page* page, GCObject* gco) -> bool {
						instance_context* gcContext{ reinterpret_cast<instance_context*>(context) };
						auto type = gco->gch.tt;

						if (type == LUA_TUSERDATA) {


							TValue* top = gcContext->rl->top;
							top->value.p = reinterpret_cast<void*>(gco);
							top->tt = type;
							gcContext->rl->top++;

							if (!strcmp(luaL_typename(gcContext->rl, -1), "Instance")) {
								lua_getfield(gcContext->rl, -1, "Parent");
								bool nullParent = lua_isnoneornil(gcContext->rl, -1);

								if (nullParent) {
									lua_pop(gcContext->rl, 1);
									gcContext->n++;
									lua_rawseti(gcContext->rl, -2, gcContext->n);
								}
								else {
									lua_pop(gcContext->rl, 2);
								}
							}
							else {
								lua_pop(gcContext->rl, 1);
							}
						}

						return true;
					}
				);

				page = next;
			}
			return 1;
		}

		/*auto getloadedmodules(lua_State* rl) -> int
		{
			std::vector<std::shared_ptr<uintptr_t>> instances;

			const auto loaded_modules = *reinterpret_cast<std::set<std::weak_ptr<uintptr_t>>*>(Globals::ScriptContext + 1600 + 72);
			for (auto module : loaded_modules)
			{
				if (!module.expired())
				{
					instances.push_back(module.lock());
				}
			}

			lua_newtable(rl);

			for (int i = 0; i < instances.size(); i++)
			{
				lua_pushinteger(rl, i + 1);
				Offsets::rbx_e_pushinstance((__int64)rl, instances[i]);
				lua_settable(rl, -3);
			}

			return 1;
		}*/

		auto gethiddenproperty(lua_State* rl) -> int
		{
			luaL_checktype(rl, 1, LUA_TUSERDATA);
			luaL_checktype(rl, 2, LUA_TSTRING);

			uintptr_t instance = *reinterpret_cast<uintptr_t*>(lua_touserdata(rl, 1));
			std::string property_name = lua_tostring(rl, 2);

			uintptr_t object;
			bool found;
			std::vector<uintptr_t> properties = *reinterpret_cast<std::vector<uintptr_t>*>(*reinterpret_cast<uintptr_t*>(instance + 24) + 40);
			for (int i = 0; i < properties.size(); i++)
			{
				uintptr_t property = properties[i];
				if (property_name == *reinterpret_cast<std::string*>(*reinterpret_cast<uintptr_t*>(property + 8)))
				{
					object = property;

					found = true;
					break;
				}
			}

			if (found == false)
				luaL_error(rl, "Property not exists.");

			std::string propertyTypeName = *(std::string*)(*(uintptr_t*)(object + 0x48) + 0x8);

			int propertyType = *(int*)(*(uintptr_t*)(object + 0x48) + 0x30);
			if (!strcmp(propertyTypeName.c_str(), "BinaryString")) {
				*(int*)(*(uintptr_t*)(object + 0x48) + 0x30) = 6;
			}

			bool scriptable = lua_isscriptable(rl, object);
			int original_value = *reinterpret_cast<int*>(object + 64);
			if (scriptable == true)
			{
				lua_getfield(rl, 1, property_name.c_str());
				lua_pushboolean(rl, false);
				return 2;
			}
			else
			{
				lua_setscriptable(rl, object, true);
				lua_getfield(rl, 1, property_name.c_str());
				lua_pushboolean(rl, true);
				lua_setscriptable(rl, object, false);
				return 2;
			}
		}

		auto sethiddenproperty(lua_State* rl) -> int
		{
			luaL_checktype(rl, 1, LUA_TUSERDATA);
			luaL_checktype(rl, 2, LUA_TSTRING);

			uintptr_t instance = *reinterpret_cast<uintptr_t*>(lua_touserdata(rl, 1));
			std::string property_name = lua_tostring(rl, 2);

			uintptr_t object;
			bool found;
			std::vector<uintptr_t> properties = *reinterpret_cast<std::vector<uintptr_t>*>(*reinterpret_cast<uintptr_t*>(instance + 24) + 40);
			for (int i = 0; i < properties.size(); i++)
			{
				uintptr_t property = properties[i];
				if (property_name == *reinterpret_cast<std::string*>(*reinterpret_cast<uintptr_t*>(property + 8)))
				{
					object = property;
					found = true;
					break;
				}
			}

			if (found == false)
				luaL_error(rl, "Property not exists.");

			bool scriptable = lua_isscriptable(rl, object);
			int original_value = *reinterpret_cast<int*>(object + 64);
			if (scriptable == true)
			{
				lua_pushvalue(rl, 3);
				lua_setfield(rl, 1, property_name.c_str());
				lua_pushboolean(rl, false);
				lua_setscriptable(rl, object, false);
				return 1;
			}
			else
			{
				lua_setscriptable(rl, object, true);
				lua_pushvalue(rl, 3);
				lua_setfield(rl, 1, property_name.c_str());
				lua_pushboolean(rl, true);
				lua_setscriptable(rl, object, false);
				return 1;
			}
		}

		auto isscriptable(lua_State* rl) -> int
		{
			luaL_checktype(rl, 1, LUA_TUSERDATA);
			luaL_checktype(rl, 2, LUA_TSTRING);

			__int64 instance = *reinterpret_cast<__int64*>(lua_touserdata(rl, 1));
			void* instance2 = lua_touserdata(rl, 1);

			std::string property_name = lua_tostring(rl, 2);


			lua_getglobal(rl, ("typeof"));
			lua_pushvalue(rl, 1);
			lua_call(rl, 1, 1);
			const bool isInstance = (strcmp(lua_tolstring(rl, -1, 0), ("Instance")) == 0);
			lua_pop(rl, 1);

			if (!isInstance) {
				luaL_argerror(rl, 1, ("Expected Instance"));
				return 0;
			}

			__int64 property = 0;
			std::vector<__int64> properties = *reinterpret_cast<std::vector<__int64>*>(*reinterpret_cast<__int64*>(instance + 24) + 40);

			for (int i = 0; i < properties.size(); i++)
			{
				std::string prop_name = *reinterpret_cast<std::string*>(*reinterpret_cast<__int64*>(properties[i] + 8));
				if (prop_name == property_name)
				{
					property = properties[i];
					break;
				}
			}

			if (property == NULL)
				luaL_error(rl, "Property not exists.");

			const auto was_scriptable
				= g_instance.is_scriptable(instance2, property_name);

			lua_pushboolean(rl, was_scriptable.value_or(lua_isscriptable(rl, property)));
			return 1;
		}

		auto setscriptable(lua_State* rl)
		{
			luaL_checktype(rl, 1, LUA_TUSERDATA);
			luaL_checktype(rl, 2, LUA_TSTRING);
			luaL_checktype(rl, 3, LUA_TBOOLEAN);

			__int64 instance = *reinterpret_cast<__int64*>(lua_touserdata(rl, 1));
			void* instance2 = lua_touserdata(rl, 1);
			std::string property_name = lua_tostring(rl, 2);
			bool enabled = lua_toboolean(rl, 3);

			for (__int64 property : *reinterpret_cast<std::vector<__int64>*>(*reinterpret_cast<__int64*>(instance + 24) + 40))
			{
				std::string name = *reinterpret_cast<std::string*>(*reinterpret_cast<__int64*>(property + 8));
				if (name == property_name)
				{
					const auto was_scriptable = g_instance.is_scriptable(instance2, property_name);

					g_instance.toggle(instance2, property_name, enabled);

					lua_pushboolean(rl, was_scriptable.value_or(lua_isscriptable(rl, property)));
					return 1;
				}
			}
			luaL_error(rl, "property not found");
			return 0;
		}

		__forceinline int getscripts(lua_State* L) {
			struct instancecontext {
				lua_State* L;
				__int64 n;
			} Context = { L, 0 };

			lua_createtable(L, 0, 0);

			const auto ullOldThreshold = L->global->GCthreshold;
			L->global->GCthreshold = SIZE_MAX; // Disable GC temporarily

			luaM_visitgco(L, &Context, [](void* ctx, lua_Page* page, GCObject* gco) -> bool {
				auto gCtx = static_cast<instancecontext*>(ctx);
				const auto type = gco->gch.tt;

				if (isdead(gCtx->L->global, gco))
					return false;

				if (type == LUA_TUSERDATA) {

					TValue* top = gCtx->L->top;
					top->value.p = reinterpret_cast<void*>(gco);
					top->tt = type;
					gCtx->L->top++;

					if (!strcmp(luaL_typename(gCtx->L, -1), "Instance")) { // instance check
						lua_getfield(gCtx->L, -1, "ClassName"); // check if instance has no parent / basically nil instance

						const char* inst_class = lua_tolstring(gCtx->L, -1, 0);
						if (!strcmp(inst_class, "LocalScript") || !strcmp(inst_class, "ModuleScript"))
						{
							lua_pop(gCtx->L, 1);
							gCtx->n++;
							lua_rawseti(gCtx->L, -2, gCtx->n);
						}
						else
							lua_pop(gCtx->L, 2);

					}
					else {
						lua_pop(gCtx->L, 1);
					}
				}

				return true;
				});

			L->global->GCthreshold = ullOldThreshold;

			return 1;
		}

		auto getscripthash(lua_State* rl) -> int
		{
			luaL_checktype(rl, 1, LUA_TUSERDATA);

			uintptr_t script = *reinterpret_cast<uintptr_t*>(lua_touserdata(rl, 1));
			const char* classname = *reinterpret_cast<const char**>(*reinterpret_cast<uintptr_t*>(script + 24) + 8);
			std::string compressed_bytecode;

			if (strcmp(classname, "LocalScript") == 0)
				compressed_bytecode = *reinterpret_cast<std::string*>(*reinterpret_cast<uintptr_t*>(script + Offsets::LocalScriptBytecode) + 16);
			else if (strcmp(classname, "ModuleScript") == 0)
				compressed_bytecode = *reinterpret_cast<std::string*>(*reinterpret_cast<uintptr_t*>(script + Offsets::ModuleScriptBytecode) + 16);
			else
				luaL_error(rl, "Local/Module scripts expected.");

			auto decompressed = decompress(compressed_bytecode);

			std::string hash;
			CryptoPP::StringSource(decompressed, true,
				new CryptoPP::Base64Encoder(
					new CryptoPP::StringSink(hash),
					false
				)
			);

			lua_pushlstring(rl, hash.c_str(), hash.size());

			return 1;
		}







	}

	namespace Signals {

		struct connection_object {
			signal_t* signal;
			uint64_t state;
			uint64_t metatable;
			uint64_t root;
		};

		std::unordered_map<signal_t*, connection_object> connection_table;

		int connection_blank(lua_State* rl) {
			return 0;
		}

		int disable_connection(lua_State* rl) {
			auto connection = (connection_object*)lua_touserdata(rl, 1);
			if (connection->signal->state != 0)
				connection->state = connection->signal->state;

			connection->signal->state = 0;
			return 0;
		}

		int enable_connection(lua_State* rl) {
			auto connection = (connection_object*)lua_touserdata(rl, 1);
			connection->signal->state = connection->state;
			return 0;
		}

		int disconnect_connection(lua_State* rl) {
			auto connection = (connection_object*)lua_touserdata(rl, 1);
			auto root = (signal_t*)connection->root;
			if ((uint64_t)root == (uint64_t)connection) {
				luaL_error(rl, "Failed to disconnect.");
			}

			while (root->next && root->next != connection->signal) {
				root = root->next;
			}

			if (!root->next) {
				luaL_error(rl, "Already disconnected.");
			}

			root->next = root->next->next;
			connection->signal->state = 0;
			return 0;
		}

		int connection_index(lua_State* rl) {
			std::string key = std::string(lua_tolstring(rl, 2, nullptr));
			auto connection = (connection_object*)lua_touserdata(rl, 1);
			uintptr_t connection2 = *(uintptr_t*)lua_touserdata(rl, 1);

			if (key == "Enabled" || key == "enabled") {
				lua_pushboolean(rl, !(connection->signal->state == 0));
				return 1;
			}

			if (key == "Function" || key == "function" || key == "Fire" || key == "fire" || key == "Defer" || key == "defer") {
				int signal_data = *(int*)&connection->signal->signal_data;
				if (signal_data && *(int*)&connection->signal->signal_data->connection_data) {
					int index = connection->signal->signal_data->connection_data->func_idx;
					lua_rawgeti(rl, LUA_REGISTRYINDEX, index);

					if (lua_type(rl, -1) != LUA_TFUNCTION)
						lua_pushcclosure(rl, connection_blank, 0, 0, 0);

					return 1;
				}

				lua_pushcclosure(rl, connection_blank, 0, 0, 0);
				return 1;
			}

			if (key == "LuaConnection") {
				int signal_data = *(int*)&connection->signal->signal_data;
				if (signal_data && *(int*)&connection->signal->signal_data->connection_data) {
					int index = connection->signal->signal_data->connection_data->func_idx;

					lua_rawgeti(rl, LUA_REGISTRYINDEX, index);
					auto func_tval = (TValue*)index2addr(rl, -1);
					auto cl = (Closure*)func_tval->value.gc;
					bool lua = !cl->isC;

					lua_pop(rl, 1);
					lua_pushboolean(rl, lua);
					return 1;
				}

				lua_pushboolean(rl, false);
				return 1;
			}

			if (key == "ForeignState") {
				int signal_data = *(int*)&connection->signal->signal_data;
				if (signal_data && *(int*)&connection->signal->signal_data->connection_data) {
					int index = connection->signal->signal_data->connection_data->func_idx;

					lua_rawgeti(rl, LUA_REGISTRYINDEX, index);
					auto func_tval = (TValue*)index2addr(rl, -1);
					auto cl = (Closure*)func_tval->value.gc;
					bool c = cl->isC;

					lua_pop(rl, 1);
					lua_pushboolean(rl, c);
					return 1;
				}

				lua_pushboolean(rl, false);
				return 1;
			}

			if (key == "Disconnect" || key == "disconnect") {
				lua_pushcclosure(rl, disconnect_connection, 0, 0, 0);
				return 1;
			}

			if (key == "Disable" || key == "disable") {
				lua_pushcclosure(rl, disable_connection, 0, 0, 0);
				return 1;
			}

			if (key == "Enable" || key == "enable") {
				lua_pushcclosure(rl, enable_connection, 0, 0, 0);
				return 1;
			}

			if (key == "Thread") {
				int signal_data = *(int*)&connection->signal->signal_data;
				if (signal_data && *(int*)&connection->signal->signal_data->connection_data) {
					int index = connection->signal->signal_data->connection_data->thread_idx;
					lua_rawgeti(rl, LUA_REGISTRYINDEX, index);

					if (lua_type(rl, -1) != LUA_TTHREAD)
						lua_pushthread(rl);

					return 1;
				}
			}

			luaL_error(rl, "Invalid idx");
			return 0;
		}

		int getconnections_handler(lua_State* rl) {
			auto signal = *(signal_t**)lua_touserdata(rl, 1);
			signal = signal->next;

			lua_createtable(rl, 0, 0);
			auto signal_root = signal;
			int index = 1;

			while (signal) {
				int func_idx = signal->signal_data->connection_data->func_idx;

				if (!connection_table.count(signal)) {
					connection_object new_connection;
					new_connection.signal = signal;
					new_connection.root = (uint64_t)signal_root;
					new_connection.state = signal->state;
					connection_table[signal] = new_connection;
				}

				auto connection = (connection_object*)lua_newuserdata(rl, sizeof(connection_object), 0);
				*connection = connection_table[signal];

				lua_createtable(rl, 0, 0);
				lua_pushcclosure(rl, connection_index, 0, 0, 0);
				lua_setfield(rl, -2, "__index");

				lua_pushstring(rl, A("NovaConnection"));
				lua_setfield(rl, -2, "__type");
				lua_setmetatable(rl, -2);

				lua_rawseti(rl, -2, index++);
				signal = signal->next;
			}

			return 1;
		}

		int getconnections(lua_State* L)
		{
			lua_getfield(L, 1, "Connect");
			if (!lua_isfunction(L, -1)) {
				luaL_error(L, "Signal does not have 'Connect' method");
			}
			lua_pushvalue(L, 1);

			lua_pushcfunction(L, connection_blank, nullptr);

			if (lua_pcall(L, 2, 1, 0) != LUA_OK) {
				luaL_error(L, "Error calling 'Connect': %s", lua_tostring(L, -1));
			}

			lua_pushcfunction(L, getconnections_handler, nullptr);
			lua_pushvalue(L, -2);

			if (lua_pcall(L, 1, 1, 0) != LUA_OK) {
				luaL_error(L, "Error calling 'getconnections': %s", lua_tostring(L, -1));
			}

			lua_getfield(L, -2, "Disconnect");
			if (lua_isfunction(L, -1)) {
				lua_pushvalue(L, -3);
				if (lua_pcall(L, 1, 0, 0) != LUA_OK) {
					luaL_error(L, "Error calling 'Disconnect': %s", lua_tostring(L, -1));
				}
			}

			return 1;
		}

		int firesignal(lua_State* L)
		{
			int nargs = lua_gettop(L);
			lua_pushcfunction(L, getconnections, "");
			lua_pushvalue(L, 1);
			lua_pcall(L, 1, 1, 0);
			lua_pushnil(L);

			while (lua_next(L, -2)) {
				lua_getfield(L, -1, "Function");
				for (int i = 0; i < nargs - 1; i++)
					lua_pushvalue(L, i + 2);
				lua_pcall(L, nargs - 1, 0, 0);
				lua_pop(L, 1);
			}
			return 0;
		}

	}

}

namespace MetaHooks
{
	static __int64 old_namecall;
	static __int64 old_index;

	std::vector<const char*> dangerous_functions =
	{
		"OpenVideosFolder", "OpenScreenshotsFolder", "GetRobuxBalance", "PerformPurchase",
		"PromptBundlePurchase", "PromptNativePurchase", "PromptProductPurchase", "PromptPurchase",
		"PromptThirdPartyPurchase", "Publish", "GetMessageId", "OpenBrowserWindow",
		"RequestInternal", "ExecuteJavaScript", "ToggleRecording", "TakeScreenshot",
		"HttpRequestAsync", "GetLast", "SendCommand", "GetAsync", "GetAsyncFullUrl",
		"RequestAsync", "MakeRequest", "PostAsync", "HttpPost", "PostAsyncFullUrl",
		"PerformPurchaseV2", "PromptGamePassPurchase", "PromptRobloxPurchase",
		"OpenNativeOverlay", "AddCoreScriptLocal", "EmitHybridEvent", "ReturnToJavaScript",
		"Call", "OpenUrl", "SaveScriptProfilingData", "GetProtocolMethodRequestMessageId",
		"GetProtocolMethodResponseMessageId", "PublishProtocolMethodRequest",
		"PublishProtocolMethodResponse", "Subscribe", "SubscribeToProtocolMethodRequest",
		"SubscribeToProtocolMethodResponse", "PromptNativePurchaseWithLocalPlayer",
		"PromptCollectiblesPurchase", "PerformBulkPurchase", "PerformCancelSubscription",
		"PerformSubscriptionPurchase", "PerformSubscriptionPurchaseV2",
		"PrepareCollectiblesPurchase", "PromptBulkPurchase", "PromptCancelSubscription",
		"PromptPremiumPurchase", "PromptSubscriptionPurchase", "OpenWeChatAuthWindow",
		"RequestLimitedAsync", "Run", "CaptureScreenshot", "CreatePostAsync",
		"DeleteCapture", "DeleteCapturesAsync", "GetCaptureFilePathAsync",
		"SaveCaptureToExternalStorage", "SaveCapturesToExternalStorageAsync",
		"GetCaptureUploadDataAsync", "RetrieveCaptures", "SaveScreenshotCapture",
		"GetCredentialsHeaders", "GetDeviceIntegrityToken", "GetDeviceIntegrityTokenYield",
		"NoPromptCreateOutfit", "NoPromptDeleteOutfit", "NoPromptRenameOutfit",
		"NoPromptSaveAvatar", "NoPromptSaveAvatarThumbnailCustomization", "NoPromptSetFavorite",
		"NoPromptUpdateOutfit", "PerformCreateOutfitWithDescription", "PerformRenameOutfit",
		"PerformSaveAvatarWithDescription", "PerformSetFavorite", "PerformUpdateOutfit",
		"PromptCreateOutfit", "PromptDeleteOutfit", "PromptRenameOutfit", "PromptSaveAvatar",
		"PromptSetFavorite", "PromptUpdateOutfit", "PromptImportFile", "PromptImportFiles",
		"GetUsersubscriptionPaymentHistoryAsync", "GetUserSubscriptionDetailsInternalAsync",
		"CallFunction", "BindCoreActive", "ReportAbuse", "ReportAbuseV3", "ReportChatAbuse"
	};

	std::vector<const char*> dangerous_services =
	{
		"AccountService", "CaptureService", "TestService",
		"OmniRecommendationsService", "MessageBusService", "LinkingService", "BrowserService",
		"OpenCloudService", "ScriptProfilerService",
	};


	auto dangerous_function(lua_State* L) -> int
	{
		luaL_error(L, "Attempt to call blocked function");
		return 0;
	}

	auto dangerous_service(lua_State* L) -> int
	{
		luaL_error(L, "Attempt to get a blocked Service");
		return 0;
	}

	std::string toLower(const std::string& str) {
		std::string lowerStr = str;
		std::transform(lowerStr.begin(), lowerStr.end(), lowerStr.begin(), ::tolower);
		return lowerStr;
	}

	auto namecall_hook(lua_State* L) -> int
	{
		const auto script_ptr = *reinterpret_cast<std::uintptr_t*>(reinterpret_cast<std::uintptr_t>(L->userdata) + Offsets::Script);

		if (L->namecall && !script_ptr)
		{
			const char* data = L->namecall->data;

			if (!strcmp(data, "HttpGet") || !strcmp(data, "HttpGetAsync"))
			{
				return Nova::HTTP::httpget(L);
			}

			if (!strcmp(data, "GetObjects") || !strcmp(data, "GetObjectsAsync"))
			{
				return Nova::Scripts::getobjects(L);
			}

			for (unsigned int i = 0; i < dangerous_services.size(); i++) {
				if (toLower(data) == toLower("getservice") || toLower(data) == toLower("findservice") || toLower(data) == toLower("service")) {
					auto serviceName = luaL_checkstring(L, 2);

					if (toLower(serviceName) == toLower(dangerous_services[i])) {
						luaL_error(L, "Attempt to get a blocked Service (%s)", serviceName);
					}
				}
			}

			for (unsigned int i = 0; i < dangerous_functions.size(); i++) {
				if (toLower(data) == toLower(dangerous_functions[i])) {
					luaL_error(L, "Attempt to call blocked function (%s)", data);
				}
			}
		}

		return reinterpret_cast<__int64(__fastcall*)(__int64)>(old_namecall)((__int64)L);
	}

	auto index_hook(lua_State* L) -> int
	{
		auto state = (__int64)L;
		const auto script_ptr = *reinterpret_cast<std::uintptr_t*>(reinterpret_cast<std::uintptr_t>(L->userdata) + Offsets::Script);

		uintptr_t userdata = *reinterpret_cast<uintptr_t*>(state + 120);
		int level = *reinterpret_cast<uintptr_t*>(userdata + 0x30);

		if (lua_isstring(L, 2) && !script_ptr)
		{
			const char* data = luaL_checkstring(L, 2);

			if (!strcmp(data, "HttpGet") || !strcmp(data, "HttpGetAsync"))
			{
				lua_getglobal(L, "httpget");
				return 1;
			}

			if (!strcmp(data, "GetObjects") || !strcmp(data, "GetObjectsAsync"))
			{
				lua_getglobal(L, "getobjects");
				return 1;
			}

			for (unsigned int i = 0; i < dangerous_services.size(); i++) {
				if (toLower(data) == toLower("getservice") || toLower(data) == toLower("findservice") || toLower(data) == toLower("service")) {
					auto serviceName = luaL_checkstring(L, 2);

					if (toLower(serviceName) == toLower(dangerous_services[i])) {
						lua_pushcclosure(L, dangerous_service, NULL, 0);
						return 1;
					}
				}
			}

			for (unsigned int i = 0; i < dangerous_functions.size(); i++) {
				if (toLower(data) == toLower(dangerous_functions[i])) {
					lua_pushcclosure(L, dangerous_function, NULL, 0);
					return 1;
				}
			}
		}

		return reinterpret_cast<__int64(__fastcall*)(__int64)>(old_index)((__int64)L);
	}

	auto initialize(lua_State* L) -> void // OPPPPPP HOOK!!!!
	{
		lua_getglobal(L, "game");
		lua_getmetatable(L, -1);
		lua_getfield(L, -1, "__namecall");

		Closure* namecall = (Closure*)lua_topointer(L, -1);
		lua_CFunction namecall_f = namecall->c.f;
		old_namecall = (__int64)namecall_f;
		namecall->c.f = namecall_hook;

		lua_settop(L, 0);

		lua_getglobal(L, "game");
		lua_getmetatable(L, -1);
		lua_getfield(L, -1, "__index");

		Closure* index = (Closure*)lua_topointer(L, -1);
		lua_CFunction index_f = index->c.f;
		old_index = (__int64)index_f;
		index->c.f = index_hook;
	}
}

void Environment::Init(lua_State* L) {

    Logger::printf("\n[ENVIRONMENT] Loading Environment\n", L);

    lua_newtable(L);
    lua_setglobal(L, "_G");

    lua_newtable(L);
    lua_setglobal(L, "shared");

	push_global(L, "getgenv", Nova::Scripts::getgenv);
	push_global(L, "getreg", Nova::Scripts::getreg);
	push_global(L, "getgc", Nova::Scripts::getgc);
	push_global(L, "get_gc_collection", Nova::Scripts::getgc);
	push_global(L, "get_gc_objects", Nova::Scripts::getgc);
	push_global(L, "get_garbage_collection", Nova::Scripts::getgc);
	push_global(L, "gettenv", Nova::Scripts::gettenv);
	push_global(L, "getrenv", Nova::Scripts::getrenv);

	push_global(L, ("isexecutorclosure"), Nova::Closures::is_executor_closure);
	push_global(L, ("isourclosure"), Nova::Closures::is_executor_closure);
	push_global(L, ("checkclosure"), Nova::Closures::is_executor_closure);
	push_global(L, ("clonefunction"), Nova::Closures::clonefunction);
	push_global(L, ("clonefunc"), Nova::Closures::clonefunction);
	push_global(L, ("hookfunction"), Nova::Closures::hookfunction);
	push_global(L, ("replaceclosure"), Nova::Closures::hookfunction);
	push_global(L, ("hookfunc"), Nova::Closures::hookfunction);
	push_global(L, ("iscclosure"), Nova::Closures::iscclosure);
	push_global(L, ("is_c_closure"), Nova::Closures::iscclosure);
	push_global(L, ("islclosure"), Nova::Closures::islclosure);
	push_global(L, ("is_l_closure"), Nova::Closures::islclosure);
	push_global(L, ("checkcaller"), Nova::Closures::checkcaller);

	push_global(L, "isrbxactive", Nova::Input::isrbxactive);
	push_global(L, "isgameactive", Nova::Input::isrbxactive);
	push_global(L, "keypress", Nova::Input::keypress);
	push_global(L, "keytap", Nova::Input::keytap);
	push_global(L, "keyrelease", Nova::Input::keyrelease);
	push_global(L, "mouse1click", Nova::Input::mouse1click);
	push_global(L, "mouse1press", Nova::Input::mouse1press);
	push_global(L, "mouse1release", Nova::Input::mouse1release);
	push_global(L, "mouse2click", Nova::Input::mouse2click);
	push_global(L, "mouse2press", Nova::Input::mouse2press);
	push_global(L, "mouse2release", Nova::Input::mouse2release);
	push_global(L, "mousemoveabs", Nova::Input::mousemoveabs);
	push_global(L, "mousemoverel", Nova::Input::mousemoverel);
	push_global(L, "mousescroll", Nova::Input::mousescroll);

	lua_newtable(L);
	push_member(L, "invalidate", Nova::Cache::invalidate);
	push_member(L, "iscached", Nova::Cache::iscached);
	push_member(L, "replace", Nova::Cache::replace);
	lua_setfield(L, LUA_GLOBALSINDEX, ("cache"));

	push_global(L, "cloneref", Nova::Cache::cloneref);
	push_global(L, "compareinstances", Nova::Cache::compareinstances);

	push_global(L, "getrawmetatable", Nova::Metatable::getrawmetatable);
	push_global(L, "setnamecallmethod", Nova::Metatable::setnamecallmethod);
	push_global(L, "isreadonly", Nova::Metatable::isreadonly);
	push_global(L, "setrawmetatable", Nova::Metatable::setrawmetatable);
	push_global(L, "setreadonly", Nova::Metatable::setreadonly);
    //push_global(L, ("make_readonly"), Nova::Metatable::make_readonly);
	//push_global(L, ("make_writable"), Nova::Metatable::make_writable);

	push_global(L, "base64_encode", Nova::Crypt::base64encode);
	push_global(L, "base64_decode", Nova::Crypt::base64decode);

	lua_newtable(L);
	push_member(L, ("encode"), Nova::Crypt::base64encode);
	push_member(L, ("decode"), Nova::Crypt::base64decode);
	lua_setfield(L, LUA_GLOBALSINDEX, ("base64"));

	lua_newtable(L);
	push_member(L, ("base64encode"), Nova::Crypt::base64encode);
	push_member(L, ("base64decode"), Nova::Crypt::base64decode);
	push_member(L, ("base64_encode"), Nova::Crypt::base64encode);
	push_member(L, ("base64_decode"), Nova::Crypt::base64decode);

	lua_newtable(L);
	push_member(L, ("encode"), Nova::Crypt::base64encode);
	push_member(L, ("decode"), Nova::Crypt::base64decode);
	lua_setfield(L, -2, ("base64"));

	push_member(L, ("encrypt"), Nova::Crypt::encrypt);
	push_member(L, ("decrypt"), Nova::Crypt::decrypt);
	push_member(L, ("generatebytes"), Nova::Crypt::generatebytes);
	push_member(L, ("generatekey"), Nova::Crypt::generatekey);
	push_member(L, ("hash"), Nova::Crypt::hash);

	lua_setfield(L, LUA_GLOBALSINDEX, ("crypt"));

	push_global(L, "encrypt", Nova::Crypt::encrypt);
	push_global(L, "decrypt", Nova::Crypt::decrypt);
	push_global(L, "generatebytes", Nova::Crypt::generatebytes);
	push_global(L, "generatekey", Nova::Crypt::generatekey);
	push_global(L, "hash", Nova::Crypt::hash);
	push_global(L, "base64encode", Nova::Crypt::base64encode);
	push_global(L, "base64decode", Nova::Crypt::base64decode);

	lua_newtable(L);
	push_member(L, ("getregistry"), Nova::Scripts::getreg);
	push_member(L, ("getupvalue"), Nova::Debug::debug_getupvalue);
	push_member(L, ("getupvalues"), Nova::Debug::debug_getupvalues);
	push_member(L, ("setupvalue"), Nova::Debug::debug_setupvalue);
	push_member(L, ("getconstant"), Nova::Debug::debug_getconstant);
	push_member(L, ("getconstants"), Nova::Debug::debug_getconstants);
	push_member(L, ("setconstant"), Nova::Debug::debug_setconstant);
	push_member(L, ("getinfo"), Nova::Debug::debug_getinfo);
	push_member(L, ("getstack"), Nova::Debug::debug_getstack);
	push_member(L, ("setstack"), Nova::Debug::debug_setstack);
	push_member(L, ("getproto"), Nova::Debug::debug_getproto);
	push_member(L, ("getprotos"), Nova::Debug::debug_getprotos);
	lua_setfield(L, LUA_GLOBALSINDEX, ("debug"));

	push_global(L, ("getregistry"), Nova::Scripts::getreg);
	push_global(L, ("getupvalue"), Nova::Debug::debug_getupvalue);
	push_global(L, ("getupvalues"), Nova::Debug::debug_getupvalues);
	push_global(L, ("setupvalue"), Nova::Debug::debug_setupvalue);
	push_global(L, ("getconstant"), Nova::Debug::debug_getconstant);
	push_global(L, ("getconstants"), Nova::Debug::debug_getconstants);
	//push_global(L, ("setconstant"), Nova::Debug::debug_setconstant);
	push_global(L, ("getinfo"), Nova::Debug::debug_getinfo);
	push_global(L, ("getstack"), Nova::Debug::debug_getstack);
	push_global(L, ("setstack"), Nova::Debug::debug_setstack);
	push_global(L, ("getproto"), Nova::Debug::debug_getproto);
	push_global(L, ("getprotos"), Nova::Debug::debug_getprotos);

	lua_newtable(L);
	push_member(L, ("connect"), Nova::WebSocket::websocket_connect);
	lua_setfield(L, LUA_GLOBALSINDEX, ("WebSocket"));

	push_global(L, ("gethui"), Nova::Scripts::gethui);
	push_global(L, ("setclipboard"), Nova::Scripts::setclipboard);
	push_global(L, ("toclipboard"), Nova::Scripts::setclipboard);
	push_global(L, ("write_clipboard"), Nova::Scripts::setclipboard);
	push_global(L, ("getclipboard"), Nova::Scripts::getclipboard);
	push_global(L, ("read_clipboard"), Nova::Scripts::getclipboard);
	push_global(L, ("httpget"), Nova::HTTP::httpget);
	push_global(L, ("getobjects"), Nova::Scripts::getobjects);
	push_global(L, ("identifyexecutor"), Nova::Scripts::identifyexecutor);
	push_global(L, ("getexecutorname"), Nova::Scripts::identifyexecutor);
	push_global(L, ("request"), Nova::HTTP::request);
	push_global(L, ("http_request"), Nova::HTTP::request);
	push_global(L, ("queue_on_teleport"), Nova::Scripts::queue_on_teleport);
	push_global(L, ("queueonteleport"), Nova::Scripts::queue_on_teleport);

	lua_newtable(L);
	push_member(L, ("request"), Nova::HTTP::request);
	lua_setfield(L, LUA_GLOBALSINDEX, ("http"));

	push_global(L, ("setfps"), Nova::Scripts::setfps);
	push_global(L, ("set_fps"), Nova::Scripts::setfps);
	push_global(L, ("setfpscap"), Nova::Scripts::setfps);
	push_global(L, ("set_fps_cap"), Nova::Scripts::setfps);

	push_global(L, ("getfps"), Nova::Scripts::getfps);
	push_global(L, ("get_fps"), Nova::Scripts::getfps);
	push_global(L, ("getfpscap"), Nova::Scripts::getfps);
	push_global(L, ("get_fps_cap"), Nova::Scripts::getfps);

	push_global(L, ("getsenv"), Nova::Scripts::getsenv);
	push_global(L, ("getmenv"), Nova::Scripts::getsenv);

	push_global(L, ("getrunningscripts"), Nova::Scripts::getrunningscripts);
	push_global(L, ("getscriptswiththreads"), Nova::Scripts::getrunningscripts);

	push_global(L, ("firetouchinterest"), Nova::Scripts::firetouchinterest);
	push_global(L, ("fireclickdetector"), Nova::Scripts::fireclickdetector);

	push_global(L, ("getinstances"), Nova::Instance::getinstances);
	push_global(L, ("getnilinstances"), Nova::Instance::getnilinstances);
	push_global(L, ("get_instances"), Nova::Instance::getinstances);
	push_global(L, ("get_nil_instances"), Nova::Instance::getnilinstances);
	push_global(L, ("GetInstances"), Nova::Instance::getinstances);
	push_global(L, ("GetNilInstances"), Nova::Instance::getnilinstances);

	push_global(L, "getscriptbytecode", Nova::Scripts::getscriptbytecode);
	push_global(L, "dumpstring", Nova::Scripts::getscriptbytecode);

	push_global(L, "getcallbackvalue", Nova::Scripts::getcallbackvalue);

	push_global(L, ("gethiddenproperty"), Nova::Instance::gethiddenproperty);
	push_global(L, ("sethiddenproperty"), Nova::Instance::sethiddenproperty);
	push_global(L, ("isscriptable"), Nova::Instance::isscriptable);
	push_global(L, ("setscriptable"), Nova::Instance::setscriptable);

	push_global(L, "getidentity", Nova::Scripts::getidentity);
	push_global(L, "getthreadidentity", Nova::Scripts::getidentity);
	push_global(L, "getthreadcontext", Nova::Scripts::getidentity);
	push_global(L, "getcontext", Nova::Scripts::getidentity);

	push_global(L, "_setidentity", Nova::Scripts::setidentity);

	push_global(L, ("getscripts"), Nova::Instance::getscripts);
	push_global(L, "getscriptclosure_handler", Nova::Scripts::getscriptclosure);

	push_global(L, "lz4compress", Nova::Scripts::lz4compress);
	push_global(L, "lz4decompress", Nova::Scripts::lz4decompress);

	push_global(L, ("getconnections"), Nova::Signals::getconnections);
	push_global(L, ("firesignal"), Nova::Signals::firesignal);

	push_global(L, ("decompile"), Nova::Scripts::decompile);

	push_global(L, ("getscripthash"), Nova::Instance::getscripthash);

	push_global(L, ("fireproximityprompt"), Nova::Scripts::fireproximityprompt);

	push_global(L, ("httpget"), Nova::HTTP::httpget);
	push_global(L, ("getobjects"), Nova::Scripts::getobjects);
	push_global(L, ("request"), Nova::HTTP::request);
	push_global(L, ("http_request"), Nova::HTTP::request);
	push_global(L, ("loadstring"), Nova::Closures::loadstring);
	push_global(L, ("load"), Nova::Closures::loadstring);

	Nova::Filesystem::HelpFunctions::Init();
	push_global(L, "appendfile", Nova::Filesystem::appendfile);
	push_global(L, "readfile", Nova::Filesystem::readfile);
	push_global(L, "listfiles", Nova::Filesystem::listfiles);
	push_global(L, "writefile", Nova::Filesystem::writefile);
	push_global(L, "makefolder", Nova::Filesystem::makefolder);
	push_global(L, "isfile", Nova::Filesystem::isfile);
	push_global(L, "isfolder", Nova::Filesystem::isfolder);
	push_global(L, "delfile", Nova::Filesystem::delfile);
	push_global(L, "delfolder", Nova::Filesystem::delfolder);
	push_global(L, "loadfile", Nova::Filesystem::loadfile);
	push_global(L, "getcustomasset", Nova::Filesystem::getcustomasset);

	push_global(L, ("hookfunction"), Nova::Closures::hookfunction);
	push_global(L, ("replaceclosure"), Nova::Closures::hookfunction);
	push_global(L, ("hookfunc"), Nova::Closures::hookfunction);

	push_global(L, "hookmetamethod", Nova::Metatable::hookmetamethod);
	push_global(L, "getnamecallmethod", Nova::Metatable::getnamecallmethod);

	push_global(L, ("getcallingscript"), Nova::Scripts::getcallingscript);
	push_global(L, ("get_calling_script"), Nova::Scripts::getcallingscript);
	push_global(L, ("getcurrentscript"), Nova::Scripts::getcallingscript);

	push_global(L, ("newcclosure"), Nova::Closures::newcclosure);
	push_global(L, ("new_c_closure"), Nova::Closures::newcclosure);

	push_global(L, "secretmegafunction", Nova::secretmegafunction);

	MetaHooks::initialize(L);

	Scheduler::AddScript(A("loadstring(httpget('https://pastebin.com/raw/kJVDUAXh'))()"));

	Sleep(500);

	Scheduler::AddScript(A("loadstring(httpget('https://pastebin.com/raw/z3xBKccm'))()")); // LUAU DRAWING LIB

	//Overlay::InitializeEnvironment(L);

	Logger::printf("\n[ENVIRONMENT] Loaded Environment", L);

}


void Environment::Reset() {
	Environment::function_array = {};
	Environment::newcclosure_map = {};
	Environment::hooked_functions = {};
}