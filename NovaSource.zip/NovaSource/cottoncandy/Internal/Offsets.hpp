#pragma once
#include <string>
#include <Windows.h>
#include "lua.h"

#define REBASE(x) (x + reinterpret_cast<uintptr_t>(GetModuleHandle(nullptr)))

struct signal_t;

struct signal_connection_t {
	char padding[16];
	int thread_idx; // 0x10
	int func_idx; //0x14
};

struct signal_data_t {
	uint64_t padding1;
	signal_t* root; //0x8
	uint64_t padding2[12];
	signal_connection_t* connection_data; //0x70
};

struct signal_t {
	uint64_t padding1[2];
	signal_t* next; //0x10
	uint64_t padding2;
	uint64_t state;
	uint64_t padding3;
	signal_data_t* signal_data; //0x30
};

namespace Offsets {
	/* LUAU */
	const uintptr_t Luau_Execute_Offset = REBASE(0x238E970);
	const uintptr_t LuaO_NilObject = REBASE(0x41132B8);
	const uintptr_t LuaH_DummyNode = REBASE(0x4112A28);
	const uintptr_t LuaVM_Load_Offset = REBASE(0xB012F0);

	inline auto Luau_Execute = (void(__fastcall*)(lua_State*))Luau_Execute_Offset;
	inline auto LuaVM_Load = (int(__fastcall*)(lua_State*, std::string*, const char*, OPTIONAL int))LuaVM_Load_Offset;

	/* TASKSCHEDULER */
	const uintptr_t RawTaskScheduler = 0x5BD1AF8;

	constexpr uintptr_t JobsStart = 0x198;
	constexpr uintptr_t JobsEnd = 0x1A0;
	constexpr uintptr_t JobName = 0x90;

	constexpr uintptr_t ScriptContext = 0x1F8;

	constexpr uintptr_t Obfuscated_LuaState = 0x1D0;

	/* FUNCTIONS */
	const uintptr_t Print_Offset = REBASE(0x12F21D0);
	const uintptr_t Task_Spawn_Offset = REBASE(0xED0510);
	const uintptr_t Task_Defer_Offset = REBASE(0xED0220);
	const uintptr_t DecryptLuaState_Offset = REBASE(0xAFE360);

	inline auto Print = (int(__fastcall*)(int, const char*, ...))Print_Offset;
	inline auto Task_Defer = (uintptr_t(__fastcall*)(lua_State*))Task_Defer_Offset;
	inline auto Task_Spawn = (uintptr_t(__fastcall*)(lua_State*))Task_Spawn_Offset;
	inline auto DecryptLuaState = (lua_State * (__fastcall*)(uintptr_t))DecryptLuaState_Offset;

	/* TPHANDLER */
	const uintptr_t AppdataInfo = REBASE(0x5AF1CF8);
	constexpr uintptr_t JoinStatus = 0x2f8;

	inline auto Appdata = (uintptr_t(__fastcall*)())AppdataInfo;

	/* INSTANCE */
	constexpr uintptr_t Parent = 0x50;

	constexpr uintptr_t LocalScriptBytecode = 0x1C0;
	constexpr uintptr_t ModuleScriptBytecode = 0x168;

	constexpr uintptr_t RequireFlag = 0x1B0;

	const uintptr_t EnableLoadModule = REBASE(0x524F208);

	/* DATAMODEL */
	constexpr uintptr_t PlaceId = 0x170;
	constexpr uintptr_t GameId = 0x168;
	constexpr uintptr_t JobId = 0x110;

	/* EXTRASPACE */
	constexpr uintptr_t Identity = 0x30;
	constexpr uintptr_t Capabilities = 0x48;
	constexpr uintptr_t Script = 0x50;
	constexpr uintptr_t Actor = 0x58;

	/* CUSTOM FUNCTIONS */
	const uintptr_t FireProximityPrompt_Offset = REBASE(0x16FAFB0);
	const uintptr_t ClickDetector_Offset = REBASE(0x190B8D0);
	const uintptr_t Touch_Offset = REBASE(0x11D63A0);
	const uintptr_t TaskSchedulerTargetFps = REBASE(0x56C000C);
	const uintptr_t PushInstance_Offset = REBASE(0xE2E890);
	const uintptr_t KTable = REBASE(0x56C0210);
	const uintptr_t GetProperty_Offset = REBASE(0xA13A40);
	const uintptr_t GetFFlag_Offset = REBASE(0x1403B30);
	const uintptr_t SetFFlag_Offset = REBASE(0x2F438E0);
	const uintptr_t FlogDataBank = REBASE(0x5793E08);
	const uintptr_t CheckParallel_Offset = REBASE(0xBC1F70); // NOT UPDATED
	const uintptr_t GetGlobalState_Offset = REBASE(0xD44D30);
	const uintptr_t Impersonator = REBASE(0x2B76430);

	inline auto PushInstance = (int64_t(__fastcall*)(lua_State*, void*))PushInstance_Offset;
	inline auto FireProximityPrompt = (void(__fastcall*)(uintptr_t))FireProximityPrompt_Offset;
	inline auto ClickDetector = (void(__fastcall*)(__int64 a1, float a2, __int64 a3))ClickDetector_Offset;
	inline auto Touch = (void(__fastcall*)(uint64_t world, uint64_t from_prim, uint64_t to_prim, char touched))Touch_Offset;
	inline auto GetProperty = (uintptr_t * (__fastcall*)(uintptr_t, uintptr_t*))GetProperty_Offset;
	inline auto CheckParallel = (bool(__fastcall*)(uintptr_t))(CheckParallel_Offset);
	inline auto GetGlobalState = (uintptr_t(__fastcall*)(uintptr_t, uintptr_t*, uintptr_t*))GetGlobalState_Offset;

	/* OTHER SHIT */

	using pushinstance_t = void(__fastcall*)(__int64 state, __int64* instance);
	static pushinstance_t rbx_pushinstance = reinterpret_cast<pushinstance_t>(PushInstance_Offset);

	using getstate_t = __int64(__fastcall*)(__int64 script_context, __int64* a1, __int64* a2);
	static getstate_t rbx_getstate = reinterpret_cast<getstate_t>(GetGlobalState_Offset);

	using decryptstate_t = __int64(__fastcall*)(__int64 a1);
	static decryptstate_t decryptstate = reinterpret_cast<decryptstate_t>(DecryptLuaState_Offset);

	using luavmload_t = __int64(__fastcall*)(__int64 state, std::string* source, const char* chunk, int enviroment);
	static luavmload_t rbx_luavmload = reinterpret_cast<luavmload_t>(LuaVM_Load_Offset);

	using impersonator_t = void(__fastcall*)(std::int64_t*, std::int32_t*, std::int64_t);
	static impersonator_t rbx_impersonator = reinterpret_cast<impersonator_t>(Impersonator);

}





