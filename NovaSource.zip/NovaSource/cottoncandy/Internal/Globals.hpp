#pragma once
#include <cstdint>
#include <lua.h>
#include <Windows.h>

#define DebugMode false	

namespace Globals {

	inline HMODULE DLL;

	inline uintptr_t DataModel;
	inline uintptr_t ScriptContext;

	inline lua_State* RobloxState;
	inline lua_State* NovaState;

	inline bool Execution = true;

}