#pragma once

#include <iostream>
#include <filesystem>

class Logs {
public:
	static std::string ReadFile(const std::string& FilePath);
	static std::filesystem::path FindLatestLog(const std::string& LogLocation);
	static std::string GetLogInfo();
	static uintptr_t ExtractPointer(const std::string& Line);
	static uintptr_t Get();
};

class DataModel
{
public:
	static uintptr_t Get();
};

