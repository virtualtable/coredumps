#include "Scheduler.hpp"

#include "../Globals.hpp"
#include "../TaskScheduler/TaskScheduler.hpp"
#include "../Execution/Execution.hpp"
#include "../Logger/Logger.hpp"

#include <mutex>
#include <shared_mutex>

#include "lstate.h"

std::queue<std::string> Scheduler::coderun_queue = {};
std::queue<SchedulerJob> Scheduler::schedulerJobs = {};
/*
int SchedulerCycle() {

    if (!Scheduler::coderun_queue.empty()) {
        std::string script = Scheduler::coderun_queue.front();
        Execution::Execute(Globals::NovaState, script);
        Scheduler::coderun_queue.pop();
    }

    return 0;
}

std::shared_mutex __scheduler_lock;

SchedulerJob Scheduler::GetSchedulerJob(bool shouldPop) {
    if (schedulerJobs.empty())
        return SchedulerJob("");
    auto job = schedulerJobs.front();
    if (shouldPop)
        schedulerJobs.pop();
    return job;
}

bool Scheduler::ExecuteJob(lua_State* L, SchedulerJob* job) {
    //const auto execution = Execution::GetSingleton();

    if (job->bIsLuaCode) {
        if (job->luaJob.szluaCode.empty())
            return true;

        Logger::printf("test");

        Execution::Execute(L, job->luaJob.szluaCode);
        //execution->Send(L, job->luaJob.szluaCode,true);
        return true;
    }
    else {
        return false;
    }
};

void StepScheduler(lua_State* runner) {

    std::scoped_lock lg{ __scheduler_lock };

    auto job = Scheduler::GetSchedulerJob(false);
    Scheduler::GetSchedulerJob(Scheduler::ExecuteJob(runner, &job));

}

uintptr_t __fastcall SchedulerHook(uintptr_t a1, uintptr_t a2, uintptr_t a3) {

    StepScheduler(Globals::NovaState);

    return OldSchedulerVF != nullptr ? OldSchedulerVF(a1, a2, a3) : 0;
}*/

using VTFunctionType = uintptr_t(__fastcall*)(uintptr_t, uintptr_t, uintptr_t);
VTFunctionType OldSchedulerVF = nullptr;

uintptr_t __fastcall SchedulerHook(uintptr_t a1, uintptr_t a2, uintptr_t a3)
{
    if (!Scheduler::coderun_queue.empty())
    {
        Execution::Execute(Globals::NovaState, Scheduler::coderun_queue.front().c_str());
        Scheduler::coderun_queue.pop();
    }

    return OldSchedulerVF != nullptr ? OldSchedulerVF(a1, a2, a3) : 0;
}

void Scheduler::Init(lua_State* L) {
    const auto coolJob = TaskScheduler::GetJobByName(("LuaGc"));

    if (!coolJob)
        return;

    auto VTable = new void* [25];
    memcpy(VTable, *(void**)coolJob, sizeof(uintptr_t) * 25);
    OldSchedulerVF = (VTFunctionType)(VTable[2]);
    VTable[2] = SchedulerHook;
    *(void**)coolJob = VTable;
}

std::mutex Pending;

void Scheduler::AddScript(const std::string& Script)
{
    {
        std::lock_guard<std::mutex> lock(Pending);
        coderun_queue.push(Script);
    }
}

void ThreadFunc(const std::function<YieldReturn()>& YieldedFunction, lua_State* L)
{
    YieldReturn ret_func;

    try
    {
        ret_func = YieldedFunction();
    }
    catch (std::exception ex)
    {
        lua_pushstring(L, ex.what());
        lua_error(L);
    }

    lua_State* l_new = lua_newthread(L);

    const auto returns = ret_func(L);

    lua_getglobal(l_new, ("task"));
    lua_getfield(l_new, -1, ("defer"));

    lua_pushthread(L);
    lua_xmove(L, l_new, 1);

    for (int i = returns; i >= 1; i--)
    {
        lua_pushvalue(L, -i);
        lua_xmove(L, l_new, 1);
    }

    lua_pcall(l_new, returns + 1, 0, 0);
    lua_settop(l_new, 0);
}

int Scheduler::YieldExecution(lua_State* L, const std::function<YieldReturn()>& YieldedFunction)
{
    lua_pushthread(L);
    lua_ref(L, -1);
    lua_pop(L, 1);

    std::thread(ThreadFunc, YieldedFunction, L).detach();

    L->base = L->top;
    L->status = LUA_YIELD;

    L->ci->flags |= 1;
    return -1;
}
