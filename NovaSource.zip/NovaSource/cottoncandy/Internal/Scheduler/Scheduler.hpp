#pragma once

#include <functional>
#include <queue>

#include "lua.h"

class SchedulerJob {
public:
    struct lJob {
        std::string szluaCode;
    } luaJob;


    bool bIsLuaCode;
    bool bIsYieldingJob;

    SchedulerJob(const SchedulerJob& job) {
        if (job.bIsLuaCode) {
            this->bIsLuaCode = true;
            this->luaJob = {};
            this->luaJob.szluaCode = job.luaJob.szluaCode;
        }
    };

    explicit SchedulerJob(const std::string& luaCode) {
        this->bIsLuaCode = true;

        this->luaJob = {};

        this->luaJob.szluaCode = luaCode;
    }

    ~SchedulerJob() = default;


};

using YieldReturn = std::function<int(lua_State* L)>;

class Scheduler {
public:
    static std::queue<std::string> coderun_queue;
    static void Init(lua_State* L);

    static void AddScript(const std::string& Script);

    static std::queue<SchedulerJob> schedulerJobs;

    static SchedulerJob GetSchedulerJob(bool shouldPop);

    static bool ExecuteJob(lua_State* L, SchedulerJob* job);

    static int YieldExecution(lua_State* L, const std::function<YieldReturn()>& YieldedFunction);
};

