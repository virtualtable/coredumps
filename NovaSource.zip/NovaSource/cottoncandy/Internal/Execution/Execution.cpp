#include "Execution.hpp"

#include "../Offsets.hpp"
#include "../Logger/Logger.hpp"

#include "Luau/BytecodeBuilder.h"
#include "Luau/BytecodeUtils.h"
#include "Luau/Compiler.h"

#include <zstd/xxhash.h>
#include <zstd/zstd.h>

class bytecode_encoder_t : public Luau::BytecodeEncoder {
    inline void encode(uint32_t* data, size_t count) override {

        for (auto i = 0u; i < count;) {

            auto& opcode = *reinterpret_cast<uint8_t*>(data + i);

            i += Luau::getOpLength(LuauOpcode(opcode));

            opcode *= 227;
        }
    }
};

void Execution::SetProtoCaps(Proto* proto, uintptr_t* Caps) {
    if (!proto)
        return;

    proto->userdata = static_cast<void*>(Caps);
    for (auto i = 0; i < proto->sizep; i++) {
        SetProtoCaps(proto->p[i], Caps);
    }
}

std::string CompressBytecode(const std::string& bytecode) {
    const auto data_size = bytecode.size();
    const auto max_size = ZSTD_compressBound(data_size);
    auto buffer = std::vector<char>(max_size + 8);

    strcpy_s(&buffer[0], buffer.capacity(), ("RSB1"));
    memcpy_s(&buffer[4], buffer.capacity(), &data_size, sizeof(data_size));

    const auto compressed_size = ZSTD_compress(&buffer[8], max_size, bytecode.data(), data_size, ZSTD_maxCLevel());
    if (ZSTD_isError(compressed_size))
        throw std::runtime_error(("Failed to compress the bytecode."));

    const auto size = compressed_size + 8;
    const auto key = XXH32(buffer.data(), size, 42u);
    const auto bytes = reinterpret_cast<const uint8_t*>(&key);

    for (auto i = 0u; i < size; ++i)
        buffer[i] ^= bytes[i % 4] + i * 41u;

    return std::string(buffer.data(), size);
}

static uintptr_t Caps = 0xFFFFFFFFFFFFFFFF;

int Execution::Lua_LoadString(lua_State* L, std::string& code, std::string chunkName) {
    static auto encoder = bytecode_encoder_t();

    const auto bytecode =
        Luau::compile(std::string(("script = Instance.new('LocalScript');"))
            .append(code),
            { 1, 1, 0 }, {}, &encoder);

    std::string compressed = CompressBytecode(bytecode);

    if (chunkName.empty())
        chunkName = "=";
   
    if (Offsets::LuaVM_Load(L, &compressed, chunkName.c_str(), 0) != LUA_OK) {
        lua_pushnil(L);
        lua_pushvalue(L, -2);
        return 2;
    }

    auto* stackClosure = const_cast<Closure*>(static_cast<const Closure*>(lua_topointer((lua_State*)L, -1)));

    SetProtoCaps(stackClosure->l.p, &Caps);

    return 1;
}

#include <oxorany/oxorany_include.h>

void Execution::Execute(lua_State* L, std::string code) {
    static auto encoder = bytecode_encoder_t();

    const auto bytecode = Luau::compile(std::string(("script = Instance.new('LocalScript');")).append(code), { 1, 1, 0 }, {}, &encoder);

    std::string compressed = CompressBytecode(bytecode);

    if (bytecode.at(0) == 0) {
        Offsets::Print(3, bytecode.c_str() + 1);
    }
    else {
        lua_State* L2 = lua_newthread(L);

        lua_pop(L, -1);

        Logger::printf("[EXECUTION] Newstate: %p", L2);

        const auto Userdata = (uintptr_t)L2->userdata;
        *(__int64*)(Userdata + Offsets::Capabilities) = Caps;

        if (Offsets::LuaVM_Load(L2, &compressed, A("=Nova"), 0) != LUA_OK) {
            const char* error = lua_tostring(L2, -1);
            Offsets::Print(3, error);
            lua_pop(L2, 1);
            return;
        }

        auto* stackClosure = const_cast<Closure*>(static_cast<const Closure*>(lua_topointer(L2, -1)));

        Logger::printf("[EXECUTION] Closure: %p", stackClosure);

        SetProtoCaps(stackClosure->l.p, &Caps);

        Offsets::Task_Spawn(L2);

        Logger::printf("[EXECUTION] Spawned the thread");

    }

}
