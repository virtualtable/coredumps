#pragma once
#include "lua.h"
#include "lstate.h"

class Execution {
public:

    static void SetProtoCaps(Proto* proto, uintptr_t* Caps);

    static int Lua_LoadString(lua_State* L, std::string& code, std::string chunkName);

    static void Execute(lua_State* L, std::string code);
};