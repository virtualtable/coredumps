#include "Communications.hpp"

#include "../Scheduler/Scheduler.hpp"
#include "../Globals.hpp"

#include <string>
#include <thread>
#include <vector>
#include <windows.h>
#include <oxorany/oxorany_include.h>

void Communications::Init() {
    std::thread([] {

        DWORD read{};

        std::vector<char> buffer(999999);
        std::string code{};

        HANDLE Pipe = CreateNamedPipeA((A("\\\\.\\pipe\\ifyouseethisthenyouaregaybtw")), PIPE_ACCESS_DUPLEX | PIPE_TYPE_BYTE | PIPE_READMODE_BYTE, PIPE_WAIT, 1, 999999, 999999, NMPWAIT_USE_DEFAULT_WAIT, NULL);

        if (Pipe == INVALID_HANDLE_VALUE) {
            MessageBox(NULL, "Could not create Pipes", ("Selene"), MB_OK);
            return;
        }

        while (Pipe != INVALID_HANDLE_VALUE) {
            if (ConnectNamedPipe(Pipe, NULL) != FALSE || GetLastError() == ERROR_PIPE_CONNECTED) {

                while (ReadFile(Pipe, buffer.data(), static_cast<DWORD>(buffer.size() - 1), &read, NULL)) {
                    buffer[read] = '\0';
                    code.append(buffer.data(), read);
                }

                if (!code.empty() && Globals::Execution == true) {
                    Scheduler::AddScript(code);
                    
                    //scheduler::schedulerJobs.emplace(SchedulerJob(code));
                    code.clear();
                }

            }

            DisconnectNamedPipe(Pipe);
        }

        CloseHandle(Pipe);
        }).detach();
}