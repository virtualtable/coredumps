#pragma once
class Communications
{
public:
	static void Init();
};

