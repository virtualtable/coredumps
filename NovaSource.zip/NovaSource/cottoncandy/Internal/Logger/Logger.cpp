#include "Logger.hpp"
#include <windows.h>
#include <iostream>
#include <string>
#include <thread>

HANDLE hPipe = INVALID_HANDLE_VALUE;

void Logger::Init() {
    /*std::thread([] {
        while (true) {
            hPipe = CreateFileA(
                R"(\\.\pipe\NovaLogger)",
                GENERIC_WRITE,  
                0,              
                nullptr,        
                OPEN_EXISTING,  
                0,              
                nullptr         
            );

            if (hPipe != INVALID_HANDLE_VALUE) {
                //std::cout << "[Logger] Pipe erfolgreich verbunden!" << std::endl;
                break;
            }

            DWORD error = GetLastError();
            if (error == ERROR_PIPE_BUSY) {
                if (!WaitNamedPipeA(R"(\\.\pipe\NovaLogger)", 5000)) {
                    //std::cerr << "[Logger] Zeit�berschreitung beim Warten auf Pipe!" << std::endl;
                    continue;
                }
            }
            else {
                //std::cerr << "[Logger] Fehler beim Verbinden der Pipe! Fehlercode: " << error << std::endl;
                break;
            }
        }
        }).detach();*/
}

void Logger::printf(const char* fmt, ...) {
    /*if (hPipe == INVALID_HANDLE_VALUE) {
        //std::cerr << "[Logger] Pipe nicht verbunden!" << std::endl;
        return;
    }

    char buffer[1024];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);

    strcat_s(buffer, "\n");

    DWORD bytesWritten = 0;
    BOOL result = WriteFile(
        hPipe,
        buffer,
        (DWORD)strlen(buffer),
        &bytesWritten,
        nullptr
    );

    if (!result || bytesWritten == 0) {
        DWORD error = GetLastError();
        //std::cerr << "[Logger] Fehler beim Schreiben in die Pipe! Fehlercode: " << error << std::endl;
    }
    else {
        //std::cout << "[Logger] Nachricht erfolgreich gesendet: " << buffer << std::endl;
    }*/
}
